use Getopt::Long;

sub trim($);

$result = GetOptions ("input=s" => \$inputFile,
					  "rownames=s" => \$rowName,
                      "rowdescs=s"   => \$rowDesc,    
					  "filterDashRowNames=s" => \$filterDashRowNames,
					  "outputColumns=s" => \$outputColumns,
					  "output=s"  => \$outputPrefix);  

if (!($inputFile =~ /\.fpkm_tracking$/i)) {
	print STDERR "Incorrect input file type. Expected .fpkm_tracking file.\n";
	exit(1);
}

$outputFile = $outputPrefix;
if ($outputPrefix eq "") {
	$outputFile = "output.gct";
} elsif (!($outputFile =~ /\.gct$/i)) {
	$outputFile = $outputPrefix . ".gct";
}

open(IN, "<$inputFile") || die("Can't open file: $!");
@lines = <IN>;
close(IN);

#remove newlines, even if from different platforms
$joined = join('',@lines); #several lines may be present in each element of @lines
$joined =~ s/[\r\n]+/\n/g;
@lines = split(/\n/, $joined);
	
if ($#lines < 1)  {
	print STDERR "Error: The input file $inputFile contains no data, or is not a valid .fpkm_tracking file.\n";
	exit(1);
}

@colNames = split(/\t/, $lines[0]);
for $j (0..$#colNames) { trim($colNames[$j]); }


$rnIndex=-1;  #row names index
for $i (0..$#colNames)
{
	if ($colNames[$i] =~ m/$rowName$/) { $rnIndex=$i; last; }
}
if ($rnIndex == -1) {
	print STDERR "$rowName not found among FPKM_TRACKING file column names: @colNames.\nMissing headerline or invalid FPKM_TRACKING file.\n";
	exit(1);
}	

$rdIndex=-1;  #row descriptions index
for $i (0..$#colNames)
{
	if ($colNames[$i]  =~ m/$rowDesc$/) { $rdIndex=$i; last; }
}
if ($rdIndex == -1) {
	print STDERR "$rowDesc not found among FPKM_TRACKING file column names: @colNames.\nMissing headerline or invalid FPKM_TRACKING file.\n";
	exit(1);
}	

@ocIndex = ();
if($outputColumns ne "all")
{
    #output columns index
    for $i (0..$#colNames)
    {
        if ($colNames[$i] =~ m/$outputColumns/)
        {
            push(@ocIndex, $i);
        }
    }

    $ocIndexLength = @ocIndex;

    if ($ocIndexLength < 1) {
        print STDERR "$outputColumns not found among FPKM_TRACKING file column names: @colNames.\nMissing headerline or invalid FPKM_TRACKING file.\n";
        exit(1);
    }
}

@rowNames = ();
@rowDescs = ();
%sampleData = ();
$offset = 0; #for FPKM_lo, offset = 1. for FPKM_hi, offset = 2.
foreach $line (@lines[1..$#lines]) {
	@vals = split(/\t/, $line);
	push(@rowNames, trim($vals[$rnIndex]));
	push(@rowDescs, trim($vals[$rdIndex]));
	$j = 0;

	if($ocIndexLength < 1)
	{
	    for($j..$#vals)
	    {
            if($j != $rnIndex && $j != $rdIndex)
            {
                push(@{$sampleData{$colNames[$j]}},trim($vals[$j]));
            }
            $j++;
	    }
	}
	else
	{
	    foreach $index (@ocIndex)
	    {
            push(@{$sampleData{$colNames[$index]}},trim($vals[$index]));
        }
	}

}

@sampleNames = keys %sampleData;

#return error if all rownames are the same
$validRowNames = 0;
$char = $rowNames[0];
foreach $rn (@rowNames) {
	if ($rn ne $char) {
	 	$validRowNames = 1;
	 	last;
	}
}

if (!$validRowNames) {
	print STDERR "Error: The input file contains duplicate row names for \"$rowName\". Please make an alternate selection for rownames.\n";
	exit(1);
}	

#if filterDashRowNames==yes, remove rows with "-" as rowName.
@kept_i = ();
$numRemovedRows = 0;
if ($filterDashRowNames eq "yes") {
	for ($j=0;$j<=$#rowNames;$j++) {
		if (!($rowNames[$j] eq "-")) {
			push(@kept_i, $j);
		}
	}
	$numRemovedRows = $#rowNames - $#kept_i;	
	print "Filtered $numRemovedRows rows with invalid row names\n";
} else {
	@kept_i = (0..$#rowNames);  #keep all rows	
}

#return error if all data values to be written to the GCT file are zero
$validData = 0;
for $sample (@sampleNames) {
	for $i (@kept_i) {
		if ($sampleData{$sample}[$i] != 0) {
			$validData = 1;
			last;
		}
	}
}
if (!$validData && $numRemovedRows > 0) {
	print STDERR "Error: After filtering rows with invalid row names, all remaining FPKM values are zero.\n";
	exit(1);
} elsif (!$validData) {
	print STDERR "Error: The output file contains all-zero FPKM values.\n";
	exit(1);
}

#write GCT file
open(OUT, ">$outputFile") || die ("Can't open file: $!");
print OUT "#1.2\n";
print OUT $#kept_i+1, "\t", $#sampleNames+1, "\n";
print OUT $colNames[$rnIndex], "\tDescription\t";
print OUT join("\t",@sampleNames), "\n";
for $i (@kept_i) {
	print OUT $rowNames[$i], "\t", $rowDescs[$i];
	for $sample (@sampleNames) {
		print OUT"\t", $sampleData{$sample}[$i];
	}
	print OUT "\n";
}


# Perl trim function to remove whitespace from the start and end of the string
sub trim($)
{
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}


