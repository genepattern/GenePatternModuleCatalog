# Project Feature Set

use POSIX;
use Getopt::Std;
getopt('Fo');

BEGIN{
    open(STDERR, ">&STDOUT");
    $| = 1;                         # fflush() invoked at every output.
    print '';
}

$output_file = "output.txt"; 
$output_file = $opt_o if defined($opt_o); # -o <output file name>


$input_file = $opt_F if defined($opt_F); # -F <input file>

open(F, $input_file) || die "cannot open file $input_file\n";

$output_filename = ">" . "$output_file";
if(!($output_filename =~ /.txt/)) {
	$output_filename = $output_filename .".txt";	
}
open(OUT, $output_filename) || die "cannot open file $output_filename \n";

$header = <F>;
$line1 = <F>;  # scaling factors
$line2 = <F>;  # number of genes

$gene_count = 0;
$gene_accessions = ();

while (<F>) {
    chomp;
    @data = split("\t", $_);
    $desc = shift @data;
    $gene = shift @data;
    $gene_accessions[$gene_count] = $gene; 
    $gene_count++;
}

for $i (0..$gene_count - 1) {
    print OUT "$gene_accessions[$i]\n";
}

print "\n Total features extracted = $gene_count \n\n";



