mysvm <- function(dataset.file, cls.file, test.dataset.file, test.cls.file, output.file.name, ...) {
	libdir <- ""
	other.args <- list(...)
	if(length(other.args)==1) {
		libdir <- other.args[[1]]
	}
	options("warn"=-1)
	if(!require("e1071", quietly=TRUE)) {
		install.package(libdir, "e1071", "1.3-15")
	}
	library(e1071, verbose=FALSE)
	library(GenePattern, verbose=FALSE)
	
	train.dataset <- read.dataset(dataset.file)@data 
	
	train.dataset <- t(train.dataset)
	
	train.cls <- read.cls(cls.file)$labels 
	
	if(length(train.cls)!=dim(train.dataset)[1]) {
		stop("number of samples in cls file does not match the number of samples in training data")	
	}
	
	model <- svm(train.dataset, train.cls)
	
	test.dataset <- read.dataset(test.dataset.file)@data
	
	test.dataset <- t(test.dataset)
	test.cls <- read.cls(test.cls.file)$labels
	if(length(test.cls)!=dim(test.dataset)[1]) {
		stop("number of samples in cls file does not match the number of samples in test data")
	}
	
	
	pred <- predict.svm(model, test.dataset) # returns a factor 
	
		
	num.rows  <- dim(test.dataset)[1]
	num.errors <- 0
	for(i in 1:num.rows) {
		if(test.cls[i][[1]]!=pred[i][[1]]) {
			num.errors <- num.errors + 1
		}
	}
	
	result <- regexpr(paste(".odf","$",sep=""), tolower(output.file.name))
	if(result[[1]] == -1) { # append .odf file extension if it doesn't exist
		output.file.name <- paste(output.file.name, ".odf", sep="") 
	}
	
	output.file <- file(output.file.name, "w")
	on.exit(close(output.file))
	cat("SDF 1.0", "\n", file=output.file, append=TRUE)
	cat("HeaderLines= 8", "\n", file=output.file, append=TRUE)
	cat("COLUMN_NAMES:	Samples	True Class	Predicted Class	Confidence	Correct?", "\n", file=output.file, append=TRUE)
	cat("COLUMN_TYPES:	String	String	String	float	boolean", "\n", file=output.file, append=TRUE)
	cat("Model= Prediction Results", "\n", file=output.file, append=TRUE)
	cat("PredictorModel= SVM", "\n", file=output.file, append=TRUE)
	
	cat("NumFeatures=", length(model$index), "\n", file=output.file, append=TRUE) 
	num.correct <- num.rows-num.errors
	cat("NumCorrect=",file=output.file, append=TRUE)
	cat(num.correct, "\n", file=output.file, append=TRUE)
	cat("NumErrors=", num.errors, "\n", file=output.file, append=TRUE)
	cat("DataLines=", num.rows, "\n", file=output.file, append=TRUE)
	
	for(i in 1:num.rows) {
		row.name <- row.names(test.dataset)[i]
		cat(row.name, file=output.file, append=TRUE)
		cat("\t", file=output.file, append=TRUE)
		cat(test.cls[i][[1]]-1, file=output.file, append=TRUE) # true class
		cat("\t", file=output.file, append=TRUE)
		cat(pred[i][[1]]-1, file=output.file, append=TRUE) # predicted class
		cat("\t", file=output.file, append=TRUE)
		cat("1", file=output.file, append=TRUE) # FIXME confidence
		cat("\t", file=output.file, append=TRUE) 
		if(test.cls[i][[1]]==pred[i][[1]]) { # prediction correct?
			cat("true", file=output.file, append=TRUE);	
		} else {
			cat("false", file=output.file, append=TRUE);	
		}
		cat("\n", file=output.file, append=TRUE)
	}
	return(output.file.name)
}



read.dataset <- function(file) {
	result <- regexpr(paste(".gct","$",sep=""), tolower(file))
	if(result[[1]] != -1)
		return(read.gct(file))
	result <- regexpr(paste(".res","$",sep=""), tolower(file))
	if(result[[1]] != -1)
		return(read.res(file))
	
	stop("Input is not a res or gct file.")	
}

install.package <- function(dir, library, version) {
	isWindows <- Sys.info()[["sysname"]]=="Windows"
	isMac <- Sys.info()[["sysname"]]=="Darwin" 
	if(isWindows) {
		f <- paste(dir, library, "_", version, ".zip", sep="")
		.install.windows(f)
	} else if(isMac) {
		f <- paste(dir, library, "_", version, ".tgz", sep="") 
		if(!file.exists(f)) { # see if mac binary exists
			f <- paste(dir, library, "_", version, ".tar.gz", sep="")
		}
		.install.unix(f)
	} else { # install from source
		f <- paste(dir, library, "_", version, ".tar.gz", sep="")
		.install.unix(f)
	}	
}

.install.windows <- function(pkg) {
	install.packages(pkg, .libPaths()[1], CRAN=NULL, installWithVers=FALSE)
}

.install.unix <- function(pkg) {
    lib <- .libPaths()[1]
   # cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL --with-package-versions")
	 cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL")
    cmd <- paste(cmd, "-l", lib)
    cmd <- paste(cmd, " '", pkg, "'", sep = "")
    status <- system(cmd)
    if (status != 0) 
    	cat("\tpackage installation failed\n")
}

