message <- function (..., domain = NULL, appendLF = TRUE) {

}

mysvm <- function(...) {
	suppressMessages(.mysvm(...))
}

.mysvm <- function(...) {
	options("warn"=-1)
   args <- list(...)
   dataset.file <- NULL
   cls.file <- NULL
   test.dataset.file <- NULL
   test.cls.file <- NULL
   output.file.name <- NULL
   saved.model.file <- NULL

   for(i in 1:length(args)) {
		flag <- substring(args[[i]], 0, 3)
      arg <- substring(args[[i]], 4, nchar(args[[i]]))
		if(flag=='-rf') {
			dataset.file <- arg
		} else if(flag=='-rc') {
			cls.file <- arg
		} else if(flag=='-sm') {
			saved.model.file <- arg
		} else if(flag=='-ef') {
			test.dataset.file <- arg
		} else if(flag=='-ec') {
			test.cls.file <- arg
		} else if(flag=='-pr') {
         output.file.name <- arg
		} else if(flag=='-mf') {
			model.file.name <- arg
		} else if(flag=='-li') {
			libdir <- arg
		} else  {
			stop(paste("unknown option", flag, sep=": "))
		}
	}
   if(dataset.file!='' && cls.file=='' || cls.file!='' && dataset.file=='' ) {
      stop("Both training data file and training class file must be supplied.", call.=F)
   }
   if(saved.model.file=='' && (dataset.file==''|| cls.file=='')) {
      stop("One of saved model or training data must be supplied.", call.=F)
   }

	if(libdir!='') {
		source(paste(libdir, "common.R", sep=''))
		setLibPath(libdir)
		install.required.packages(libdir)
	}
	if(dataset.file!='' && saved.model.file!='') {
		 cat("Both saved model and training data supplied-using saved model.")
	}

	if(dataset.file!='' && saved.model.file=='') {
		if(model.file.name=='') {
			 stop("Model output file name must be given", call.=F)
		}

      train.dataset <- read.dataset(dataset.file)$data
      train.dataset <- t(train.dataset)
      train.cls <- read.cls(cls.file)$labels

      if(length(train.cls)!=dim(train.dataset)[1]) {
         stop("Number of samples in cls file does not match the number of samples in training data", call.=F)
      }
      model <- svm(train.dataset, train.cls, probability=T)
      train.features <-  colnames(train.dataset)

      result <- regexpr(paste(".model","$",sep=""), tolower(model.file.name))
		if(result[[1]] == -1) { # append .model file extension if it doesn't exist
			model.file.name <- paste(model.file.name, ".model", sep="")
		}

      save(model, train.features, train.features, file=model.file.name)
	} else {
		if(saved.model.file=='') {
			stop("Either training data or a saved model must be provided.", call.=F)
		}
		if(test.dataset.file =='') {
			stop("No test dataset provided.", call.=F)
		}
		if(test.cls.file =='') {
			stop("No test class labels provided.", call.=F)
		}
      load(saved.model.file)
   }

   if(test.dataset.file!='') {
		test.dataset <- read.dataset(test.dataset.file)$data
		test.dataset <- t(test.dataset)
		test.dataset <- try(test.dataset[,train.features])
		if(class(test.dataset)=="try-error") {
			stop("Test data does not contain the same features as the train data.\n", call.=F)
		}

		test.cls <- read.cls(test.cls.file)$labels
		if(length(test.cls)!=dim(test.dataset)[1]) {
			stop("Number of samples in test cls file does not match the number of samples in test data", call.=F)
		}

		pred <- try(predict(model, test.dataset, probability=T)) # returns a factor
		if(class(pred)=="try-error") {
			stop("An error occured while predicting the classes for the test data.", call.=F)
		}

		probabilities <- attr(pred, "probabilities")

		num.rows  <- dim(test.dataset)[1]
		num.errors <- 0
		for(i in 1:num.rows) {
			if(test.cls[i]!=pred[i]) {
				num.errors <- num.errors + 1
			}
		}

		result <- regexpr(paste(".odf","$",sep=""), tolower(output.file.name))
		if(result[[1]] == -1) { # append .odf file extension if it doesn't exist
			output.file.name <- paste(output.file.name, ".odf", sep="")
		}

		output.file <- file(output.file.name, "w")
		on.exit(close(output.file))
		cat("ODF 1.0", "\n", file=output.file, append=TRUE)
		cat("HeaderLines=8", "\n", file=output.file, append=TRUE)
		cat("COLUMN_NAMES:	Samples	True Class	Predicted Class	Confidence	Correct?", "\n", file=output.file, append=TRUE)
		cat("COLUMN_TYPES:	String	String	String	float	boolean", "\n", file=output.file, append=TRUE)
		cat("Model=Prediction Results", "\n", file=output.file, append=TRUE)
		cat("PredictorModel=SVM", "\n", file=output.file, append=TRUE)
		cat("NumFeatures=", length(train.features), "\n", file=output.file, append=TRUE, sep='')
		num.correct <- num.rows-num.errors
		cat("NumCorrect=",file=output.file, append=TRUE)
		cat(num.correct, "\n", file=output.file, append=TRUE)
		cat("NumErrors=", num.errors, "\n", file=output.file, append=TRUE, sep='')
		cat("DataLines=", num.rows, "\n", file=output.file, append=TRUE, sep='')


		for(i in 1:num.rows) {
			row.name <- row.names(test.dataset)[i]
			cat(row.name, file=output.file, append=TRUE)
			cat("\t", file=output.file, append=TRUE)
			cat(as.character(test.cls[i]), file=output.file, append=TRUE) # true class
			cat("\t", file=output.file, append=TRUE)
			predClass <- as.character(pred[i])
			cat(predClass, file=output.file, append=TRUE) # predicted class
			cat("\t", file=output.file, append=TRUE)
			conf <- probabilities[i, as.character(pred[i])]
			cat(conf, file=output.file, append=TRUE)
			cat("\t", file=output.file, append=TRUE)
			if(test.cls[i]==pred[i]) { # prediction correct?
				cat("true", file=output.file, append=TRUE);
			} else {
				cat("false", file=output.file, append=TRUE);
			}
			cat("\n", file=output.file, append=TRUE)
		}
		return(output.file.name)
	}
}

install.required.packages <- function(libdir) {
	if(!is.package.installed(libdir, "e1071")) {
		install.package(libdir, "e1071_1.5-16.zip", "e1071_1.5-16.tgz", "e1071_1.5-16.tar.gz")
	}
	library(class, verbose=FALSE)
	library(e1071, verbose=FALSE)
}







