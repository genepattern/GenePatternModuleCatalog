 unpackPkg <- function(pkg, pkgname, installWithVers = FALSE) {
 	isWindows <- Sys.info()[["sysname"]]=="Windows"
 	if(!isWindows) stop("This function only works with Windows")
        lib <- .libPaths()[1]
        tmpDir <- tempfile("Rinstdir")
        dir.create(tmpDir)
        cDir <- getwd()
        on.exit(setwd(cDir), add = TRUE)
        res <- zip.unpack(pkg, tmpDir)
        setwd(tmpDir)
        res <- tools::checkMD5sums(pkgname, file.path(tmpDir, 
            pkgname))
        if (!is.na(res) && res) 
            cat("package ", pkgname, " successfully unpacked and MD5 sums checked\n")
        if (file.exists("DESCRIPTION")) {
            conts <- read.dcf("DESCRIPTION", fields = "Contains")[1, 
                ]
            if (is.na(conts)) 
                stop("Malformed bundle DESCRIPTION file, no Contains field")
            else pkgs <- strsplit(conts, " ")[[1]]
        }
        else pkgs <- pkgname
        for (curPkg in pkgs) {
            desc <- read.dcf(file.path(curPkg, "DESCRIPTION"), 
                c("Package", "Version"))
            if (installWithVers) {
                instPath <- file.path(lib, paste(desc[1, 1], 
                  desc[1, 2], sep = "_"))
            }
            else instPath <- file.path(lib, desc[1, 1])
            ret <- unlink(instPath, recursive = TRUE)
            if (ret == 0) {
                file.rename(file.path(tmpDir, curPkg), instPath)
            }
            else {
                stop("Can not remove prior installation of package")
            }
        }
        setwd(cDir)
        unlink(tmpDir, recursive = TRUE)
    }

