
#
#  $Id: globals.r,v 1.1 2006/10/17 19:30:39 jgould Exp $
#


## Global constants and functions for lc-ms data analysis



mz.int.factor <- 1e4                          # factor used to convert m/z values to integers
rt.int.factor <- 1e2                          # factor used to convert RT values to integers



integerize <- function (dataset, column.factor.pairs = list ( list (column='mz', factor=mz.int.factor),
                                                              list (column='rt', factor=rt.int.factor) )) {
  # converts m/z and RT (or other listed columns) values to integers
  # this enables reliable merging of datasets, without the problem of testing equality for real numbers
  
  for (p in column.factor.pairs) 
    dataset [, p$column] <- dataset [, p$column] * p$factor
  ## NB: using trunc or as.integer to ensure the rhs above is an integer results in "rounding"
  ##     errors that cause problems later during merge operations

  return (dataset)
}
  


integerize.mz <- function (dataset) {
  integerize (dataset, list (list (column='mz', factor=mz.int.factor)))
}

                        
integerize.rt <- function (dataset) {
  integerize (dataset, list (list (column='rt', factor=rt.int.factor)))
}



floatize <- function (dataset, column.factor.pairs = list ( list (column='mz', factor=mz.int.factor),
                                                            list (column='rt', factor=rt.int.factor) )) {
  # converts integerized m/z and RT (or other listed columns) values to real numbers
  
  for (p in column.factor.pairs) 
    dataset [, p$column] <- dataset [, p$column] / p$factor 

  return (dataset)
}
  


repeated <- function (data) {
  # function returns a boolean vector indicating whether a each row in data is repeated;
  # this is differenent from the 'duplicated' function in that it includes the original
  # row along with the duplicates of that row

  # duplicated identifies the second and later replicates;
  # use duplicated after reversing the order of the rows to find the first occurance
  reverse <- rev ( 1:nrow(data) )
  repeated <- duplicated (data) | duplicated (data[reverse,])[reverse]

  return (repeated)
}

 
