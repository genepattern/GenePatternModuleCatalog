#
#  $Id: peak-match.r,v 1.1 2006/10/17 19:30:40 jgould Exp $
#


library (mclust)


ppm <- function (m) { return (m/1e6) }


ppm.var <- function (y) {
  # calculate ppm variation (range) for values in vector y
  r <-range (y)
  1e6*(r[2]-r[1])/r[2]
}


range.diff <- function (y) {
  # calculate variation (range) for values in vector y
  r <- range (y)
  r[2] - r[1]
}


get.subset <- function (data, start.n, ppm.tol) {
  # extracts and plots subset of 'data', to include all rows with m/z values within
  # ppm.tol of m/z for row 'start.n'
  mz.n <- data [start.n, 'mz']
  x <- data [ data[,'mz'] >= (mz.n - ppm.tol*ppm(mz.n)) & data[,'mz'] <= (mz.n + ppm.tol*ppm(mz.n)), ]
  plot (x[,c('rt','mz')], col=x[,'charge'], pch='+', cex=2, main=t)

  invisible (x)
}



peak.match <-
  function (expt.file, 
            final.table,
            final.matched.table.prefix,
            # m/z strips to process -- used for parallelization of peak matching
            #  (numeric list results in processing only that subset)
            mz.strips.to.process='all',
            parallel.nproc=50,                          # max number of simultaneous processes if master; 1 => serial
                                                        # sub-process id if not master call
            min.strips=100,                             # min m/z strips per sub process
            scratch.dir='LSF',                          # scratch directory prefix for parallelization
            # default mz and rt tolerance calculation
            # OLD: mz.tol.fn=function (x) {median (x,na.rm=T) + 3 * mad (x,na.rm=T)},
            #      rt.tol.fn=function (x) {quantile (x, probs=0.99, na.rm=TRUE)},
            mz.tol.fn=function (x) {boxplot.stats(x)$stats[5]},     # remove outliers beyond 1.5*IQR
            rt.tol.fn=function (x) {boxplot.stats(x)$stats[5]},
            debug=1,                                    # numerical values >= 0; 1=enable, 2=detailed
            # clustering "constants"
            min.clust.size=3,                           # minimum expected number of peaks in each mz or rt cluster
            report.freq=100,                            # print updates after this many mz clusters
            # cluster merging options
            mz.for.merge='mz.mu',                       # 'mz' & 'rt': merge based on tolerance of individual peaks in clusters
            rt.for.merge='rt.mu',                       # 'mz.mu' & 'rt.mu': merge based on cluster centroids
            # normalization
            normalize='tic',                            # normalization method: tic | filtered-tic | none (default)
            # files
            suffix.tic='.tic',                          # file with tic value for normalization
            suffix.final='-final.csv',                  # mass and RT corrected data (output from apply.corrections)
            suffix.matched='-matched.csv',              # after peak matching across all runs
            raw.peaks.file='peaks-all.csv',             # complete list of peaks, before refinement
            peaks.file='peaks-unique.csv',              # unique set of common peaks (features)
            # other
            mz.tol=NULL,                                # input m/z tolerance in ppm; mz.tol.fn ignored if non-NULL
            rt.tol=NULL,                                # input RT tolerance in min; rt.tol.fn ignored if non-NULL
            R.exec=Sys.getenv('R_EXECUTABLE')
            )
{

  # extract list of unique features
  extract.unique.peaks <- function (x) {
    peaks <- unique ( x[, c('final.mz.cluster','final.rt.cluster','charge','mz.mu','rt.mu',
                            'sigma.11','sigma.21','sigma.12','sigma.22')] )
    peaks <- peaks [ sort (peaks[,'mz.mu'],index=TRUE)$ix, ]
    invisible (peaks)
  }

  # check if this is a master peak.match function call, or is call to process a specific subset;
  # any value for mz.strips.to.process other than a numeric vector will result in a master run
  master.call <- ! ( is.numeric (mz.strips.to.process) && is.vector (mz.strips.to.process) )


  if (debug) print (' Peak Matching ...', quote=FALSE)


  if (master.call) { 
    p <- read.csv (final.table, comment.char='')
    p <- floatize (p)


    # extract (matched) landmarks from data
    p.lm <- p [ !is.na(p[,'peptide']), ]
    
    if ( is.null (mz.tol) ) {
      # determine m/z variation (ppm for each peptide and charge state)
      mz.var <-  by (p.lm[,c('mz','charge')], p.lm[,'peptide'],
                     FUN = function (x) {
                       r.z <- by (x[,'mz'], x[,'charge'], FUN=ppm.var)
                       mean (r.z)
                     })
      ## define m/z tolerance function using mz.tol.fn, e.g:
      #  mz.tol.fn <- function (mz.var) {median (mz.var) + 3 * mad (mz.var)}
      #  mz.tol.fn <- function (mz.var) {max (mz.var, na.rm=TRUE)}
      mz.tol <- mz.tol.fn (mz.var)
    }
    if (debug) print ( paste(' M/Z tolerance (ppm):', mz.tol), quote=FALSE )


    if ( is.null (rt.tol) ) {
      # determine RT deviation
      ## define rt tolerance function using rt.tol.fn, e.g:
      #  rt.tol.fn <- sd
      #  rt.tol.fn <- function (rt.var) {quantile (rt.var, rt.tol.pct, na.rm=TRUE)}
      #  rt.tol.fn <- function (rt.var) {max (rt.var, na.rm=TRUE)}
      rt.var <- by (p.lm[,'rt'], p.lm[,'peptide'], range.diff)
      rt.tol <- rt.tol.fn (rt.var)
    }
    if (debug) print ( paste(' RT tolerance (min):', rt.tol), quote=FALSE )


    # sort p by m/z values, determine ppm change between adjacent m/zs
    # and use this for initial m/z cluster assignment; this initial
    # cluster assignment is the minimum number of clusters this list
    # of m/zs can have, given the mz.tol ppm tolerance
    if (debug) print (' Creating m/z slices ... ', quote=FALSE)
    q <- p [ sort (p[,'mz'], index=TRUE)$ix, ]
    ppm.change <- (q[-1,'mz'] - q[,'mz']) * 1e6 / q[,'mz']
    ppm.change <- c ( 0, ppm.change[1:(nrow(q)-1)] )
    mz.cluster <- cumsum ( ppm.change > mz.tol ) + 1
    q <- cbind (q, mz.cluster)
    q <- cbind (q, final.mz.cluster=0, final.rt.cluster=0, mz.mu=0, rt.mu=0,
                sigma.11=0, sigma.12=0, sigma.21=0, sigma.22=0)



    # group different charge states in each m/z (pre-)cluster to ensure
    # different z's are processed independently
    if (debug) print (' Grouping charges ... ', quote=FALSE)
    ppm.change.index <- ppm.change > mz.tol
    ppm.change.index [ppm.change.index==TRUE] <- max (q[,'charge'])
    ppm.change.index[1] <- 1  # start at cluster 1
    # space numbering based on maximum charge, and use charge to create clusters
    mz.cluster <- cumsum (ppm.change.index) + q[,'charge']
    unique.clusters <- unique (mz.cluster)
    # renumber clusters to be consecutive
    for ( i in 1:length(unique.clusters) )
      mz.cluster [ mz.cluster == unique.clusters[i] ] <- i
    q[, 'final.mz.cluster'] <- mz.cluster



    # cluster each of the m/z segments (based on initial cluster assignment using m/z & z values)
    # cluster using both m/z and rt axis simultaneouly
    r <- max (q[,'final.mz.cluster'])
    mz.strips.to.process <- 1:r
    if (parallel.nproc > 1) {
      if (debug) print (' Parallelizing peak matching ... ', quote=FALSE)

      # temp files and directories
      temp.dir <- paste (scratch.dir, '.', Sys.getpid(), sep='')
      dir.create (temp.dir)
      setwd (temp.dir)
      q.file <- paste ('temp-q.', Sys.getpid(), '.csv', sep='')
      r.file.prefix <- paste ('temp-r.', Sys.getpid(), '.r', sep='')
      write.table ( integerize(q), q.file, sep=',', row.names=F, quote=F )

      # parallelize and submit parallel jobs
      n <- ceiling (r / parallel.nproc)
      if ( n < min.strips ) {
        n <- min.strips
        parallel.nproc <- ceiling (r / n)
      }

      for (k in 1:parallel.nproc) {
        strip.min <- (k-1) * n + 1
        strip.max <- min (r, k*n)
        r.file <- paste (r.file.prefix, '.', k, sep='')
        script <- file (r.file, 'w')
        # assemble call to peak.match
        # these args need to be explicitly overridden in the parallel call to peak.match
        args.override <- c ('expt.file', 'final.table', 'final.matched.table.prefix',
                            'mz.strips.to.process', 'parallel.nproc', 'mz.tol', 'rt.tol')
        args.exclude <- c ('mz.tol.fn', 'rt.tol.fn')  # mz.tol and rt.tol are explicitly given
        # the remaining args need to retain their current values
        args.keep <- setdiff (names (formals ()), c (args.override, args.exclude))
        cat ("code.dir <- Sys.getenv ('PROTEOMICS_CODEBASE')\n", file=script)
        cat ("source  ( paste (code.dir, 'lc-ms.r', sep='/') )\n\n", file=script)
        peakmatch.cmd <- paste ('peak.match ("', q.file, '", NULL, NULL, ',
                                'mz.strips.to.process=', strip.min, ':', strip.max, ', ',
                                'parallel.nproc=', k, ', ',
                                'mz.tol=', mz.tol, ', ',
                                'rt.tol=', rt.tol, 
                                sep='')
        cat (peakmatch.cmd, file=script)
        for ( a in 1:length(args.keep) ) {
          a.value <- get ( args.keep[a] )
          if ( is.numeric(a.value) )
            cat (',\n           ', args.keep[a], '=', a.value, file=script, sep='')             # print straight
          else 
            cat (',\n           ', args.keep[a], '="', a.value, '"', file=script, sep='')       # string
          if ( a == length(args.keep) ) cat (')', file=script)
        }

        cat ('\n', file=script)
        close (script)

        cmd <- paste ('bsub -J pepper_peakmatch', R.exec, 'CMD BATCH --vanilla', r.file)
        system (cmd)
      }

      # wait for parallel jobs to finish and assemble results
      while ( as.numeric (system ('bjobs -J pepper_peakmatch | wc -l', intern=TRUE)) > 1 ) Sys.sleep (120)
      q.new <- NULL
      for (k in 1:parallel.nproc) {
        result <- read.csv ( paste (q.file, '.', k, sep=''), comment.char='' )
        q.new <- rbind (q.new, floatize(result))
      }
      q <- q.new

      setwd ('..')
    }
  }


  if ( !master.call || parallel.nproc <= 1 ) {
    if (!master.call) {
      # read and subset intermediate results file
      q <- read.csv (expt.file, comment.char='')
      q <- floatize (q)
      q <- q [ q[,'final.mz.cluster'] >= min (mz.strips.to.process) &
               q[,'final.mz.cluster'] <= max (mz.strips.to.process), ]
    }
    
    if (debug) print (' Clustering m/z and rt axes ... ', quote=FALSE)
    # perturb m/z and rt values -- otherwise, mclust can crash is there are too many identical values
    q.perturb <- q
    q.perturb[,'mz'] <- q[,'mz'] + rnorm ( nrow(q), mean=0, sd=1/(mz.int.factor*100) )
    q.perturb[,'rt'] <- q[,'rt'] + rnorm ( nrow(q), mean=0, sd=1/(rt.int.factor*100) )
    
    for (strip in mz.strips.to.process) {
      if ( debug && ! (strip %% report.freq) ) print ( paste ("   m/z strip:", strip), quote=FALSE )
      rows <- which ( q[,'final.mz.cluster'] == strip )
      if (length(rows)==1) {
        # if strip has single row, no need to cluster
        q [rows, c('final.rt.cluster','mz.mu','rt.mu','sigma.11','sigma.21','sigma.12','sigma.22')] <-
          c (0, q[rows, c('mz','rt')], 0, 0, 0, 0)
      } else {
        maxG <- 1
        if ( ppm.var (q[rows,'mz']) > mz.tol ||
            range.diff (q[rows,'rt']) > rt.tol ) {
          # only 1 cluster is expected if BOTH m/z and rt are within tolerance
          # further, when there are enough data points, too many clusters can be problematic
          # for every factor of 10 increase in data points, increase min.clust.size proportionately
          clust.size.adjustment <- ceiling (log10 (length(rows)/ min.clust.size))
          clust.size <- min.clust.size * max (clust.size.adjustment, 1)
          maxG <- max ( round (length(rows)/clust.size), 1 )
        }
        model <- Mclust ( q.perturb[rows, c('mz','rt')], minG=1, maxG=maxG )
        if (debug >= 2) print ( paste ("   m/z strip:", strip, "clusters:", model$G), quote=FALSE )
      
        q[rows,'final.rt.cluster'] <- model$classification
        q[rows,'mz.mu'] <- model$mu [ 1, model$classification ]
        q[rows,'rt.mu'] <- model$mu [ 2, model$classification ]
        # set sigma
        for (i in 1:length(rows))
          q[rows[i], c('sigma.11','sigma.21','sigma.12','sigma.22')] <-
            as.vector ( model$sigma [,,model$classification[i]] )
  

        # iteratively group clusters if the ACTUAL m/z AND rt values of the clusters
        # are within m/z and rt tolerances, respectively -- this avoids unwarranted
        # splitting of clusters;
        # implementation note: use the q [rows,] table directly to  merge clusters
        clusters.init <- unique (model$classification)    # cluster number may not be consecutive
        while (! is.null(clusters.init) ) {
          cluster <- clusters.init[1]
          if (length(clusters.init) == 1) {
            # no more clusters to combine ... done!
            clusters.init <- NULL
            next
          }
          clusters.close <- cluster
          clusters.far <- NULL
          rows.1 <- rows [ q[rows,'final.rt.cluster'] == cluster ]
          for ( i in 2:length(clusters.init) ) {
            k <- clusters.init[i]
            rows.2 <- rows [ q[rows,'final.rt.cluster'] == k ]
            if ( ppm.var ( q [c(rows.1,rows.2), mz.for.merge] ) <= mz.tol &&
                 range.diff ( q [c(rows.1,rows.2), rt.for.merge] ) <= rt.tol )
              clusters.close <- c (clusters.close, k)
            else
              clusters.far <- c (clusters.far, k)
          }
          clusters.init <- clusters.far

          # combine clusters that are "close"
          if ( length(clusters.close) > 1 ) {
            if (debug >= 2) print ( paste ("    combining clusters", paste (clusters.close, collapse=' ')),
                                    quote=FALSE )
            subset.rows <- rows [ q [rows,'final.rt.cluster'] %in% clusters.close ]
            submodel <- Mclust ( q.perturb[subset.rows, c('mz','rt')], minG=1, maxG=1 )
            q[subset.rows,'final.rt.cluster'] <- clusters.close[1]
            q[subset.rows,'mz.mu'] <- submodel$mu [ 1, submodel$classification ]
            q[subset.rows,'rt.mu'] <- submodel$mu [ 2, submodel$classification ]
            # set sigma
            for (j in subset.rows)
              q[j, c('sigma.11','sigma.21','sigma.12','sigma.22')] <-
                as.vector ( submodel$sigma [,,submodel$classification[1]] )
            # add combined cluster to clusters.init
            clusters.init <- c (clusters.init, clusters.close[1])
          }
        }
      }
    }

    if (!master.call) {
      # write out intermediate results and quit
      result.file <- paste (expt.file, '.', parallel.nproc, sep='')
      write.table ( integerize(q), result.file, sep=',', row.names=F, quote=F )
      return ()
    }
  }
  
  write.table (q, raw.peaks.file, sep=',', row.names=F, quote=F)


  peaks <- extract.unique.peaks (q)
  write.table (peaks, peaks.file, sep=',', row.names=F, quote=F)

  
  # read sample information file
  sample.info <- read.csv (expt.file, comment.char='')
  files <- unlist (lapply (sample.info[,'experiment'], toString))
  sample.names <- unlist (lapply (sample.info[,'sample'], toString))
  cls <- unlist (lapply (sample.info[,'class'], toString))

  
  # propagate mz and rt clustering to all runs
  if (debug) print (' Creating matched data tables ... ', quote=FALSE)
  for (f in files) {
    if (debug) print ( paste ('  ', f), quote=FALSE)
    data.file <- paste (f, '/', f, suffix.final, sep='')
    data <- read.csv (data.file, comment.char='')
    data <- floatize (data)

    data.new <- merge (data, q, by=colnames(data))
    data.new <- merge (data.new[, c(setdiff(colnames(q),colnames(peaks)),'final.mz.cluster','final.rt.cluster')],
                       peaks, by=c('final.mz.cluster','final.rt.cluster'), all.y=TRUE)
    # NB: for the above merge, charge does not need to be explicitly taken into account,
    #     since final.mz.cluster takes both m/z and charge into account during (pre-)clustering
    data.matched <- NULL
    match.by.columns <- c ('mz.mu', 'rt.mu', 'charge')
    dup <- repeated (data.new[ , match.by.columns])
    dup.data <- data.new [ dup, ]
    by (dup.data, dup.data[ , match.by.columns],
        function (x) {
          row <- cbind ( mz=x[1,'mz.mu'], rt=x[1,'rt.mu'], charge=x[1,'charge'],
                         intensity=sum(x[,'intensity'],na.rm=TRUE), x[1,c('actualmz','peptide')] )
          data.matched <<- rbind (data.matched, row)
        })
    unique.data <- data.new [!dup, c('mz.mu','rt.mu','charge','intensity','actualmz','peptide')]
    colnames (unique.data) <- c ('mz','rt','charge','intensity','actualmz','peptide')
    data.matched <- rbind (data.matched, unique.data)

    data.matched [ is.na (data.matched [,'intensity']), 'intensity' ] <- 0

    write.table (data.matched, paste(f,'/',f,suffix.matched,sep=''), sep=',', row.names=FALSE, quote=FALSE)
  }


  # combine all matched runs to create final matched table
  if (debug) print (' Merging tables to create final matched table ... ', quote=FALSE)
  matched.table <- NULL
  for ( i in 1:length(files) ) {
    if (debug) print ( paste ('  ', files[i]), quote=FALSE)
    data.file <- paste (files[i], '/', files[i], suffix.matched, sep='')
    data <- read.csv (data.file, comment.char='')
    if ( is.null(matched.table) ) {
      matched.table <- data [, c('mz','rt','charge','peptide','intensity')]
    } else {
      matched.table <- merge (matched.table, data [, c('mz','rt','charge','peptide','intensity')],
                              by=c('mz','rt','charge'), all.x=TRUE)
      # merge peptide ids -- so that NAs are replaced by identities, if known
      matched.table [, 'peptide.x'] <- apply (matched.table [,c('peptide.x','peptide.y')], MARGIN=1,
                                              FUN=function (x) {
                                                ids <- setdiff ( unique (unlist (x)), NA )
                                                if (length (ids) > 1) {
                                                  msg <- paste ('Multiple peptide ids assigned to m/z:', paste (ids, collapse=','))
                                                  if (debug) print ( paste ('   ', msg) )
                                                  warning (msg)
                                                  ids <- ids[1]  # (arbitrarily) select the first peptide
                                                }
                                                ifelse (length(ids)==0, NA, ids)
                                              })
      # rename peptide.x (to peptide) and drop peptide.y
      keep <- which ( colnames (matched.table) == 'peptide.x' )
      colnames (matched.table) [keep] <- 'peptide'
      matched.table <- matched.table [ , setdiff (colnames (matched.table), 'peptide.y') ]
    }
  }

  colnames (matched.table) <- c ('mz','rt','charge','peptide', sample.names)
  for (x in sample.names)
    matched.table [ is.na (matched.table [,x]), x ] <- 0


  # normalization
  if (debug) print (' Normalizing sample intensities ... ', quote=FALSE)
  if (normalize=='tic') {
    # normalize to tic calculated using ALL detected peaks (including those with no isotope pattern)
    if (debug) print ('   ... normalization method: tic', quote=FALSE)
    tic <- NULL
    for (f in files)
      tic <- c (tic, scan ( paste (f, '/', f, suffix.tic, sep=''), what=double(0), n=1 ))
    norm.factor <- mean (tic) / tic 
  } else if (normalize=='filtered-tic') {
    # normalize samples so that the total intensity is the same (= mean intensity) for all samples
    if (debug) print ('   ... normalization method: filtered-tic', quote=FALSE)
    total.intensity <- apply (matched.table[,sample.names], MARGIN=2, FUN=sum)
    mean.sample.intensity <- mean (total.intensity)
    norm.factor <- mean.sample.intensity / total.intensity
  } else {
    # no normalization
    if (debug) print ('   ... normalization method: none', quote=FALSE)
    norm.factor <- rep (1, length(sample.names))
  }

  norm.matrix <- t ( replicate (nrow(matched.table), norm.factor) )
  matched.table[,sample.names] <- matched.table[,sample.names] * norm.matrix
  write.table (norm.factor, paste (final.matched.table.prefix,'.norm',sep=''), col.names='norm.factor')


  write.table (matched.table, paste(final.matched.table.prefix,'.csv',sep=''),
               sep=',', row.names=FALSE, quote=FALSE)
  matched.table [,'mz'] <- paste ('mz', matched.table[,'mz'], sep='')
  matched.table [,'rt'] <- paste ('rt', matched.table[,'rt'], sep='')
  matched.table [,'charge'] <- paste ('z', matched.table[,'charge'], sep='')
  name <- unlist (lapply (1:nrow(matched.table),
                          function (x) { paste (as.vector (matched.table[x,c('mz','rt','charge')]), collapse='-') }))
  matched.gct <- cbind (Name=name, Description=matched.table[,'peptide'], matched.table[,sample.names])
  write.gct (matched.gct, paste (final.matched.table.prefix,'.gct',sep=''))
  write.cls (cls, paste (final.matched.table.prefix,'.cls',sep=''))
}
