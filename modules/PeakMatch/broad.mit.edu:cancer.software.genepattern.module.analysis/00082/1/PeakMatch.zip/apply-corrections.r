
#
#  $Id: apply-corrections.r,v 1.1 2006/10/17 19:30:39 jgould Exp $
#



apply.corrections <-
  function (expt.file,                              # file with sample / run information    
            final.table,                            # file to which final corrected table is written to
            threshold=FALSE,                            # intensity threshold
            intensity.threshold=0.001,                  # threshold at 0.1% of max intensity
            # RT correction
            rt.correction.fit='lm',                     # loess or lm
            loess.span=0.15,                            # smoothing span for loess fitting
            # file name suffixes
            suffix.data='.csv',                         # mapquant output data
            suffix.out='-lm.csv',                       # mass corrected (mapquant output) data, thresholded
            suffix.cal='.coef',                         # mass calibration equation
            suffix.globm='.matches.global',             # global landmark matches after dup assignments are resolved
            suffix.globm.bak='.matches.global.bak',     # saved global landmark matches output from LM program
            suffix.final='-final.csv',                  # mass and RT corrected (mapquant output) data, thresholded
            # whether to use landmarks or not (or to call peak matching with absolute tolerances)
            use.landmarks=TRUE
            )
{

  apply.mass.correction <- function (data.file, out.file, calibration.coeffs) {
    # apply mass calibration/correction specified in calibration.coeffs to mz values
    # in data.file and write out result to out.file


    read.calibration.coefficients <- function (file.name) {
      # read calibration coeffients [ c0 c1 c2] from file
      f <- file (file.name, 'r')
      line <- readLines (f, n=1)
      line.clean <- sub ('\\]', '', sub ('\\[', '', line))          # remove [ ... ]
      line.clean <- sub ('\ *$', '', sub ('^\ *', '', line.clean))  # remove leading and training blanks
      line.clean <- sub ('\ +', ' ', line.clean)                    # replace multiple spaces with single space
      close (f)
      
      coeffs <- as.real (strsplit (line.clean, split=' ')[[1]])
      
      # calibration coefficients
      c0 <- coeffs[1]
      c1 <- coeffs[2]
      c2 <- coeffs[3]
      
      return (list (c0=c0, c1=c1, c2=c2))
    }

  
    data <- read.csv (data.file, comment.char='')
    eqn <- read.calibration.coefficients (calibration.coeffs)

    # mass correction
    mz <- data [, 'mz']
    mz.int <- mz * mz.int.factor
    correction <- (eqn$c0 + eqn$c1 * mz.int + eqn$c2 * mz.int * mz.int) / mz.int.factor
    mz.corrected <- mz - correction
    data [, 'mz'] <- round (mz.corrected * mz.int.factor)
    write.table (data, out.file, sep=',', row.names=FALSE, quote=FALSE)
    
    invisible (data)
  }



  files <- unlist (lapply (read.csv (expt.file, comment.char='')[,'experiment'], toString))


  if (! use.landmarks) {
    # ignore landmarks (or landmarks not available)
    # write out necessary files for peak matching to run with absolute m/z and RT tolerances
    for ( i in 1:length(files) ) {
      f = files[i]
      print ( paste (' ...', f), quote=FALSE )
      data.file <- paste (f, '/', f, suffix.data, sep='')

      data <- read.csv (data.file, comment.char='')
      data.i <- integerize (data)
      data.i <- cbind (data.i, actualmz=NA, peptide=NA)

      write.table (data.i, paste(f,'/',f,suffix.final,sep=''), sep=',', row.names=FALSE, quote=FALSE)
      if (i == 1)  write.table (data.i, final.table, sep=',', row.names=FALSE, quote=FALSE )
      else         write.table (data.i, final.table, sep=',', row.names=FALSE, col.names=FALSE, quote=FALSE, append=TRUE)
    }

    return ()
  }
      
      

  #
  # scan each global landmark matches file and resolve duplicate assignments (if any)
  # by selecting the landmark closest (in m/z) to the actual peptide m/z;
  # also resolve duplicate peptide ids (identical z, hence close m/z) to the
  # most intense peptide  
  #
  print (' Resolving duplicate assignments ...', quote=FALSE)
  for (f in files) {
    lm.file <- paste (f, '/', f, suffix.globm, sep='')
    lm.bak.file <- paste (f, '/', f, suffix.globm.bak, sep='')
    
    lm.f <- ifelse ( file.exists(lm.bak.file), lm.bak.file, lm.file )
    orig <- read.table (lm.f, header=FALSE, comment.char='' )
    # duplicate m/zs
    new1 <- NULL
    ignore <- by (orig, orig[,1],
                  FUN=function (y) {
                    if ( nrow(y) > 1 ) new1 <<- rbind (new1, y [which.min (abs (y[,1] - y[,4])), ])
                    else new1 <<- rbind (new1, y)
                    return (0)
                  })
    
    # duplicate peptides (with same charge)
    new2 <- NULL
    ignore <- by (new1, new1[,5:6],
                  FUN=function (y) {
                    if ( nrow(y) > 1 ) new2 <<- rbind (new2, y [which.max (y[,3]), ])
                    else new2 <<- rbind (new2, y)
                    return (0)
                  })
          
    if (! file.exists(lm.bak.file) )
      file.rename (lm.file, lm.bak.file)
    write.table (new2, lm.file, sep='\t', row.names=FALSE, col.names=FALSE, quote=FALSE)
  }



  # MASS CORRECTION
  # for each MS scan:
  #  1. apply mass correction
  #  2. identify landmarks in mass corrected data
  #     (by matching mass corrected mzs in data and "global-matches" file
  print (' Mass correction ...', quote=FALSE)
  for (f in files) {
    print ( paste (' ...', f), quote=FALSE )
    data.file <- paste (f, '/', f, suffix.data, sep='')
    out.file <- paste (f, '/', f, suffix.out, sep='')
    calibration.coeffs <- paste (f, '/', f, suffix.cal, sep='')
    
    data <- apply.mass.correction (data.file, out.file, calibration.coeffs)
    if (threshold) {
      max.intensity <- max (data[,'intensity'], na.rm=T)
      data <- data [ data[,'intensity'] > max.intensity * intensity.threshold, ]
    }
    
    lm.file <- paste (f, '/', f, suffix.globm, sep='')
    lm <- read.delim (lm.file, header=FALSE, comment.char='')
    colnames (lm) <- c ('mz', 'rt', 'intensity', 'actualmz', 'charge', 'peptide')
    
    data.lm <- merge (data, lm, by=c ('mz','rt','intensity','charge'), all.x=T)
    write.table (data.lm, out.file, sep=',', row.names=FALSE, quote=FALSE)
  }



  # RT CORRECTION
  # pick a base MS scan (use first scan)
  # for every other scan:
  #  1. compute RT correction model using: rt.base ~ f (rt, rt^2)
  #  2. apply RT correction to scan using this model: rt.new ~ f (rt, rt^2)
  print (' Retention time correction ...', quote=FALSE)
  base <- files[1]
  rest <- setdiff (files, base)
  
  base.file <- paste (base, '/', base, suffix.out, sep='')
  data.base <- read.csv (base.file, comment.char='')
  data.base.lm <- data.base [ !is.na (data.base[,'actualmz']), ]

  data.base.i <- integerize.rt (data.base)
  write.table (data.base.i, paste(base,'/',base,suffix.final,sep=''), sep=',', row.names=FALSE, quote=FALSE)
  write.table (data.base.i, final.table, sep=',', row.names=FALSE, quote=FALSE )

  rest.new <- NULL
  base.old <- NULL
  while ( ! is.null(rest) ) {
    base.old <- c (base.old, base)
    for (f in rest) {
      data <- read.csv ( paste (f, '/', f, suffix.out, sep=''), comment.char='' )
      data.lm <- data [ !is.na (data[,'actualmz']), ]
      # compute average rt for multiple elutions of the same peptide
      # this significantly improves fit and reduces error
      common.landmarks <- merge (data.base.lm, data.lm, by=c('actualmz','peptide'), suffixes=c('.base',''))
      if ( nrow (common.landmarks) > 2 ) {
        print ( paste (' ...', f, '[ base:', base, 'common:', nrow(common.landmarks), ']' ), quote=FALSE )
        minimal.landmarks <- aggregate ( common.landmarks [, c('rt.base', 'rt')],
                                         by = common.landmarks [, c('actualmz', 'peptide')],
                                         FUN=function (x) {
                                           ifelse ( length (boxplot.stats(x)$out) > 0, NA,  mean(x) )
                                         } )
        # eliminate landmarks with outlier rt values
        minimal.landmarks <- minimal.landmarks [ !is.na (minimal.landmarks[,'rt.base']) &
                                                 !is.na (minimal.landmarks[,'rt']), ]
        if (rt.correction.fit == 'loess')
          fit <- loess (rt.base ~ rt, data = minimal.landmarks, family='symmetric', degree=1,
                        span=loess.span, control=loess.control(surface='direct', iterations=100))
        else
          fit <- lm ( rt.base ~ rt + I(rt*rt), data=minimal.landmarks )
        rt.new <- predict (fit, data)
        data [, 'rt'] <- round (rt.new, digits=2)

        data.i <- integerize.rt (data)
        write.table (data.i, paste(f,'/',f,suffix.final,sep=''), sep=',', row.names=FALSE, quote=FALSE)
        write.table (data.i, final.table, sep=',', row.names=FALSE, col.names=FALSE, quote=FALSE, append=TRUE)
      } else {
        rest.new <- c (rest.new, f)
      }
    }

    bases <- setdiff ( files, c(base.old,rest.new) )
    if (length (bases) <= 1) {
      for (f in rest.new) {
        warn <- paste ('===== No common landmarks for', f, '=====') 
        warning (warn)
        print (warn, quote=FALSE)
        
        data <- read.csv ( paste (f, '/', f, suffix.out, sep=''), comment.char='' )
        data.i <- integerize.rt (data)
        write.table (data.i, paste(f,'/',f,suffix.final,sep=''), sep=',', row.names=FALSE, quote=FALSE)
        write.table (data.i, final.table, sep=',', row.names=FALSE, col.names=FALSE, quote=FALSE, append=TRUE)
      }
      break
    }
    
    base <- sample (bases, 1)
    rest <- rest.new
    rest.new <- NULL

    base.file <- paste (base, '/', base, suffix.out, sep='')
    data.base <- read.csv (base.file, comment.char='')
    data.base.lm <- data.base [ !is.na (data.base[,'actualmz']), ]
  }
}
