
# $Id: lc-ms.r,v 1.1 2006/10/17 19:30:40 jgould Exp $


# source files for LC-MS proteomics processing
code.dir <- Sys.getenv ('PROTEOMICS_CODEBASE')
if ( code.dir == "" )
  stop ('PROTEOMICS_CODEBASE not set in environment.')

files <- c ('globals.r',
            'apply-corrections.r',
            'peak-match.r',
            'util.r')
for (f in files)
  source ( paste (code.dir, f, sep='/') )
