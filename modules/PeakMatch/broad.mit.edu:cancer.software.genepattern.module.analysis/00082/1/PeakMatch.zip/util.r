
# $Id: util.r,v 1.1 2006/10/17 19:30:40 jgould Exp $


write.gct <- function (data, file, ...) {
  # write out gct file
  version <- '#1.2'
  size <- dim (data)
  size[2] <- size[2] - 2  # adjust for "Name" & "Description"
  write.table (version, file, quote=FALSE, sep='\t', row.names=FALSE, col.names=FALSE)
  write.table (rbind(size), file, append=TRUE, quote=FALSE, sep='\t',
               row.names=FALSE, col.names=FALSE, ...)
  write.table (data, file, append=TRUE, quote=FALSE, sep='\t', row.names=FALSE, ...)
}


write.cls <- function (cls, file) {
  # write out cls file
  classes <- unique (cls)

  line1 <- c ( length(cls), length(classes), 1 )
  line2 <- paste ( '#',
                   paste (classes, collapse=" ") )

  for ( i in 1:length(classes) )
    cls [ cls==classes[i] ] <- i-1

  write.table (rbind(line1), file, quote=FALSE, row.names=FALSE, col.names=FALSE)
  write.table (line2, file, append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)
  write.table (cls, file, eol=' ', append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)  # single line
  write.table ('', file, append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)            # end above line 
}

