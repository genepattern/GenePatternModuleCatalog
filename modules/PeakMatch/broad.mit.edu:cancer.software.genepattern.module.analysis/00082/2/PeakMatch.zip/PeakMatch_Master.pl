#!/usr/bin/perl

#
# PeakMatch setup/run script for integrating with GenePattern.
#

use strict;
use File::Copy;

use vars qw ($opt_d $opt_c $opt_p $opt_s $opt_o $opt_l $opt_n $opt_r $opt_b $opt_m $opt_t);
use Getopt::Std;


my $peakList;						# peak list zip file
my $sampleInfo;						# sample info file (contains experiment name, sample, class)
my $lmatchoutput;					# zip file output from landmark matching
my $outputprefix;                                       # output file prefix <P> -- will create <P>.csv, <P>-matched.{csv|gct|cls}
my $Rcmd;                                               # command for running and R function in a script file
my $R;                                                  # command for directly executing R
my $batchCmd;                                           # command for invoking parallel execution
my $expt;						# experiment name
my $installDir;						# install directory containing programs and libraries
my $libPath;						# library path for a specific operating system
my $OS;							# operating system
my $nproc;                                              # number of parallel processes (run sequentially if 1)
my $nprocdefault=1;
my @tmp;						# temporary array
my @experiments;					# experiment name array
# peak matching without landmark matching -- the following options are used when $lmatchoutput is not specified;
# if $lmatchoutput is specified, these options are ignored
my $mztolerance;                                        # absolute m/z tolerance in ppm
my $rttolerance;                                        # absolute RT tolerance in minutes
my $mztolerancedefault=10;                              # defaults to 10 ppm
my $rttolerancedefault=2;                               # defaults to 2 minutes

my $peakDir = "PEAK_LIST";
my $matchDir = "MATCH_DATA";
my $ticfileext = ".tic";

my @Rlibs=("mclust_2.1-8");                                            # list of R libs to be installed
my @RlibFiles=();                                                     # list of actual files containing libraries (updated in setupOS)
my $rscript="run-peak-match.r";						# R script for peak matching
my $uselandmarks="TRUE";                                                # if lmatchoutput is not present set to FALSE


#
# command line options
#  -d installDir -c OS
#  -p peakList -s sampleInfo -o outputprefix -l lmatchoutput
#  -n nproc -r Rcmd -b batchCmd -m mztolerance -t rttolerance
#

getopts ('d:c:p:s:o:l:n:r:b:m:t:');
if ( !defined ($opt_d) || !defined ($opt_c) || !defined ($opt_p) || 
     !defined ($opt_s) || !defined ($opt_o) || !defined ($opt_r) ) {
  print "PeakMatch_Master.pl  -d installDir -c OS  -p peakList -s sampleInfo -o outputprefix [-l lmatchoutput]\n";
  print "                     [-n nproc] -r Rcmd [-b batchCmd -m mztolerance -t rttolerance]\n";
  exit;
}

$installDir = $opt_d;
$OS = $opt_c;
$peakList = $opt_p;


$sampleInfo = $opt_s;
$outputprefix = $opt_o;
$Rcmd = $opt_r;
# use defaults for unspecified arguments
if (!defined ($opt_l)) {
  # if landmatch output is not available, set up code for peak matching with absolute tolerances
  undef $lmatchoutput;
  $uselandmarks = "FALSE";
  $mztolerance = defined ($opt_m) ? $opt_m : $mztolerancedefault;
  $rttolerance = defined ($opt_t) ? $opt_t : $rttolerancedefault;
} else {
  $lmatchoutput = $opt_l;
  $mztolerance = "NULL";
  $rttolerance = "NULL";
}

if (!defined ($opt_n)) { $nproc = $nprocdefault; } else { $nproc = $opt_n; }

$batchCmd = $opt_b;
if ($batchCmd eq "no") { 
	undef $batchCmd; 
} else { 
	$batchCmd = "bsub �K �o lsf_log.txt"; 
}

if (!defined ($batchCmd) || $batchCmd !~ /bsub/) {
  # the peak match module only supports LSF (using the bsubs/bjobs commands) for parallelism,
  # and the use of bsub/bjobs is currently hard coded into the peak match code;
  # bsub/bjobs will NOT be invoked (and the job is run sequentially) if $nproc == 1
  $nproc = $nprocdefault;
}


# extract location of R_HOME
$_ = $Rcmd;
/-DR_HOME=([^ ]+)/;
$R = "$1/bin/R";
$R =~ tr!\\!/!;
print "R executable is: $R\n";


# on windows gene pattern returns the path with "\" we need to convert it to
# "/" to work properly elsewhere
print "peak match module install dir: $installDir\n";
$installDir =~ tr!\\!/!;

print "operating system: $OS\n";
# unzip/install peak match module according to the specific operating system
$libPath = &setupOS ($OS, $installDir);
print "library path: $libPath\n";


# set up files and directories
@experiments = getExptList ($sampleInfo);
checkExpts ($matchDir, \@experiments);
extractPeakListToCSV ($peakDir, $matchDir, \@experiments);



# create and run R script for peak matching;
# the script installs libraries if they are not already installed
# the R script has several hacks to get it to work in both unix and windows
my $rlibfilelist = join ", ", @RlibFiles;
open (SCRIPT, ">$rscript") || die "cannot create script file $rscript\n";
print SCRIPT <<EOF;

Sys.putenv (PROTEOMICS_CODEBASE="$installDir", R_EXECUTABLE="$R")

run <- function (run.dir) {
  if (! require (mclust)) {
    install.packages ( pkgs=c($rlibfilelist), lib="$libPath", CRAN=NULL )
    library (mclust, lib.loc="$libPath")
  }

  setwd (run.dir)

  code.dir <- Sys.getenv ('PROTEOMICS_CODEBASE')
  source ( paste (code.dir, 'lc-ms.r', sep='/') )


  apply.corrections ("$sampleInfo", "$outputprefix.csv", use.landmarks=$uselandmarks)
  peak.match ("$sampleInfo", "$outputprefix.csv", "$outputprefix-matched", parallel.nproc=$nproc, mz.tol=$mztolerance, rt.tol=$rttolerance, debug=2)
}

run ("$matchDir")

EOF
close (SCRIPT);

# the R script is run from $matchDir -- copy necessary files to and from here
copy ($sampleInfo, "$matchDir/$sampleInfo");
system "$R CMD BATCH --vanilla --quiet $rscript";
my @outputfiles = ("$outputprefix-matched.gct", "$outputprefix-matched.cls");
foreach my $f (@outputfiles) {
  copy ("$matchDir/$f", $f);
}



###############################################################
                      # FUNCTIONS #
###############################################################

sub setupOS {
  my $OS = shift;
  my $installDir = shift;
  my $unzipStr;	                    # unzip path
  my $lib;	         	    # R lib path (for installed libs)
  my $libzip;                       # zip file with library packages
  my $libpkg;                       # location of R packages
  my $now;                          # current time

  my $Rlib;


  # NB: libR/ contains two subdirectories: packages with win and linux packages
  #     and library, for the installed R libraries

  $libzip = $installDir."libR.zip";
  $libpkg = $installDir."libR/packages";
  $lib = $installDir."libR/library";

  print "setting up files and directories...\n";

  if ($OS =~ /[Ww]indows/) {
    # assumes running on Windows machine to run the executable unzip.exe
    $unzipStr = $installDir."unzip.exe";

    # unzip libR files and install R packages -- do this every time
    #  (module install check does not work properly on windows)
    print "installing Peak Match Module for $OS...\n";

    # unzip the library files
    system "$unzipStr $libzip -d $installDir";


    # set up library installs (used only if needed)
    foreach $Rlib (@Rlibs) {
      push @RlibFiles, "\"$libpkg/$Rlib.zip\"";
    }

    # unzip peak files 
    system "$unzipStr $peakList -d $peakDir";

    # unzip landmark match files
    if (defined ($lmatchoutput)) {
      system "$unzipStr $lmatchoutput";
    }

    return ($lib);

  } elsif($OS =~ /[Ll]inux/) {

    # unzip libR files and install R packages -- do this every time
    #  (module install check does not work properly on windows)
    print "installing Peak Match Module for $OS...\n";

    # unzip the library files
    system "unzip $libzip -d $installDir";


    # set up library installs (used only if needed)
    foreach $Rlib (@Rlibs) {
      push @RlibFiles, "\"$libpkg/$Rlib.tar.gz\"";
    }

    # unzip peak files
    system "unzip $peakList -d $peakDir";

    # unzip landmark match files
    if (defined ($lmatchoutput)) {
      system "unzip $lmatchoutput";
    }

    return ($lib);

  } else {
		die "It appears your operating system is not supported - sorry.\n";
  }
}



###############################################################
sub getExptList {
  # reads sample infor file and extracts list of experiment names

  my $sampleInfo = shift;
  my @retlist = ();

  open (SAMPLEINFO, $sampleInfo) || die ("getExptList: cannot open sample info file $sampleInfo\n");
  while (<SAMPLEINFO>) {
    chomp;
    if ($. != 1) {
      # skip header line
      @tmp = split /,/, $_;
      push @retlist, $tmp[0];
    }
  }
  close (SAMPLEINFO);

  return (@retlist);
}


###############################################################
sub checkExpts {
  # checks to see if the experiment subdirectories exist

  my ($matchDir, $exptRef) = @_;
  my $dir;

  if (! -d $matchDir) {
    print "creating directory $matchDir ...\n";
    mkdir $matchDir;
  }

  foreach $expt (@$exptRef) {
    $dir = "$matchDir/$expt";
    if (! -d $dir) {
      print "creating directory $dir ...\n";
      mkdir $dir;
    }
  }
}


###############################################################
sub extractPeakListToCSV {

  # moves peak list files to the appropriate subdirectories
  # extracts charge-identified peaks from peak list file (in generic pgr format)
  # expects peak list files to be named <expt-run>.pgr, and creates new csv file <expt-run>.csv
  # also calculates TIC

  my ($peakDir, $matchDir, $exptRef) = @_;

  foreach $expt (@$exptRef) {
    my $pgr_file = "$peakDir/$expt.pgr";
    my $out_file = "$matchDir/$expt/$expt.csv";

    print STDOUT "extractPeakListToCSV: processing file $pgr_file ... \n";
    open (PGR, $pgr_file) || die (" ... cannot open file $pgr_file.\n");

    open (OUT, ">$out_file") || die ("extractPeakListToCSV: cannot open output file $out_file\n");
    print OUT "mz,rt,charge,intensity\n";

    my $tic = 0;
    while (<PGR>) {
      chomp;
      if ($. != 1) {
	# skip first line (header)
	my ($feature, $mz, $rt, $z, $abund, $mz_err, $rt_err, $carbons) = split (/\t/);
	$tic = $tic + $abund;
	if ($z >= 1) {
	  print OUT "$mz,$rt,$z,$abund\n";
	}
      }
    }
    close (PGR);
    close (OUT);

    # write out TIC
    my $tic_file = "$matchDir/$expt/$expt.tic";
    open (TIC, ">$tic_file") || die ("extractPeakListToCSV: cannot open file $tic_file\n");
    print TIC "$tic\n";
    close (TIC);
  }
}
