use warnings;
use File::Basename;
use Getopt::Long;


GetOptions (\%options,
        "inputfilelist:s", # a file containing a list of input file paths
);


if(-e $options{inputfilelist})
{
    open(FILELIST, "<", $options{inputfilelist}) or die("Could not open file: $options{inputfilelist}");

    $count = 1;
    foreach my $file (<FILELIST>)
    {
        chomp $file;
        if(-e $file)
        {
            my $newfile = basename($file);
            #create symlink to file

            #first check if $newfile already exists
            my $tmpfile = $newfile;
            while(-e $tmpfile)
            {
                $tmpfile = $count."_".$newfile;
                $count = $count++;
            }

            $newfile = $tmpfile;

            $linkCreated = link $file,$newfile;

            if(!$linkCreated)
            {
                print "\nUnable to create a hard link to file: $file. Creating symlink instead.\n";

                $symlinkCreated = symlink $file,$newfile;
                wr_die("\nUnable to create a symlink to file: $file.\n") unless $symlinkCreated;
            }
        }
        else
        {
            wr_die("\nFile does not exist: $file")
        }
    }

    close(FILELIST) or warn "close failed $!";
}
else
{
    wr_die("File does not exist: $options{inputfilelist}")
}


sub wr_die
{
    print STDERR @_, "\n\n";
    exit(1);
}
