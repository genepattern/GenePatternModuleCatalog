use strict;
use File::Basename;


my $cn = shift; # xcn file
open(CN, "< $cn") or die("Cannot open input file $cn: $!\n");

my $outfile = shift;
open(OUTPUT,"> $outfile") or die("$!\n");



my @header_xcn = split(/\t/,<CN>);
my @columnSize_xcn = @header_xcn[3..$#header_xcn];
my $colxcn =  $#columnSize_xcn+1;
my %cols_xcn;
my %scans_xcn;

print OUTPUT "SNP\tChromosome\tLocation";

foreach my $head (@columnSize_xcn) {
chomp($head);
print OUTPUT "\t$head\t$head";
print OUTPUT " Call";
}
print OUTPUT "\n";

my $linecount = 0;

my ($name,$dir,$extension) = fileparse($cn,'\..*');

while (<CN>) {
    chomp;
    $linecount = $linecount + 1;
    my ($gene,$chr,$loc,@row) =split(/\t/,$_);

    if(length($gene)==0 || length($chr)==0
        || length($loc) == 0 || scalar(@row) == 0)
    {
        print STDERR "Error parsing line $linecount: line length smaller than expected.";

        if($linecount == 1 || $extension ne ".cn")
        {
            print STDERR "\nPlease check that the input is a valid CN file.";
        }

        exit(1);
    }
    
    print OUTPUT "$gene\t$chr\t$loc";
   
 
    foreach my $sample ( @row) {
      print OUTPUT "\t$sample\tNoCall";


    }
    print OUTPUT "\n";
    
 
 }   
