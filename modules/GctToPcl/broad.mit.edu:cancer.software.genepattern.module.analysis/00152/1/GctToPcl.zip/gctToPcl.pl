#!/usr/bin/perl
#
# pclToGct.pl
#
# Author: Jeremy Hubble, Stanford University
# Date: 25 July 2008
# Purpose: Convert a .gct to a .pcl file 
#
# Description: This converts a pcl file to a gct file. The two formats are
#    quite similar, thus the main action is simply to rearrange the data in 
#    the new format. Since the .gct format does not support weights, the .pcl
#    will have all weights set to 1.  (Thus a weighted .pcl file converted to 
#    .gct and back to .pcl will be slightly different.)
#
#    When run on the command line, multiple .gct files can be specified to convert
#    in batch.  When done in batch mode, the output .pcl file will have the same
#    filename, with the extension changed to .pcl.  Alternative, an output file
#    can be explicitly specified on the command line using the -o option.  When
#    this is done, the following pcl file will be output to the new filename.
#
# .pcl Format:
# Columns: Name \t  Descript \t  GWEIGHT   \t  experiments ....
# Rows:
# Headers
# EWEIGHT
# genes...
#
use strict;
my @gct = @ARGV;
use Cwd;
use File::Basename;
my $dir = getcwd;

unless (@gct) {
	print "USAGE: $0 .gct_file...\n";
	print " or $0 -o outputfile .pclfile\n";
	print "converts .gct files to .pcl files\n";
	print "If -o option given, the resultant .gct will be saved as the name specified (and only one file can be converted)\n";
	print "Otherwise, the .gct file will be saved with the .gct extension changed to .pcl (and multiple can be specified)\n";
	die;
}

for (my $i=0;$i<=$#gct;$i++) {
	my $gctFile = $gct[$i];
	if ($gctFile =~ /^-o/) {
		if ($i<($#gct+1)) {
			my $output = $gct[++$i];
			my $gctFile = $gct[++$i];
			convertToPcl($gctFile,$output);
		}
	}
	else {
		convertToPcl($gctFile);
	}
}

exit;

sub convertToPcl {
	my ($file, $outputFile) = @_;
	if (!defined $outputFile) {
		$outputFile = $file;
		$outputFile =~ s|\.gct$|.pcl|;
	}
	if (-f $outputFile) { print "$outputFile exists - overwriting\n"; }
	open PCL, ">$outputFile" || die "Unable to open $file for writing\n";
	#print "Converting $file to $outputFile\n";

	unless (-f $file) {
		die ("Unable to find $file\n");
	}
	open (GCT, $file) || die "Unable to open $file\n";

	## throw away first two lines
	my $vers = <GCT>;
	my $gctcounts = <GCT>;

	## head
	my $head1 = <GCT>;
	chomp $head1;
	
	my @heads = split(/\t/,$head1);
	## get rid of first two colummns ('real' labels start with the 3rd column)
	shift @heads;
	shift @heads;
	my $expCount = $#heads +1;

	print PCL "UID\tNAME\tGWEIGHT\t";
	print PCL join ("\t",@heads),"\n";

	## WEIGHTS
	print PCL "EWEIGHT\t\t";
	print PCL "\t1" x $expCount;
	print PCL  "\n";
	
	while (<GCT>) {
		chomp;
		my @data = split (/\t/,$_);
		my $uid = shift @data;
		my $name = shift @data;
		while (@data <$expCount) {
			push @data, "";
		}
		print PCL "$uid\t$name\t1\t";
		print PCL join ("\t",@data),"\n";
	}
		
	close PCL;
	close GCT;
}

	
