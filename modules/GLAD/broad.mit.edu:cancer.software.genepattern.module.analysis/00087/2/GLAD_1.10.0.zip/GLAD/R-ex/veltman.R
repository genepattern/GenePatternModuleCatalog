### Name: veltman
### Title: Public CGH data of Veltman
### Aliases: P9 P20
### Keywords: datasets

### ** Examples

data(veltman)
P9



