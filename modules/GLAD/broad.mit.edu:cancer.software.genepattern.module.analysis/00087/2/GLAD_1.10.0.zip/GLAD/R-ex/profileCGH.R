### Name: profileCGH
### Title: Objects of Class profileCGH and profileChr
### Aliases: profileCGH profileChr


### ** Examples

  
data(snijders)
gm13330$Clone <- gm13330$BAC
profileCGH <- as.profileCGH(gm13330)
class(profileCGH) <- "profileCGH"

profileChr <- as.profileCGH(gm13330[which(gm13330$Chromosome==1),])
class(profileChr) <- "profileChr"




