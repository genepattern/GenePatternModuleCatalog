### Name: tkdaglad
### Title: Graphical interface for GLAD package
### Aliases: tkdaglad tkdaglad.default tkglad tkglad.default


### ** Examples

  
data(snijders)
array1 <- as.profileCGH(gm13330)
array2 <- as.profileCGH(gm04435)

## tkdaglad(c("array1","array2"))
## tkglad(c("array1","array2"))




