### This code uses GLAD to find smooth CN for a matrix of raw CN's from
### several samples. Takes as input the file with the dChip output.
### Returns a file whose rows are segments and whose
### columns are: sample number, chromosome, beginning bp, end bp,
### number SNPs in segment, and mean copy numbers for
### segment. The ... is any extra arguments for the glad command.



gpGLAD<-function(libdir, infile, outfile, log=T, ...){

  setLibPath(libdir)

  if(!is.package.installed(libdir, "aws")) {
    install.package(libdir, "aws_1.3-2.zip", "aws_1.3-2.tgz", "aws_1.3-2.tar.gz")
  }

  if(!is.package.installed(libdir, "GLAD")) {
    install.package(libdir, "GLAD_1.0.4.zip", "GLAD_1.0.4.tar.gz", "GLAD_1.0.4.tar.gz")
  }
  
  library(GLAD, verbose=FALSE)
  
  
  log <- as.logical(log)
  
  
  print("Reading Input File")
  see<-read.delim(infile)
  
  nSamp <- (dim(see)[2]-3) # for .cn format
 #  nSamp <- (dim(see)[2]-3)/2 #for xcn format

  chr<-see[,2]
  chr<-as.character(chr)
  chr[chr=="X"]<-"23"
  chr<-as.numeric(chr)
  bp<-see[,3]
  

  dats<-see[,-(1:3)]
  dats <- dats[,(1:nSamp)]
  
                                        # log2 the data
  
  if (log == T) {
    print("Logging Data")
    dats <- if(is.vector(dats)) { apply(as.matrix(dats),c(1,2),log2)} else apply(dats,c(1,2),log2)
    dats <- apply(dats, c(1,2), function(x){x-1})
  }
  
  cnms<-colnames(see)[-(1:3)]
  cnms <- cnms[(1:nSamp)]
  
  nSNP<-dim(see)[1]
  out<-matrix(nrow=0, ncol=6)
  
  for(i in 1:nSamp){
    print(paste("SAMPLE", i))
    ob<-if(is.vector(dats)) {cbind(chr, 1:nSNP, bp, dats)} else cbind(chr, 1:nSNP, bp, dats[,i])
    
    ob<-as.data.frame(ob)
    
    colnames(ob)<-c("Chromosome", "PosOrder", "PosBase", "LogRatio")
    
    ob<-as.profileCGH(ob)
    
    want<-glad(ob, verbose=T)[[1]][,c(1,3,6,7)]
    
    reg<-unique(want[,4])
    
    for(j in reg){
      tmp<-want[want[,4]==j,-4]
      nMark<-if(is.vector(tmp)){1} else dim(tmp)[1]
      chrst<-if(is.vector(tmp)){tmp[1:2]} else tmp[1,1:2]
      nd<-if(is.vector(tmp)){tmp[2]} else tmp[nMark,2]
      mn<-if(is.vector(tmp)){tmp[3]} else tmp[1,3]
      if (log==T) {
                                        # convert log2 value back to absolute
        mn = mn+1
        mn <- 2^mn
      }
      out<-rbind(out, c(cnms[i],chrst, nd, nMark, mn))
    }
    
    
    
    colnames(out)<-c("Sample", "Chromosome", "Start.bp", "End.bp", "Num.SNPs", "Seg.CN")
  }
  
  
  
  
                                        #out<-apply(out, 2, function(x){as.numeric(as.character(x))})
  
                                        #out<-out[order(out[,2], out[,3]),]
  
  write.table(out, file=outfile, sep="\t", quote=F, row.names=F)
}





is.package.installed <- function(libdir, pkg) {
f <- paste(libdir, pkg, sep='')
return(file.exists(f) && file.info(f)[["isdir"]])
}


install.package <- function(dir, windows, mac, other) {
  
isWindows <- Sys.info()[["sysname"]]=="Windows"
isMac <- Sys.info()[["sysname"]]=="Darwin"
if(isWindows) {
f <- paste(dir, windows, sep="")
.install.windows(f)
} else if(isMac) {
f <- paste(dir, mac, sep="")
      .install.unix(f)
} else { # install from source
f <- paste(dir, other, sep="")
.install.unix(f)
}
}

.install.windows <- function(pkg) {
install.packages(pkg, .libPaths()[1], CRAN=NULL, installWithVers=FALSE)
}

.install.unix <- function(pkg) {
    lib <- .libPaths()[1]
   # cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL --with-package-versions")
cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL")
    cmd <- paste(cmd, "-l", lib)
    cmd <- paste(cmd, " '", pkg, "'", sep = "")
    status <- system(cmd)
    if (status != 0)
    cat("\tpackage installation failed\n")
}

setLibPath <- function(libdir) {
 libPath <- libdir
 if(!file.exists(libdir)) {
  # remove trailing /
  libPath <- substr(libdir, 0, nchar(libdir)-1)
 }
 .libPaths(libPath)
}
