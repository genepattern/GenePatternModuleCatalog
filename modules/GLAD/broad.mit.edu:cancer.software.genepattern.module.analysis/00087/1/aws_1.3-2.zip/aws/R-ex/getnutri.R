### Name: getnutri
### Title: Calculate number of grid points in a 3D ellipsoidal neighborhood
### Aliases: getnutri
### Keywords: misc

### ** Examples




