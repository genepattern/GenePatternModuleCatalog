### Name: awsh
### Title: Univariate local polynomial Adaptive Weights Smoothing for
###   regression with heteroscedastic additive errors
### Aliases: awsh
### Keywords: smooth nonparametric regression models

### ** Examples

##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--    or do  help(data=index)  for the standard data sets.



