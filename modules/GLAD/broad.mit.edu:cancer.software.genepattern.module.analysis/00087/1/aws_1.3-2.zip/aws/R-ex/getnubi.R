### Name: getnubi
### Title: Calculate number of grid points in a bivariate elliptical
###   neighborhood
### Aliases: getnubi
### Keywords: misc

### ** Examples




