### Name: arrayPlot
### Title: Spatial image of microarray spots statistic
### Aliases: arrayPlot arrayPlot.default arrayPlot.arrayCGH


### ** Examples

data(arrayCGH)

pdf(file="arrayCGH.pdf",height=21/cm(1),width=29.7/cm(1))
arrayPlot(array2$Log2Rat, array2$Col, array2$Row, 4,4,21,22, main="Spatial Image of array CGH")
dev.off()

# object of class arrayCGH

array <- list(arrayValues=array2, arrayDesign=c(4,4,21,22))
class(array) <- "arrayCGH"

arrayPlot(array,"Log2Rat", main="Spatial Image of array CGH")




