### Name: profileCGH
### Title: Objects of Class profileCGH and profileChr
### Aliases: profileCGH profileChr


### ** Examples

  
data(snijders)
profileCGH <- as.profileCGH(gm13330)
class(profileCGH) <- "profileCGH"

profileChr <- as.profileCGH(gm13330[which(gm13330$Chromosome==1),])
class(profileChr) <- "profileChr"




