### Name: arrayPersp
### Title: Perspective image of microarray spots statistic
### Aliases: arrayPersp arrayPersp.default arrayPersp.arrayCGH


### ** Examples

data(arrayCGH)

# object of class arrayCGH

array <- list(arrayValues=array2, arrayDesign=c(4,4,21,22))
class(array) <- "arrayCGH"

arrayPersp(array,"Log2Rat", main="Perspective image of array CGH", box=FALSE, theta=110, phi=40)





