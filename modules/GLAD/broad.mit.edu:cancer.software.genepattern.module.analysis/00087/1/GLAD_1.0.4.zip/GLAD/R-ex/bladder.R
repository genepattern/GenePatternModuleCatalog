### Name: array
### Title: Bladder cancer CGH data
### Aliases: array1 array2 array3
### Keywords: datasets

### ** Examples

data(arrayCGH)
data <- array1 #array1 to array3



