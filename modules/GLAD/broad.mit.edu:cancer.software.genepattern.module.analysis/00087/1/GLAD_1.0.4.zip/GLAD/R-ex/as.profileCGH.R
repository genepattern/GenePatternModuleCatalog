### Name: as.profileCGH
### Title: Create an object of class profileCGH
### Aliases: as.profileCGH as.profileCGH.data.frame


### ** Examples


data(snijders)

### Creation of "profileCGH" object
profileCGH <- as.profileCGH(gm13330)

attributes(profileCGH)




