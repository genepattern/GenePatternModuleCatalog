### Name: as.data.frame.profileCGH
### Title: profileCGH consercion
### Aliases: as.data.frame.profileCGH


### ** Examples


data(snijders)

### Creation of "profileCGH" object
profileCGH <- as.profileCGH(gm13330)


###########################################################
###
###  glad function as described in Hup� et al. (2004)
###
###########################################################

res <- glad(profileCGH, mediancenter=FALSE,
                smoothfunc="lawsglad", bandwidth=10, round=2,
                model="Gaussian", lkern="Exponential", qlambda=0.999,
                base=FALSE,
                lambdabreak=8, lambdacluster=8, lambdaclusterGen=40,
                type="tricubic", param=c(d=6),
                alpha=0.001, msize=5,
                method="centroid", nmax=8,
                verbose=FALSE)

res <- as.data.frame(res)




