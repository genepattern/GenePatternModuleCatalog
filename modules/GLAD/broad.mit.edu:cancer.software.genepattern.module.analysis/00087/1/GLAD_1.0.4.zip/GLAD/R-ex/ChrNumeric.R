### Name: ChrNumeric
### Title: Convert chromosome into numeric values
### Aliases: ChrNumeric


### ** Examples


Chromosome <- c("1","X","Y","chr X", "ChrX", "chrX", "Chr   Y")
ChrNumeric(Chromosome)




