### Name: arrayCGH
### Title: Object of Class arrayCGH
### Aliases: arrayCGH


### ** Examples

data(arrayCGH)

# object of class arrayCGH

array <- list(arrayValues=array2, arrayDesign=c(4,4,21,22))
class(array) <- "arrayCGH"




