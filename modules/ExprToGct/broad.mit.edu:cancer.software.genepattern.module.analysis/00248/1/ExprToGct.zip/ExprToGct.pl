use Getopt::Long;

$result = GetOptions ("input=s" => \$inputFile, 
					  "output=s"  => \$outputPrefix);  

if (!($inputFile =~ /\.expr$/i)) {
	print STDERR "Incorrect input file type. Expected .expr file.\n";
	exit(1);
}

$outputFile = $outputPrefix;
if ($outputPrefix eq "") {
	$outputFile = "output.gct";
} elsif (!($outputFile =~ /\.gct$/i)) {
	$outputFile = $outputPrefix . ".gct";
}

open(IN, "<$inputFile") || die("Can't open file: $!");
chomp(@lines = <IN>);
close(IN);

$lines[0] =~ s/(\r\n)?|(\n)?//g;              # remove the newline from headerline.
@colNames = split(/\t/, $lines[0]);

if ($#lines < 1)  {
	print STDERR "Error: The input file $inputFile contains no data, or is not a valid .expr file.\n";
	exit(1);
}

$dataName = "FPKM";
$leftName = "left";
$rightName = "right";
$chrName = "chr";

$dataIndex = -1;  #col index of data which will be written to GCT file
$leftIndex = -1;  
$rightIndex = -1;
$chrIndex = -1;

$dataIndex++ until ($colNames[$dataIndex] eq $dataName) or ($dataIndex > $#colNames);
if ($dataIndex > $#colNames) { 
	print STDERR "$dataName not found among EXPR file column names: @colNames.\nMissing headerline or invalid EXPR file.\n";
	exit(1);
}

$leftIndex++ until ($colNames[$leftIndex] eq $leftName) or ($leftIndex > $#colNames);
if ($leftIndex > $#colNames) { 
	print STDERR "$leftName not found among EXPR file column names: @colNames.\nMissing headerline or invalid EXPR file.\n";
	exit(1);
}

$rightIndex++ until ($colNames[$rightIndex] eq $rightName) or ($rightIndex > $#colNames);
if ($rightIndex > $#colNames) { 
	print STDERR "$rightName not found among EXPR file column names: @colNames.\nMissing headerline or invalid EXPR file.\n";
	exit(1);
}

$chrIndex++ until ($colNames[$chrIndex] eq $chrName) or ($chrIndex > $#colNames);
if ($chrIndex > $#colNames) { 
	print STDERR "$chrName not found among EXPR file column names: @colNames.\nMissing headerline or invalid EXPR file.\n";
	exit(1);
}

@data = ();
@rowNames = ();
@description = ();
foreach $line (@lines[1..$#lines]) {
	$line =~ s/(\r\n)?|(\n)?//g;              # remove the newline 
	@vals = split(/\t/, $line);
	push(@rowNames, $vals[0]);
	push(@description, $vals[$chrIndex] . ":" . $vals[$leftIndex] . "-" . $vals[$rightIndex]);
	push(@data, $vals[$dataIndex]);
}

open(OUT, ">$outputFile") || die ("Can't open file: $!");
print OUT "#1.2\n";
print OUT $#rowNames+1, "\t1\n";
print OUT $colNames[0], "\tDescription\t$dataName\n";
for($i=0;$i<=$#rowNames;$i++) {
	print OUT $rowNames[$i], "\t", $description[$i], "\t", $data[$i], "\n";
}



