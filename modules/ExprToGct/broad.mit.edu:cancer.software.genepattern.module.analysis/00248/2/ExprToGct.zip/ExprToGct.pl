use Getopt::Long;

sub trim($);

$result = GetOptions ("input=s" => \$inputFile, 
					  "output=s"  => \$outputPrefix);  

if (!($inputFile =~ /\.expr$/i)) {
	print STDERR "Incorrect input file type. Expected .expr file.\n";
	exit(1);
}

$outputFile = $outputPrefix;
if ($outputPrefix eq "") {
	$outputFile = "output.gct";
} elsif (!($outputFile =~ /\.gct$/i)) {
	$outputFile = $outputPrefix . ".gct";
}

open(IN, "<$inputFile") || die("Can't open file: $!");
@lines = <IN>;
close(IN);

#remove newlines, even if from different platforms
$joined = join('',@lines); #several lines may be present in each element of @lines
$joined =~ s/[\r\n?]+/\n/g;
@lines = split(/\n/, $joined);

if ($#lines < 1)  {
	print STDERR "Error: The input file contains no data, or is not a valid .expr file.\n";
	exit(1);
}

@colNames = split(/\t/, $lines[0]);
for $j (0..$#colNames) { trim($colNames[$j]); }

$dataName = "FPKM";
$leftName = "left";
$rightName = "right";
$chrName = "chr";

$dataIndex = -1;  #col index of data which will be written to GCT file
$leftIndex = -1;  
$rightIndex = -1;
$chrIndex = -1;

$dataIndex++ until ($colNames[$dataIndex] eq $dataName) or ($dataIndex > $#colNames);
if ($dataIndex > $#colNames) { 
	print STDERR "$dataName not found among EXPR file column names: @colNames.\nMissing headerline or invalid EXPR file.\n";
	exit(1);
}

$leftIndex++ until ($colNames[$leftIndex] eq $leftName) or ($leftIndex > $#colNames);
if ($leftIndex > $#colNames) { 
	print STDERR "$leftName not found among EXPR file column names: @colNames.\nMissing headerline or invalid EXPR file.\n";
	exit(1);
}

$rightIndex++ until ($colNames[$rightIndex] eq $rightName) or ($rightIndex > $#colNames);
if ($rightIndex > $#colNames) { 
	print STDERR "$rightName not found among EXPR file column names: @colNames.\nMissing headerline or invalid EXPR file.\n";
	exit(1);
}

$chrIndex++ until ($colNames[$chrIndex] eq $chrName) or ($chrIndex > $#colNames);
if ($chrIndex > $#colNames) { 
	print STDERR "$chrName not found among EXPR file column names: @colNames.\nMissing headerline or invalid EXPR file.\n";
	exit(1);
}

@data = ();
@rowNames = ();
@description = ();
foreach $line (@lines[1..$#lines]) {
	@vals = split(/\t/, $line);
	push(@rowNames, trim($vals[0]));
	push(@description, trim($vals[$chrIndex]) . ":" . trim($vals[$leftIndex]) . "-" . trim($vals[$rightIndex]));
	push(@data, trim($vals[$dataIndex]));
}

#return error if all data values are zero
$validData = 0;
foreach $dat (@data) {
	if ($dat != 0) {
		$validData = 1;
		last;
	}
}
if (!$validData) {
	print STDERR "Error: The input file contains all-zero $dataName values.\n";
	exit(1);
}

#return error if all rownames are the same
$validRowNames = 0;
$firstName = $rowNames[0];
foreach $rn (@rowNames) {
	if ($rn ne $firstName) {
		$validRowNames = 1;
		last;
	}
}
if (!$validRowNames) {
	print STDERR "Error: The input file contains identical row names for all rows in the file.\n";
	exit(1);
}

#write GCT file
open(OUT, ">$outputFile") || die ("Can't open file: $!");
print OUT "#1.2\n";
print OUT $#rowNames+1, "\t1\n";
print OUT $colNames[0], "\tDescription\t$dataName\n";
for($i=0;$i<=$#rowNames;$i++) {
	print OUT $rowNames[$i], "\t", $description[$i], "\t", $data[$i], "\n";
}


# Perl trim function to remove whitespace from the start and end of the string
sub trim($)
{
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}



