###############################################################
# LogisticRegression.GP.R (ver.1)                May 1, 2006
#
#      Logistic regression using clinical data and .cls file
#        Yujin Hoshida (Broad Institute)
###############################################################

### LogisticRegression (Main) ###

LogisticRegression.GP <- function(
  input.clin.data.filename,
  input.cls.filename="NA",

  output.file="LogisticRegression_result",
                                  
  response.variable="NA",

  variable.continuous="NA",
  variable.category="NA",
  variable.interaction.terms="NA",

  input.subgroup="NA", #    e.g. "variable:2" only 1 subgroup can be selected

  variable.selection="none"    # "both","forward","backward"
  )
{

  if (response.variable=="NA"){
    stop("### Please specify response variable! ###")
  }

  # read input files
  
  clin.data<<-read.clin.data(input.clin.data.filename)
  if (input.cls.filename!="NA"){
    cls<-read.cls(input.cls.filename)
    cls.label<-read.cls.label(input.cls.filename)

    num.cls<-length(table(cls))

    if(length(clin.data[,1])!=length(cls)){
      stop("### Clinical data and class file don't match! ###")
    }
    clin.data<<-cbind(clin.data,cls)
  }

  # load packages

  library(stats)
#  library(survival)
  library(MASS)
  
  # variable conversion

  if (variable.continuous!="NA"){
    variable.continuous<-gsub(",","+",variable.continuous)
  }else{
    variable.continuous<-""
  }
  if (variable.category!="NA"){
    variable.category<-convert.category(variable.category)
  }else{
    variable.category<-""
  }
  if (variable.interaction.terms!="NA"){
    variable.interaction.terms<-gsub(",","+",variable.interaction.terms)
  }else{
    variable.interaction.terms<-""
  }

  combined.variables<-paste(variable.continuous,variable.category,variable.interaction.terms,sep="+")
  combined.variables<-gsub("\\++","+",combined.variables)
  combined.variables<-gsub("\\++","+",combined.variables)
  combined.variables<-sub("\\+$","",combined.variables)
  combined.variables<-sub("^\\+","",combined.variables)

  # GLM fit

  if (input.subgroup=="NA"){
    logreg.command<-paste("glm(",response.variable,"~",combined.variables,",binomial(logit),data=clin.data)",sep="")
  }else{
    subgroup<-unlist(strsplit(input.subgroup,":"))
    subgroup.variable<-subgroup[1]
    subgroup.member<-subgroup[2]

    logreg.command<-paste("glm(",response.variable,"~",combined.variables,",binomial(logit),data=clin.data,subset=",subgroup.variable,"==",subgroup.member,")",sep="")
  }

  logreg.fit<-eval(parse(text=logreg.command))

  # variable selection

  if (variable.selection!="none"){
    logreg.fit<-stepAIC(logreg.fit,direction=variable.selection,trace=0)
  }

  # Text output

  output.file <- paste(output.file,".txt",sep="")

  if (variable.selection=="none"){
    selection<-"variable selection:  none"
  }
  if (variable.selection=="both"){
    selection<-"variable selection:  Stepwise selection"
  }
  if (variable.selection=="forward"){
    selection<-"variable selection:  Forward selection"
  }
  if (variable.selection=="backward"){
    selection<-"variable selection:  Backward selection"
  }

  write.table("# Logistic regression results",output.file,quote=F,sep="\t",row.names=F,col.names=F)
  write.table("",output.file,quote=F,sep="\t",row.names=F,col.names=F,append=T)
  write.table(selection,output.file,quote=F,sep="\t",row.names=F,col.names=F,append=T)
  write.table(capture.output(summary(logreg.fit)),output.file,quote=F,sep="\t",row.names=F,col.names=F,append=T)
  write.table(paste("Deviance: ",deviance(logreg.fit),sep=""),output.file,quote=F,sep="\t",row.names=F,col.names=F,append=T)
  write.table("",output.file,quote=F,sep="\t",row.names=F,col.names=F,append=T)
  write.table(capture.output(summary.logreg(logreg.fit)),output.file,quote=F,sep="\t",row.names=F,col.names=F,append=T)


} # end of main



# read clinical data file

read.clin.data<-function(filename)
{
  if (regexpr(".txt$",filename)==-1){
    stop("### clinical data should be .txt file! ###")
  }
  clin.data<-read.delim(filename,header=T)
  return(clin.data)
}

# read .cls file

read.cls<-function(filename="NA")
{
  if (regexpr(".cls$",filename)==-1){
    stop("### class data should be .cls file! ###")
  }
  cls<-as.vector(t(read.delim(filename,header=F,sep=" ",skip=2)))
  return(cls)
}

read.cls.label<-function(filename="NA")
{
  cls.label<-scan(filename,what="charactor",sep=" ",nlines=2,quiet=T)
  num.cls<-as.numeric(cls.label[2])
  cls.label<-cls.label[5:(5+num.cls-1)]
  return(cls.label)
}

convert.category<-function(input.variable.category)
{
  splitted.variable<-unlist(strsplit(input.variable.category,","))
  num.cat.variable<-length(splitted.variable)
  variable.category<-""
  for (i in 1:num.cat.variable){
    variable.category<-paste(variable.category,"factor(",splitted.variable[i],")+",sep="")
  }
  return(variable.category)
}

summary.logreg<-function (object, dispersion = NULL, correlation = FALSE, symbolic.cor = FALSE, 
    ...) 
{
    est.disp <- FALSE
    df.r <- object$df.residual
    if (is.null(dispersion)) 
        dispersion <- if (any(object$family$family == c("poisson", 
            "binomial"))) 
            1
        else if (df.r > 0) {
            est.disp <- TRUE
            if (any(object$weights == 0)) 
                warning("observations with zero weight not used for calculating dispersion")
            sum(object$weights * object$residuals^2)/df.r
        }
        else Inf
    p <- object$rank
    if (p > 0) {
        p1 <- 1:p
        Qr <- object$qr
        aliased <- is.na(coef(object))
        coef.p <- object$coefficients[Qr$pivot[p1]]
        covmat.unscaled <- chol2inv(Qr$qr[p1, p1, drop = FALSE])
        dimnames(covmat.unscaled) <- list(names(coef.p), names(coef.p))
        covmat <- dispersion * covmat.unscaled
        var.cf <- diag(covmat)
        s.err <- sqrt(var.cf)
        tvalue <- coef.p/s.err
        or<-exp(coef.p)       # add
        lower<-exp(coef.p-(1.96*s.err))  # add
        upper<-exp(coef.p+(1.96*s.err))  # add
        dn <- c("Estimate", "Std. Error")
        if (!est.disp) {
            pvalue <- 2 * pnorm(-abs(tvalue))
            coef.table <- cbind(coef.p, s.err, tvalue, or, lower, upper, pvalue)
            dimnames(coef.table) <- list(names(coef.p), c(dn, 
                "Wald", "OR", "lower.95\%.CI", "upper.95\%.CI", "P-value"))
        }
        else if (df.r > 0) {
            pvalue <- 2 * pt(-abs(tvalue), df.r)
            coef.table <- cbind(coef.p, s.err, tvalue, pvalue)
            dimnames(coef.table) <- list(names(coef.p), c(dn, 
                "Wald", "OR", "lower.95\%.CI", "upper.95\%.CI", "P-value"))
        }
        else {
            coef.table <- cbind(coef.p, Inf)
            dimnames(coef.table) <- list(names(coef.p), dn)
        }
        df.f <- NCOL(Qr$qr)
    }
    else {
        coef.table <- matrix(, 0, 7)  # add
        dimnames(coef.table) <- list(NULL, c("Estimate", "Std. Error", 
            "Wald", "OR", "lower.95\%.CI", "upper.95\%.CI", "Pr(>|t|)"))
        covmat.unscaled <- covmat <- matrix(, 0, 0)
        aliased <- is.na(coef(object))
        df.f <- length(aliased)
    }
    ans <- c(object[c("call", "terms", "family", "deviance", 
        "aic", "contrasts", "df.residual", "null.deviance", "df.null", 
        "iter")], list(deviance.resid = residuals(object, type = "deviance"), 
        coefficients = coef.table, aliased = aliased, dispersion = dispersion, 
        df = c(object$rank, df.r, df.f), cov.unscaled = covmat.unscaled, 
        cov.scaled = covmat))
    if (correlation && p > 0) {
        dd <- sqrt(diag(covmat.unscaled))
        ans$correlation <- covmat.unscaled/outer(dd, dd)
        ans$symbolic.cor <- symbolic.cor
    }
    class(ans) <- "summary.logreg"
#    return(ans)
    return(coef.table)
}
