import sqlite3
import sys
import os
import sqlite_utils

Segment_Threshold_Value = 2000
        
def calc_level3qc_py(Segment_Count):
    good_val = '1'
    bad_val = '0'
    nocall_val = 'NoCall'
 

    # note: float() raises exception if field is blank or non-numeric
    Segment_Count_num = float(Segment_Count)
    # reject if noise too high
    if Segment_Count_num>=Segment_Threshold_Value:
        return bad_val
    
    return good_val

infile = sys.argv[1]
outfile = sys.argv[2]

if not os.path.exists(infile):
    raise Exception("Input file %s does not exist."%infile)

if os.path.exists(outfile):
    pass #raise Exception("Output file %s already exists."%outfile)



conn = sqlite3.connect(':memory:')
cursor=conn.cursor()

sqlite_utils.import_file_to_table(cursor,infile, 'segfile','No_Key')

conn.create_function("calc_level3qc_sql",1,calc_level3qc_py)

#input
#
# Sample Chromosome Start End Num_Probes Segment_Mean 

#output
#
# Array Level3_qc Level3_Segment_Count Level3_Segment_Count_Threshold

sql_cmd = '''CREATE TABLE level3qc 
AS SELECT 
      Sample as Array, 
      calc_level3qc_sql(count()) as Level3_qc,
      count() as Level3_Segment_Count,
      ? as Level3_Segment_Count_Threshold
    FROM segfile
    GROUP BY Sample
'''
sql_arg = (Segment_Threshold_Value,)
cursor.execute(sql_cmd, sql_arg)
#      

sqlite_utils.export_table_to_file(cursor,outfile,'level3qc')

    
