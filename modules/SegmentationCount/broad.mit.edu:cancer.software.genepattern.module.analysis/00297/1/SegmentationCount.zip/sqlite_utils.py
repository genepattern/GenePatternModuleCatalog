import csv
import sqlite3

#----------------------------------------------------------------------
def import_file_to_table(cursor,fn,tablename,keytype):
    """"""
    in_fid = open(fn,'r')
    in_reader = csv.reader(in_fid,dialect='excel-tab')
    
    # Load first line as header
    header_line = in_reader.next()
    
    # Replace blank column names with 'ColumnX'
    for i in range(len(header_line)):
        if header_line[i]=='':
            header_line[i]='Column%d'%(i+1)
    
    # Create table with that header line
    header_end = '"' + '","'.join(header_line[1:]) + '"'
    
    if keytype == 'Column1_Key':
        sql_cmd = 'create table %s("%s" PRIMARY KEY,%s)'%(tablename,header_line[0],header_end)
    elif keytype == 'No_Key':
        sql_cmd = 'create table %s("%s" ,%s)'%(tablename,header_line[0],header_end)
    else:
        raise Exception('unexpected value for keytype: %s. Must be "Column1_Key" or "No_Key"')

    cursor.execute(sql_cmd)
    
    # Load remaining lines as data
    a=['?']*(len(header_line))
    b=','.join(a) # contains '?,?,?,?...' one ? per column
    sql_cmd = 'INSERT INTO %s VALUES (%s)'%(tablename,b)
    for line in in_reader:
        sql_args = line
        cursor.execute(sql_cmd,sql_args)
    in_fid.close()
    
    return header_line

#----------------------------------------------------------------------
def export_table_to_file(cursor,filename,tablename):
    """"""
    out_fid = open(filename,'w')
    out_writer = csv.writer(out_fid,dialect='excel-tab',lineterminator='\n')
    
    sql_cmd = 'SELECT * FROM %s'%tablename
    
    cursor.execute(sql_cmd)
    columns_raw = cursor.description
    columns = [column[0] for column in columns_raw]
    out_writer.writerow(columns)
    chunk = cursor.fetchmany()
    while chunk !=[]:
        out_writer.writerows(chunk)
        chunk = cursor.fetchmany()
        #print chunk
 
    out_fid.close()
        