#!/usr/bin/perl
#
# pclToGct.pl
#
# Author: Jeremy Hubble, Stanford University
# Date: 16 July 2008
# Purpose: Convert a .pcl to a .gct file for use in GenePattern
#
# Description: This converts a pcl file to a gct file. The two formats are
#    quite similar, thus the main action is simply to rearrange the data in 
#    the new format. The one bit of computation that is done is to multiple
#    through the Eweights and Gweights.  Also, pcl is somewhat more tolerant
#    than gct, and thus empty columns are explictly put in place (with a tab)
#    in the output GCT file.  
#
#    Blank columns in the .pcl file are left blank.  The .gct will probably
#    need to be run through an imputation module before it can be used with
#    most GenePattern modules.
#
#    When run on the command line, multiple .pcl files can be specified to convert
#    in batch.  When done in batch mode, the output .gct file will have the same
#    filename, with the extension changed to .gct.  Alternative, an output file
#    can be explicitly specified on the command line using the -o option.  When
#    this is done, the following pcl file will be output to the new filename.
#
# .pcl Format:
# Columns: Name \t  Descript \t  GWEIGHT   \t  experiments ....
# Rows:
# Headers
# EWEIGHT
# genes...
#
use strict;
my @pcl = @ARGV;
use Cwd;
use File::Basename;
my $dir = getcwd;

unless (@pcl) {
	print "USAGE: $0 .pcl_file...\n";
	print " or $0 -o outputfile .pclfile\n";
	print "converts .pcl files to .gct files\n";
	print "If -o option given, the resultant .gct will be saved as the name specified (and only one file can be converted)\n";
	print "Otherwise, the .pcl file will be saved with the .pcl extension changed to .gct (and multiple can be specified)\n";
	die;
}

my $weightprocess = 3;
for (my $i=0;$i<=$#pcl;$i++) {
	my $pclFile = $pcl[$i];
	if ($pclFile =~ /^-w/) {
		if ($i<($#pcl+1)) {
			$weightprocess = $pcl[++$i];
		}
	}
	elsif ($pclFile =~ /^-o/) {
		if ($i<($#pcl+1)) {
			my $output = $pcl[++$i];
			my $pclFile = $pcl[++$i];
			convertToGct($pclFile,$output);
		}
	}
	else {
		convertToGct($pclFile);
	}
}

exit;

sub convertToGct {
	my ($file, $outputFile) = @_;
	if (!defined $outputFile) {
		$outputFile = $file;
		$outputFile =~ s|\.pcl$|.gct|;
	}
	if (-f $outputFile) { print "$outputFile exists - overwriting\n"; }
	open GCT, ">$outputFile" || die "Unable to open $file for writing\n";
	#print "Converting $file to $outputFile\n";

	unless (-f $file) {
		die ("Unable to find $file\n");
	}
	open (PCL, $file) || die "Unable to open $file\n";
	my $head1 = <PCL>;
	chomp $head1;
	
	my @heads = split(/\t/,$head1);
	## get rid of first two colummns ('real' labels start with the 4th column)
	shift @heads;
	shift @heads;
	shift @heads;


	my $expCount = $#heads +1;
	my $itemCount = 0;
	my $output = "";

	my $eweights = <PCL>;
	chomp $eweights;
	my @eweight = split (/\t/,$eweights);
	shift @eweight;
	shift @eweight;
	shift @eweight;
	
	## check for weights
	if ($weightprocess == 3) {
		foreach my $w (@eweight) {
			if ($w != 1) {
				print STDERR "PCL file contains experiment weights.  Please choose to ignore weights to process\n";
				exit 1;
			}
		}
	}

	while (<PCL>) {
		$itemCount++;
		chomp;
		my @data = split (/\t/,$_);
		## id -> NAME
		$output .= shift @data;
	        $output .= "\t";
		## name -> Description
		$output .= shift @data ;
		## get the appropriate weight
		my $gweight = shift @data;
		if (($weightprocess == 3)&&($gweight != 1)) {
			print STDERR "PCL file contains gene weights.  Please choose to ignore weights to process\n";
			exit 2;
		}
			

		## In case we have empty items at the end, fill the end of data array with blanks
		while (@data <$expCount) {
			push @data, "";
		}
		## multiply through all the values, unless they are blank
		my $weightsfound = 0;
		for (my $i=0;$i<=$#data;$i++) {
			$output .= "\t";
			if ($data[$i] ne '') {
				if (($weightprocess != 2)||(($gweight == 1) && ($eweight[$i] == 1))) {
					## don't multiply through if it is not needed
					## hopefully will reduce '-0' problems
					$output .= $data[$i];
				}
				else {
					$output .= $data[$i]*$gweight*$eweight[$i];
				}
			}
		}
		$output.="\n";
	}

	close PCL;
	print GCT "#1.2\n";
	print GCT "$itemCount\t$expCount\n";
	print GCT "NAME\tDescription\t".join("\t",@heads)."\n";
	print GCT $output;
	close GCT;
}

	
