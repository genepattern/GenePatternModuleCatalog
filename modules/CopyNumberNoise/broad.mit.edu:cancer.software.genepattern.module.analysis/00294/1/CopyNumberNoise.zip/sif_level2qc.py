import sqlite3
import sys
import os
import sqlite_utils

Noise_Threshold_Value = 0.63
        
def calc_level2qc_py(noise):
    good_val = '1'
    bad_val = '0'
    nocall_val = 'NoCall'
 

    # note: float() raises exception if field is blank or non-numeric
    noise_num = float(noise)
    # reject if noise too high
    if noise_num>=Noise_Threshold_Value:
        return bad_val
    
    return good_val

infile = sys.argv[1]
outfile = sys.argv[2]

if not os.path.exists(infile):
    raise Exception("Input file %s does not exist."%infile)

if os.path.exists(outfile):
    pass #raise Exception("Output file %s already exists."%outfile)



conn = sqlite3.connect(':memory:')
cursor=conn.cursor()

sqlite_utils.import_file_to_table(cursor,infile, 'qs_table','Column1_Key')

conn.create_function("calc_level2qc_sql",1,calc_level2qc_py)

#input
#
# Column1 qs SNPqs CNqs signal SNPsignal CNsignal noise SNPnoise CNnoise

#output
#
# Array, Level2_Signal, Level2_qc, Noise, Noise_Threshold 

sql_cmd = '''CREATE TABLE level2qc 
AS SELECT 
      Column1 as Array, 
      signal as Level2_Signal,
      calc_level2qc_sql(noise) as Level2_qc,
      noise as Level2_Noise,
      ? as Level2_Noise_Threshold
    FROM qs_table
'''
sql_arg = (Noise_Threshold_Value,)
cursor.execute(sql_cmd, sql_arg)
#      

sqlite_utils.export_table_to_file(cursor,outfile,'level2qc')

    