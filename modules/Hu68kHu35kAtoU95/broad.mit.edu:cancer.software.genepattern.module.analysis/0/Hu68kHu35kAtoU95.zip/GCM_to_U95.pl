#!/usr/bin/perl

if (@ARGV == 3){
        $pol = @ARGV[0];
        $output = @ARGV[1];
        $path = @ARGV[2];
        }
else {
        die "Not all arguments supplied!\n";
        }

if ($pol =~ /.pol$/){
	$type = 1;
        open (LIST, $pol) || die "Can't open .pol file!\n";
        while (<LIST>){
                $count++;
                chomp;
                ($rank, $acc, $name, $score) = split (/\t/);
		$RANK{$count} = $rank;
		$QUERY{$count} = $acc;
                }
        close (LIST) || die "Can't close .pol file!\n";
        }
elsif ($pol =~ /.tag$/){
	$type = 2;
        open (LIST, $pol) || die "Can't open .tag file!\n";
        while (<LIST>){
                $count++;
                chomp;
                ($acc, $name) = split (/\t/);
		$QUERY{$count} = $acc;
                }
        close (LIST) || die "Can't close .tag file!\n";
        }
elsif ($pol =~ /.grp$/){
	$type = 3;
        open (LIST, $pol) || die "Can't open .grp file!\n"; 
        while (<LIST>){
                $count++;
                chomp;
		$QUERY{$count} = $_;
                }
        close (LIST) || die "Can't close .grp file!\n";
        }
else {
        die "Input isn't a .pol/.tag/.grp file!\n";
        }

if ($type == 1){
	open (OUT, ">$output.pol") || die "Can't open output file!\n";
	}
elsif ($type == 2){
	open (OUT, ">$output.tag") || die "Can't open output file!\n";
	}
elsif ($type == 3){
	open (OUT, ">$output.grp") || die "Can't open output file!\n";
	}
else {
	die "Unsupported input file format!\n";
	}

foreach $i (1..$count){
	open (LOOKUP, $path."GCM_to_U95_lookup") || die "Can't open look-up table!\n";
	while (<LOOKUP>){
       		@line = split (/\t/);
        	($GCM_id, $genbank, $U95_id, $info) = @line;
		chomp $info;
               		if ($QUERY{$i} eq $GCM_id){
				$hits++;	
				$info =~ s/Cluster Incl\. (.+)://;
				$info = substr($info, 0, 50);
				print OUT "$RANK{$i}\t$U95_id\t$info\tGCM=$GCM_id\n" if ($type == 1);
				print OUT "$U95_id\t$info GCM=$GCM_id\n" if ($type == 2);
				print OUT "$U95_id\n" if ($type == 3);
         		}
       		}
	close (LOOKUP) || die "Can't close look-up table!\n";
	}	
close (OUT) || die "Can't close output file!\n";

print "There were $hits U95 probe-set matches from $count GCM probe-set queries.\n";

