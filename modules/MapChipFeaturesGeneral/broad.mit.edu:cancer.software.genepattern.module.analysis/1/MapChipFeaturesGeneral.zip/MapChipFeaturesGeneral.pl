# Replaces a feature set with another one in a res file using a table

use POSIX;
use Getopt::Std;
getopt('FTdfo');

$res_file = $opt_F; # -F <Res file with expression data>
$table = $opt_T; # -T <Table>
$desc_format = 0; # format, default without descriptions (only gene accessions)
$desc_format = $opt_f if defined($opt_f);
$output_file = $opt_o if defined($opt_o);

if (defined($opt_d)) {
    $direction = $opt_d; # -d forward look up
} else {
    $direction = 0;
}

print "\n Res file= $res_file \n";
print "\n Table= $table \n";

if ($direction == 1) {
    print "\n forward look up";
} else {
    print "\n reverse look up";
}

warn "\n\n";

print "\n Options: -F $opt_F -T $opt_T -d $opt_d \n";

open(F1, "$res_file") || die "Cannot open train file $res_file \n";
if ($res_file =~ /(.*).res/) {
    $res_name = $1;
}

$out_filename = ">" . "$output_file";
open(OUT, $out_filename) || die "cannot open file $out_filename \n";

open(TAB, "$table") || die "Cannot open train file $table \n";

%feature_table = ();

$tab_entries = 0;
$line = <TAB>; # skip header 1
$line = <TAB>;  # skip header 2

while (<TAB>) {
    chomp $_;

    if ($desc_format == 0) {
	($feature_1, $feature_2) = split("\t", $_);
    } else {
	($feature_1, $desc1, $feature_2, $desc2) = split("\t", $_);
    }
    if ($direction == 1) {
	$feature_table{$feature_1} = $feature_2;
    } else {
	$feature_table{$feature_2} = $feature_1;
    }
    $tab_entries++;

#    if ($tab_entries < 10) {
#	print "\n feature_1 = $feature_table{$feature_2}, feature_2 = $feature_2 \n";
#    }
}

print "\n read $tab_entries table entries \n";

# Read dataset

$line = <F1>;   # header line 1
print OUT "$line";
$line = <F1>;   # header line 2
print OUT "$line";
$line = <F1>;   # header line 3
print OUT "$line";

$feature_count = 0;
$match_count = 0;

while (<F1>) {
    chomp $_;
    @data = split("\t", $_);
    $desc = shift(@data);
    $gene = shift(@data);
    $feature_count++;

#    if ($feature_count < 10) {
#	print "feature_count: gene = $gene, table = $feature_table{$gene} \n";
#    }

    if (defined($feature_table{$gene})) {
	$match_count++;
	$new_gene = $feature_table{$gene};
	$vals = join("\t", @data);
	$line = "$desc" . "(FEATURE MAPPED)" ."\t$new_gene" . "\t$vals";
    } else {
	$new_gene = $gene;
	$vals = join("\t", @data);
	$line = "$desc" . "(FEATURE NOT MAPPED)" ."\t$new_gene" . "\t$vals";
    }
 
    print OUT "$line\n";
}

$not_matched = $feature_count - $match_count;
print "\n total features = $feature_count, $match_count matched, $not_matched not matched \n";


