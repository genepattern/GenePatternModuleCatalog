##################################################################

# SubMapBrowser.R (ver.1)                      May 4, 2007
#
#     Survey all possible Subclass Mappings
#        Yujin Hoshida (Broad Institute)

##################################################################

### SubMapBrowser (main) ###

message <- function (..., domain = NULL, appendLF = TRUE) {

}

SubMapBrowser <-
function(
  input.data.A,
  input.data.B,
  input.sample.info.A,
  input.sample.info.B,
  outputSubMapOverview.file="SubMapOverview",
  ntag=100,
  nperm=5,
  nperm.fisher=100,
  weighted.score.type=1,
  null.dist="pool",
  p.corr="FDR",
  clust.row=1,
  clust.col=1,
  create.legend="T",
  rnd.seed=3876352,
  libdir=""
)
{
    # for GenePattern
    nperm <- as.numeric(nperm)

    nperm.fisher <- as.numeric(nperm.fisher)

    rnd.seed <- as.numeric(rnd.seed)

    set.seed(rnd.seed)

    # omitted from command line

    outputTable.file <- paste(outputSubMapOverview.file, "_parameter.txt", sep="")

    nom.p.mat <- "F"

    null.dist.fig <- "F"

    ntag<-as.integer(ntag)

    nperm<-as.integer(nperm)

    nperm.fisher<-as.integer(nperm.fisher)

    weighted.score.type<-as.integer(weighted.score.type)

    if (clust.row=="NA")
    {
        clust.row<-NA
    }
    else
    {
        clust.row<-as.integer(clust.row)
    }

    if (clust.col=="NA")
    {
        clust.col<-NA
    }
    else
    {
        clust.col<-as.integer(clust.col)
    }

	 setLibPath(libdir)
    # install the package rimage if it is not already installed
    if(!is.package.installed(libdir, "rimage"))
    {
        # Windows, Mac, Unix packages
        install.package(libdir, "rimage_0.5-7.zip", "rimage_0.5-7.tar.gz", "rimage_0.5-7.tar.gz")
    }

    old.warn<-options("warn"=-1)

    library(rimage)

    options(old.warn)

    # Read input data & clustids

    original.data.A<-read.gct(filename=input.data.A)

    original.data.B<-read.gct(filename=input.data.B)

    data.A<-take.intersection(original.data.A,original.data.B)

    data.B<-take.intersection(original.data.B,original.data.A)

    num.intersection<-length(data.A[,1])

    if (num.intersection<=ntag)
    {
        stop(paste("### Number of intersection genes is ",num.intersection," (too small) ###",sep=""))
    }

    # Read sample info
    sample.info.A<-read.sample.info(filename=input.sample.info.A)

    sample.info.B<-read.sample.info(filename=input.sample.info.B)

    num.cls.A<-length(sample.info.A[1,])

    num.cls.B<-length(sample.info.B[1,])

    ## START LOOP OF MULTI-MATRICES ##
    for (clsA in 1:num.cls.A)
    {
        cand.cls.label.A<-sample.info.A[,clsA]

        for (clsB in 1:num.cls.B)
        {
            cand.cls.label.B<-sample.info.B[,clsB]

            # Mutual mapping to generate ES matrices
            ES.1<-submap.perm(data.A,data.B,cand.cls.label.A,cand.cls.label.B,ntag,nperm,weighted.score.type)

            ES.2<-submap.perm(data.B,data.A,cand.cls.label.B,cand.cls.label.A,ntag,nperm,weighted.score.type)

            n.row<-length(ES.1[,1,1])

            n.col<-length(ES.1[1,,1])

            # Convert ES matrices into nominal p-values

            nom.p.matrix.1<-array(9,c(n.row,n.col,(nperm+1)))

            nom.p.matrix.2<-array(9,c(n.col,n.row,(nperm+1)))

            if (null.dist=="each")
            {
                for (r in 1:n.row)
                {
                    for (c in 1:n.col)
                    {
                        each.ES.1<-ES.1[r,c,]

                        each.ES.2<-ES.2[c,r,]

                        ES.rank.1<-rank(each.ES.1)

                        ES.rank.2<-rank(each.ES.2)

                        nom.p.matrix.1[r,c,]<-((nperm+2-ES.rank.1)/(nperm+1))

                        nom.p.matrix.2[c,r,]<-((nperm+2-ES.rank.2)/(nperm+1))
                    }
                }
            }

            if (null.dist=="pool")
            {
                perm.ES.vector.1<-as.vector(ES.1[,,2:(nperm+1)])

                perm.ES.vector.2<-as.vector(ES.2[,,2:(nperm+1)])

                num.element<-length(perm.ES.vector.1)

                nom.p.perm.ES.vector.1<-((num.element+2-rank(perm.ES.vector.1))/(num.element+1))

                nom.p.perm.ES.vector.2<-((num.element+2-rank(perm.ES.vector.2))/(num.element+1))

                nom.p.perm.ES.1<-array(nom.p.perm.ES.vector.1,c(n.row,n.col,nperm))

                nom.p.perm.ES.2<-array(nom.p.perm.ES.vector.2,c(n.col,n.row,nperm))

                for (r in 1:n.row)
                {
                    for (c in 1:n.col)
                    {
                        rank.comb.ES.vector.1<-rank(c(ES.1[r,c,1],perm.ES.vector.1))

                        rank.comb.ES.vector.2<-rank(c(ES.2[c,r,1],perm.ES.vector.2))

                        nom.p.matrix.1[r,c,1]<-((num.element+2-rank.comb.ES.vector.1[1])/(num.element+1))

                        nom.p.matrix.2[c,r,1]<-((num.element+2-rank.comb.ES.vector.2[1])/(num.element+1))
                    }
                }

                nom.p.matrix.1[,,2:(nperm+1)]<-nom.p.perm.ES.1

                nom.p.matrix.2[,,2:(nperm+1)]<-nom.p.perm.ES.2
            }

            # compute nominal-p of Fisher's statistics from "each cell" or "pool of cells"
            nom.fisher.p.matrix<-matrix(9,nrow=n.row,ncol=n.col)

            each.perm.fisher.stat<-vector(length=nperm.fisher,mode="numeric")

            if (null.dist=="each")
            {
                for (r in 1:n.row)
                {
                    for (c in 1:n.col)
                    {
                        obs.fisher<-(-log(nom.p.matrix.1[r,c,1])-log(nom.p.matrix.2[c,r,1]))

                        perm.p.pool.1<-nom.p.matrix.1[r,c,2:(nperm+1)]

                        perm.p.pool.2<-nom.p.matrix.2[c,r,2:(nperm+1)]

                        for (f in 1:nperm.fisher)
                        {
                            rand.nom.p.1<-sample(perm.p.pool.1,1,replace=T)

                            rand.nom.p.2<-sample(perm.p.pool.2,1,replace=T)

                            each.perm.fisher.stat[f]<-(-log(rand.nom.p.1)-log(rand.nom.p.2))
                        }

                        comb.vector<-c(obs.fisher,each.perm.fisher.stat)

                        fisher.rank<-rank(comb.vector)

                        nom.fisher.p.matrix[r,c]<-((nperm.fisher+2-fisher.rank[1])/(nperm.fisher+1))
                    }
                }
            }

            if (null.dist=="pool")
            {
                perm.p.pool.1<-as.vector(nom.p.matrix.1[,,2:(nperm+1)])

                perm.p.pool.2<-as.vector(nom.p.matrix.2[,,2:(nperm+1)])

                for (f in 1:nperm.fisher)
                {
                    rand.nom.p.1<-sample(perm.p.pool.1,1,replace=T)

                    rand.nom.p.2<-sample(perm.p.pool.2,1,replace=T)

                    each.perm.fisher.stat[f]<-(-log(rand.nom.p.1)-log(rand.nom.p.2))
                }

                for (r in 1:n.row)
                {
                    for (c in 1:n.col)
                    {
                        obs.fisher<-(-log(nom.p.matrix.1[r,c,1])-log(nom.p.matrix.2[c,r,1]))

                        comb.vector<-c(obs.fisher,each.perm.fisher.stat)

                        fisher.rank<-rank(comb.vector)

                        nom.fisher.p.matrix[r,c]<-((nperm.fisher+2-fisher.rank[1])/(nperm.fisher+1))
                    }
                }
            }

            # p-value correction (SA matrix)
            bonf.SA.matrix<-fdr.SA.matrix<-matrix(9,nrow=n.row,ncol=n.col)

            bonf.SA.matrix<-nom.fisher.p.matrix*(n.row*n.col)

            bonf.SA.matrix[bonf.SA.matrix>1]<-1

            rank.matrix<-matrix(rank(nom.fisher.p.matrix),nc=length(nom.fisher.p.matrix[1,]))

            fdr.SA.matrix<-nom.fisher.p.matrix*(n.row*n.col)/rank.matrix

            fdr.SA.matrix[fdr.SA.matrix>1]<-1

            # output: text
            header=rbind("*** Subbclass Mappping Results ***","",

            paste("input.data.A:  ",as.character(input.data.A),sep=""),

            paste("input.data.B:  ",as.character(input.data.B),sep=""),

            paste("input.sample.info.A:  ",as.character(input.sample.info.A),sep=""),

            paste("input.sample.info.B:  ",as.character(input.sample.info.B),sep=""),

            paste("# of intersection genes:  ",num.intersection,sep=""),

            paste("# of marker genes:  ",ntag,sep=""),

            paste("# of permutation for nominal-p of ES:  ",nperm,sep=""),

            paste("# of permutation for nominal-p of Fisher's statistics:  ",nperm.fisher,sep=""),

            paste("SNR weight for ES (1=yes, 0=no):  ",weighted.score.type,sep=""),

            paste("choice of null distribution:  ",null.dist,sep=""),

            paste("p-value correction method (for Fisher's statistics):  ",p.corr,sep=""),
            ""
            )

            write.table(header,outputTable.file,quote=F,sep="\t",row.names=F,col.names=F)

            row.label<-paste("A",as.character(seq(1:n.row)),sep="")

            col.label<-paste("B",as.character(seq(1:n.col)),sep="")

            rownames(bonf.SA.matrix)<-rownames(fdr.SA.matrix)<-rownames(nom.fisher.p.matrix)<-rownames(nom.p.matrix.1)<-colnames(nom.p.matrix.2)<-row.label

            colnames(bonf.SA.matrix)<-colnames(fdr.SA.matrix)<-colnames(nom.fisher.p.matrix)<-colnames(nom.p.matrix.1)<-rownames(nom.p.matrix.2)<-col.label

            if (p.corr=="Bonferroni")
            {
                results<-list(SA.matrix=as.data.frame(bonf.SA.matrix),nominal.p.matrix.Fisher=as.data.frame(nom.fisher.p.matrix),nominal.p.matrix.ES.A.on.B=as.data.frame(nom.p.matrix.1[,,1]),nominal.p.matrix.ES.B.on.A=as.data.frame(t(nom.p.matrix.2[,,1])))
            }

            if (p.corr=="FDR")
            {
                results<-list(SA.matrix=as.data.frame(fdr.SA.matrix),nominal.p.matrix.Fisher=as.data.frame(nom.fisher.p.matrix),nominal.p.matrix.ES.A.on.B=as.data.frame(nom.p.matrix.1[,,1]),nominal.p.matrix.ES.B.on.A=as.data.frame(t(nom.p.matrix.2[,,1])))
            }

            #    write.table(capture.output(results),outputTable.file,quote=F,sep="\t",row.names=F,col.names=F,append=T)


            # output: gct of each SA matrix
            if (p.corr=="Bonferroni")
            {
                Name <- Description <- rownames(bonf.SA.matrix)

                output.bonf.SA.matrix <- cbind(Name,Description,bonf.SA.matrix)

                colnames.output.bonf.SA.matrix <- colnames(output.bonf.SA.matrix)

                output.bonf.SA.matrix <- t(cbind(colnames.output.bonf.SA.matrix,t(output.bonf.SA.matrix)))

                write.table("#1.2",paste(outputSubMapOverview.file,"_A",clsA,"_B",clsB,".gct",sep=""),quote=F,sep="\t",row.names=F,col.names=F)

                write.table(paste(n.row,n.col,sep="\t"),paste(outputSubMapOverview.file,"_A",clsA,"_B",clsB,".gct",sep=""),quote=F,sep="\t",row.names=F,col.names=F,append=T)

                write.table(output.bonf.SA.matrix,paste(outputSubMapOverview.file,"_A",clsA,"_B",clsB,".gct",sep=""),quote=F,sep="\t",row.names=F,col.names=F,append=T)
            }

            if (p.corr=="FDR")
            {
                Name <- Description <- rownames(fdr.SA.matrix)

                output.fdr.SA.matrix <- cbind(Name,Description,fdr.SA.matrix)

                colnames.output.fdr.SA.matrix <- colnames(output.fdr.SA.matrix)

                output.fdr.SA.matrix <- t(cbind(colnames.output.fdr.SA.matrix,t(output.fdr.SA.matrix)))

                write.table("#1.2",paste(outputSubMapOverview.file,"_A",clsA,"_B",clsB,".gct",sep=""),quote=F,sep="\t",row.names=F,col.names=F)

                write.table(paste(n.row,n.col,sep="\t"),paste(outputSubMapOverview.file,"_A",clsA,"_B",clsB,".gct",sep=""),quote=F,sep="\t",row.names=F,col.names=F,append=T)

                write.table(output.fdr.SA.matrix,paste(outputSubMapOverview.file,"_A",clsA,"_B",clsB,".gct",sep=""),quote=F,sep="\t",row.names=F,col.names=F,append=T)
            }

            # output: heatmap of each SA matrix
            if (capabilities("jpeg")==T)
            {
                # each heatmap
                min.matrix<-max.matrix<-9
            
                if (p.corr=="Bonferroni")
                {
                    if (min(bonf.SA.matrix)==max(bonf.SA.matrix))
                    {
                        min.matrix<-.9999999999

                        max.matrix<-1
                    }
                    else
                    {
                        min.matrix<-min(bonf.SA.matrix)

                        max.matrix<-max(bonf.SA.matrix)
                    }

                    jpeg(paste(outputSubMapOverview.file,"_A",clsA,"_B",clsB,".jpeg",sep=""))

                    heatmap(bonf.SA.matrix,Rowv=clust.row,Colv=clust.col,scale="none",col=rainbow(1000,start=(0+.7*min.matrix),end=.7*max.matrix),gamma=1)

                    dev.off()
                }

                if (p.corr=="FDR")
                {
                    if (min(fdr.SA.matrix)==max(fdr.SA.matrix))
                    {
                        min.matrix<-.9999999999

                        max.matrix<-1
                    }
                    else
                    {
                        min.matrix<-min(fdr.SA.matrix)

                        max.matrix<-max(fdr.SA.matrix)
                    }

                    jpeg(paste(outputSubMapOverview.file,"_A",clsA,"_B",clsB,".jpeg",sep=""))

                    heatmap(fdr.SA.matrix,Rowv=clust.row,Colv=clust.col,scale="none",col=rainbow(1000,start=(0+.7*min.matrix),end=.7*max.matrix),gamma=1)

                    dev.off()
                }
            }  # END each heatmap

        }  ## END LOOP CLS.B

    }  ## END LOOP CLS.A


    # Summary of SA matrix graphics

    if (capabilities("png")==T)
    {
        #summary png

        num.pic.row<-num.cls.B

        num.pic.col<-num.cls.A

        png(paste(outputSubMapOverview.file,".png",sep=""),width=500*num.pic.col,height=500*num.pic.row)

        par(mfcol=c(num.pic.row,num.pic.col))

        par(mar=c(1,1,1,1))

        for (clsA in 1:num.cls.A)
        {
            for (clsB in 1:num.cls.B)
            {
                hm<-read.jpeg(paste(outputSubMapOverview.file,"_A",clsA,"_B",clsB,".jpeg",sep=""))

                plot(hm)
            }
        }

        dev.off()

        ## legend of heatmap

        if (create.legend=="T")
        {
            png("legend.png")

            par(plt=c(.1,.9,.45,.5))

            a=matrix(seq(1:1000),nc=1)

            image(a,col=rainbow(1000,start=0,end=.7,gamma=1),xlim=c(0,1),yaxt="n")

            dev.off()
        }

    }   # END summary png
}



### submap.perm ###
submap.perm <-
function(data.mkr,data.rnk,cand.cls.label.mkr,cand.cls.label.rnk,ntag=100,nperm=1000,weighted.score.type=1)
{

    # cls label, box

    cand.cls.box.mkr<-cand.cls.box(cand.cls.label.mkr)

    cand.cls.box.rnk<-cand.cls.box(cand.cls.label.rnk)

    num.subcls.mkr<-length(cand.cls.box.mkr)

    num.subcls.rnk<-length(cand.cls.box.rnk)

    # initialize

    perm.ES.matrices<-array(0,c(num.subcls.mkr,num.subcls.rnk,(nperm+1)))

    #  perm.cand.cls.label.rnk<-vector(length=length(cand.cls.label.rnk),mode="numeric")


    # observed ES matrix
    ES.matrix<-matrix(0,nrow=num.subcls.mkr,ncol=num.subcls.rnk)

    perm.ES.matrices[,,1]<-submap(data.mkr,data.rnk,cand.cls.label.mkr,cand.cls.label.rnk,ES.matrix,num.subcls.mkr,num.subcls.rnk,ntag,weighted.score.type)

    # permutated ES matrices

    for (i in 2:(nperm+1))
    {
        perm.cand.cls.label.rnk<-sample(cand.cls.label.rnk)

        perm.ES.matrices[,,i]<-submap(data.mkr,data.rnk,cand.cls.label.mkr,perm.cand.cls.label.rnk,ES.matrix,num.subcls.mkr,num.subcls.rnk,ntag,weighted.score.type)
    }

    return(perm.ES.matrices)
}    ## end of submap.perm (Main)


### submap ###

submap <-
function(data.mkr,data.rnk,cand.cls.label.mkr,cand.cls.label.rnk,ES.matrix,num.subcls.mkr,num.subcls.rnk,ntag=100,weighted.score.type=1)
{
    for (rnk in 1:num.subcls.rnk)
    {
        # convert rnk cls to binary

        cls.bin.rnk<-cand.cls.label.rnk

        cls.bin.rnk[cls.bin.rnk!=rnk]<-0

        cls.bin.rnk[cls.bin.rnk==rnk]<-1

        cls1<-cls0<-cls.bin.rnk

        cls1[cls1==0]<-NA

        cls0[cls0==1]<-NA

        cls0[cls0==0]<-1

        # order gene in data.rnk

        data<-as.matrix(data.rnk)

        data1.tr<-apply(t(data)*cls1,2,na.omit)

        data0.tr<-apply(t(data)*cls0,2,na.omit)

        mean1<-apply(data1.tr,2,mean)

        mean0<-apply(data0.tr,2,mean)

        sd1<-apply(data1.tr,2,sd)

        sd0<-apply(data0.tr,2,sd)

        #    rm(data1.tr)

        #    rm(data0.tr)

        #    gc()

        s2n<-(mean1-mean0)/(sd1+sd0)

        #    rm(mean1)

        #    rm(mean0)

        #    rm(sd1)

        #    rm(sd0)

        #    gc()

        order.gene.s2n.rnk<-cbind(order(s2n,decreasing=T),sort(s2n,decreasing=T))

        #    rm(s2n)

        #    gc()

        for (mkr in 1:num.subcls.mkr)
        {
            # convert mkr cls to binary

            cls.bin.mkr<-cand.cls.label.mkr

            cls.bin.mkr[cls.bin.mkr!=mkr]<-0

            cls.bin.mkr[cls.bin.mkr==mkr]<-1

            cls1<-cls0<-cls.bin.mkr

            cls1[cls1==0]<-NA

            cls0[cls0==1]<-NA

            cls0[cls0==0]<-1

            #        rm(cls.bin)

            #        gc()

            # order gene, take marker

            data<-as.matrix(data.mkr)

            data1.tr<-apply(t(data)*cls1,2,na.omit)

            data0.tr<-apply(t(data)*cls0,2,na.omit)

            mean1<-apply(data1.tr,2,mean)

            mean0<-apply(data0.tr,2,mean)

            sd1<-apply(data1.tr,2,sd)

            sd0<-apply(data0.tr,2,sd)

            #        rm(data1.tr)

            #        rm(data0.tr)

            #        gc()

            s2n<-(mean1-mean0)/(sd1+sd0)

            #        rm(mean1)

            #        rm(mean0)

            #        rm(sd1)

            #        rm(sd0)

            #        gc()

            order.gene.mkr<-order(s2n,decreasing=T)

            marker<-order.gene.mkr[1:ntag]

            # ES

            tag.indicator <- sign(match(order.gene.s2n.rnk[,1], marker, nomatch=0))

            no.tag.indicator <- 1 - tag.indicator

            N <- length(order.gene.s2n.rnk[,1])

            Nh <- length(marker)

            Nm <-  N - Nh

            if (weighted.score.type == 0)
            {
                correl.vector <- rep(1, N)

            }
            else
            {
                alpha <- weighted.score.type

                correl.vector <- abs(order.gene.s2n.rnk[,2]**alpha)
            }

            sum.correl.tag    <- sum(correl.vector[tag.indicator == 1])

            norm.tag    <- 1.0/sum.correl.tag

            norm.no.tag <- 1.0/Nm

            RES <- cumsum(tag.indicator * correl.vector * norm.tag - no.tag.indicator * norm.no.tag)

            max.ES <- max(RES)

            min.ES <- min(RES)

            #        rm(RES)

            #        gc()

            if (max.ES > - min.ES)
            {
                ES.matrix[mkr,rnk] <- max.ES
            }
            else
            {
                ES.matrix[mkr,rnk] <- min.ES
            }
        }      # loop end num.subcls.rnk
    }        # loop end num.subcls.mkr

    return(ES.matrix)

}  # end of submap


# read clustid & generate candidate cls labels
read.sample.info<-function(filename="NULL")
{
    if (regexpr(".txt$",filename)==-1)
    {
        stop("### input data should be .txt file! ###")
    }

    sample.info<-read.delim(filename,header=T)

    sample.info[,1]<-NULL

    sample.info[,1]<-NULL

    return(sample.info)
}


cand.cls.box<-function(clustid)
{
  table.clustid<-table(clustid)

  cls.box<-as.numeric(rownames(table.clustid))

  return(cls.box)
}


# read data.frame, .gct, or .txt
read.gct<-function(filename="NULL")
{
    if (regexpr(".gct$",filename)==-1)
    {
        stop("### input data should be .gct file! ###")
    }

    data<-read.delim(filename, header=T, sep="\t", skip=2, row.names=1, blank.lines.skip=T, comment.char="", as.is=T)

    data<-data[order(data[,1]),]

    data<-data[-1]

    return(data)
}


take.intersection<-function(data.A,data.B)
{
    feature.name<-rownames(data.A)

    data.A<-cbind(feature.name,data.A)

    feature.name.B<-as.data.frame(rownames(data.B))

    colnames(feature.name.B)<-"feature.name"

    intersected<-merge(feature.name.B,data.A)

    rownames(intersected)<-intersected[,1]

    intersected<-intersected[-1]

    return(intersected)
}

setLibPath <- function(libdir) {
	libPath <- libdir
	if(!file.exists(libdir)) {
		# remove trailing /
		libPath <- substr(libdir, 0, nchar(libdir)-1)
	}
	.libPaths(libPath)
}

is.package.installed <- function(libdir, pkg) {
	f <- paste(libdir, pkg, sep='')
	return(file.exists(f) && file.info(f)[["isdir"]])
}


install.package <- function(dir, windows, mac, other) {
	isWindows <- Sys.info()[["sysname"]]=="Windows"
	isMac <- Sys.info()[["sysname"]]=="Darwin" 
	if(isWindows) {
		f <- paste(dir, windows, sep="")
		.install.windows(f)
	} else if(isMac) {
		f <- paste(dir, mac, sep="")
      .install.unix(f)
	} else { # install from source
		f <- paste(dir, other, sep="")
		.install.unix(f)
	}	
}

.install.windows <- function(pkg) {
	install.packages(pkg, .libPaths()[1], repos=NULL)
}

.install.unix <- function(pkg) {
    lib <- .libPaths()[1]
   # cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL --with-package-versions")
	 cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL")
    cmd <- paste(cmd, "-l", lib)
    cmd <- paste(cmd, " '", pkg, "'", sep = "")
    status <- system(cmd)
    if (status != 0) 
    	cat("\tpackage installation failed\n")
}



.install.unix <- function(pkg)
{
    lib <- .libPaths()[1]

    # cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL --with-package-versions")

    cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL")

    cmd <- paste(cmd, "-l", lib)

    cmd <- paste(cmd, " '", pkg, "'", sep = "")

    status <- system(cmd)

    if (status != 0)
        cat("\tpackage installation failed\n")
}

