/**
 * Copyright (C) 2005 Brian D. Piening
 *
 * The contents of this file are subject to the Academic Free License 2.1,
 * you may not use this file except in compliance with the License.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 **/

package org.fhcrc.edi.proteoArray;

import java.io.*;

import java.util.*;

import java.lang.Math.*;


/**
 * Writes a peptide array to .gct file
 *
 * @author Brian D. Piening <bpiening@fhcrc.org>
 * @version 0.1
 * @see ProteoArray
 */

public class GCTWrite {


    int samples = 0;

    File[] files;

    Hashtable peaks;

    GCTWrite(int samples1, File[] filelist, Hashtable peaks1) {

        samples = samples1;

        files = filelist;

        peaks = peaks1;

    }

    /**
     * Writes peptide array to file in gct format
     *
     * @param outfilename requested filename of output
     */

    public void writeGctFile(String outfilename) {


        try {

            if (!outfilename.toLowerCase().endsWith(".gct")) {

                outfilename += ".gct";

            }

            FileWriter fileout = new FileWriter(outfilename);

            //System.out.println("Writing .gct file...");

            //Write header

            fileout.write("#1.2\n");

            Integer newint = new Integer(peaks.size());


            fileout.write(newint.toString());

            fileout.write("\t");

            fileout.write(new Integer(samples).toString());

            fileout.write("\n");


            fileout.write("Name");

            fileout.write("\t");

            fileout.write("Description");

            fileout.write("\t");

            for (int i = 0; i < samples; i++) {


                String filename = files[i].getName();

                // strip .mzXML

                filename = filename.substring(0, filename.length() - 6);

                fileout.write(filename);

                fileout.write("\t");

                //fileout.write("\t");


            }

            fileout.write("\n");


            for (Enumeration e = peaks.keys(); e.hasMoreElements();) {

                String newstring = (String) e.nextElement();

                if (peaks.containsKey(newstring)) {

                    Float[][] ion = (Float[][]) peaks.get(newstring);



                    //	int j = 0;

                    float newmass = 0;

                    int masscounter = 0;

                    ArrayList retentionList = new ArrayList();


                    for (int i = 0; i < samples; i++) {

                        if (ion[i][1] == null) {

                            ion[i][1] = new Float(1.0);


                        } else {


                        }

                        // average masses for present peaks

                        if (ion[i][0] != null) {

                            // calculate average mass



                            newmass = newmass + ion[i][0].floatValue();

                            retentionList.add(ion[i][4]);


                            masscounter++;

                        }

                    }

                    // round mass values for each sample to get accurate mass

                    newmass = newmass / masscounter;

                    float rtmean = average(retentionList);

                    rtmean = round(rtmean, 2);


                    float rtdev = stdev(retentionList);

                    rtdev = round(rtdev, 2);

                    newmass = round(newmass, 4);

                    //Float massval = new Float(newmass);





                    //write key

                    fileout.write(newstring);

                    //    fileout.write(massval.toString());

                    fileout.write("\t");



                    // write desc & mass

                    fileout.write("AvgMass_" + newmass + "_RTMean_" + rtmean + "_SampRT");


                    // write retention times of peak across all samples
                    for (int j = 0; j < samples; j++) {

                        if (ion[j][4] != null) {

                            fileout.write("_" + ion[j][4]);


                        } else {
                            fileout.write("_0");

                        }

                    }

                    fileout.write("\t");


                    for (int k = 0; k < samples; k++) {


                        fileout.write(ion[k][1].toString());


                        fileout.write("\t");

                    }

                    fileout.write("\n");

                }


            }



//            System.out.println("GCT file written");

            fileout.close();

        } catch (FileNotFoundException e) {

            System.out.println("Could not find specified file.");

            System.exit(0);

        } catch (IOException e) {

            System.out.println("File system error.");

            System.exit(0);

        }

    }


    /**
     * calculate mean retention time of features
     *
     * @param list
     * @return average time of a given feature across multiple experiments
     */

    public float average(ArrayList list) {


        float mean = 0;

        int size = list.size();

        for (int i = 0; i < size; i++) {


            Float newdub = (Float) list.get(i);

            mean = mean + newdub.floatValue();

        }

        mean = mean / size;

        return mean;

    }


    /**
     * calculate standard deviation of retention time of features
     *
     * @param list
     * @return std deviation in time of a given feature across multiple experiments
     */

    public float stdev(ArrayList list) {

        float mean = average(list);

        float stdevflt = 0;

        int size = list.size();

        for (int i = 0; i < size; i++) {

            Float newflt = (Float) list.get(i);

            float tempflt = newflt.floatValue() - mean;

            tempflt = tempflt * tempflt;

            stdevflt = stdevflt + tempflt;


        }

        stdevflt = stdevflt / size;

        Double dub2 = new Double(Math.sqrt(stdevflt));

        float stdeviation = dub2.floatValue();

        return stdeviation;


    }



    /*

    * Round a float value to a specified number of decimal

    * places.

    */

    public static float round(float val, int places) {

        long factor = (long) Math.pow(10, places);



        // Shift the decimal the correct number of places

        // to the right.

        val = val * factor;



        // Round to the nearest integer.

        long tmp = Math.round(val);



        // Shift the decimal the correct number of places

        // back to the left.

        return (float) tmp / factor;

    }


}



