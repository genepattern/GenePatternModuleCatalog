/**
 * Copyright (C) 2005 Brian D. Piening
 *
 * The contents of this file are subject to the Academic Free License 2.1,
 * you may not use this file except in compliance with the License.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 **/

package org.fhcrc.edi.proteoArray;

import java.util.*;
import java.io.File;

/**
 * Class for aligning features across multiple experiments.  Matches peaks by mass and retention time
 * within thresholds of 0.1 Da and 200 seconds, respectively.
 *
 * @author Brian D. Piening <bpiening@fhcrc.org>
 * @version 0.1
 * @see ProteoArray
 */
public class AlignRuns {
    // Hashtable containing featurelist and intensities for each sample
    public Hashtable peaks = new Hashtable();

    // for sample-to-sample alignment, align if 2 peaks elute within
    // certain number of scans
    final static int RETENTION_WINDOW = 200;

    // number of decimal places to round mass
    final static int roundMass = 1;
    int sample = -1;
    protected int totSample = 0;


    public AlignRuns() {

    }

    public void setTotSample(int tot) {
        totSample = tot;
    }

    // Call readflatmz class to initiate mass binning
    public void loadFile(File file) {

        sample++;
        FindFeatures newSample = new FindFeatures();

        // process single sample & output hashtable
        newSample.fileHandler(file);

        Hashtable temphash = newSample.getHashTable();

        // store single sample in hash
        storeHash(temphash);

        System.out.println("Total features : " + getNumBuckets());
    }


    // Take old hashtable, consolidate peaks and store in new hashtable
    public void storeHash(Hashtable temphash) {

        for (Enumeration e = temphash.keys(); e.hasMoreElements();) {
            String masskey = (String) e.nextElement();
            if (temphash.containsKey(masskey)) {
                Float[] newPeak = (Float[]) temphash.get(masskey);
                consolidate(masskey, newPeak);

            }
        }
    }

    public String stripEndChars(String massString) {
        int x = massString.lastIndexOf('_');
        String massString2;
        if (x > 0) {
            massString2 = massString.substring(0, x);
            //   System.out.println(massString2);
        } else {
            massString2 = massString;
        }
        return massString2;
    }

    /**
     * Take a single feature and attempt to align with other features from previous experiments.
     *
     * @param masskey
     * @param newPeak
     */
    public void consolidate(String masskey, Float[] newPeak) {

        // false if mass is not matched to previous sample alignment
        boolean massFound = false;

        // hash key
        String massStr = masskey;
        String massString;
        //String storeMass=null;
        Double retentionMatch = null;
        int massCount = -1;
        String massMatch = null;
        //String lastMass = null;

        massString = stripEndChars(massStr);

        /* match mass with retention time, if multiple matches are in window,
        find closest match
        */
        while (massFound == false) {


            // see if peak is already in hashtable
            if (peaks.containsKey(massString)) {

                // get previously stored peak from hashtable
                Float[][] oldion = (Float[][]) peaks.get(massString);

                // store old retention time for compare
                double oldretention = 0;
                int retentionCounts = 0;

                // don't bin peaks together from same sample
                if (oldion[sample][4] == null) {
                    // calculate avg retention across peaks from previous samples
                    for (int i = 0; i < sample; i++) {
                        if (oldion[i][4] != null) {

                            oldretention = oldretention + oldion[i][4].doubleValue();

                            retentionCounts++;
                        }
                    }
                    // if previous samples exist, avg retention
                    if (oldretention > 0) {
                        oldretention = oldretention / retentionCounts;

                        // calc diff btw retention and avg from prev samples
                        double retention = newPeak[4].floatValue();
                        double newRetention = Math.abs(oldretention - retention);

                        // if diff is less than window, put in closest bin
                        if (newRetention <= RETENTION_WINDOW) {

                            // retention within window, mass matched

                            if (retentionMatch == null || retentionMatch.doubleValue() > newRetention) {
                                retentionMatch = new Double(newRetention);
                                massMatch = massString;
                            } else { // retention not smallest out of others in hash


                            }
                        } else { // retention not less than threshold, do nothing

                        }
                    }
                } else {

                }

                // Check for others in same retention window in hash
                massCount++;
                String massString2 = stripEndChars(massString);
                massString = massString2.toString() + "_" + massCount;
            }


            // mass not found, end loop
            else {
                massFound = true;
            }

        }

        // if matched to previous bin, add
        if (retentionMatch != null) {  // match found, add

            // get previously stored peak from hashtable
            Float[][] oldion = (Float[][]) peaks.get(massMatch);

            for (int i = 0; i < 6; i++) {
                oldion[sample][i] = newPeak[i];
            }

            peaks.put(massMatch.toString(), oldion);
        }


        // no match detected so just hash peak in new hash
        else {

            Float[][] ionArray = new Float
                    [totSample][6];
            for (int i = 0; i < 6; i++) {
                ionArray[sample][i] = newPeak[i];
            }
            if (massString != null) {
                peaks.put(massString, ionArray);

            }

        }


    }

    public Hashtable getHashTable() {
        return peaks;
    }

    public int getNumBuckets() {
        Hashtable hashpeak = getHashTable();
        int numPeaks = hashpeak.size();
        return numPeaks;
    }


    /*
    * Round a double value to a specified number of decimal
    * places.
    */
    public static double round(double val, int places) {
        long factor = (long) Math.pow(10, places);

        // Shift the decimal the correct number of places
        // to the right.
        val = val * factor;

        // Round to the nearest integer.
        long tmp = Math.round(val);

        // Shift the decimal the correct number of places
        // back to the left.
        return (double) tmp / factor;
    }

}
