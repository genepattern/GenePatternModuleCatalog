/**
 * Copyright (C) 2005 Brian D. Piening
 *
 * The contents of this file are subject to the Academic Free License 2.1,
 * you may not use this file except in compliance with the License.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 **/

package org.fhcrc.edi.proteoArray;

import java.util.*;

import org.systemsbiology.jrap.Scan;

import java.lang.reflect.*;
import java.io.File;

/**
 * FindFeatures class processes a single mzXML file of LC-MS data.  A given .mzXML contains a series of consecutive
 * spectra for the duration of the MS experiment.  This class iterates over these spectra to find peaks.  In a single
 * spectrum, a 'feature' is detected if the signal is above the threshold value.  Features in consecutive spectra are
 * binned if within 0.1 Da mass tolerance.  Features that appear in at least 5 consecutive spectra are retained as
 * true peptide signals, while others are discarded as random noise.  The intensity of a feature is computed as the
 * sum of the feature's signal intensity in consecutive spectra.  The elution time of a feature is computed as the
 * scan number of the maximum intensity for that feature.  Accurate mass for a feature is computed as the mass at the
 * feature's intensity maximum, if below the saturation threshold (1000 counts).
 *
 * @author Brian D. Piening <bpiening@fhcrc.org>
 * @version 0.1
 * @see ProteoArray
 */
public class FindFeatures {

    // indicator for which scan number
    private int scan = 0;

    /**
     * number of decimal places to round mass for binning (default 0.1 Da)
     */
    final static int ROUND_DIGITS = 1;


    final static int SCAN_GAP = 200;

    /**
     * Dead time parameter asseses mass before high intensity peaks reach saturation.
     * Important for calculating masses on time of flight instruments where dead time
     * affects mass.
     */
    final static int DEAD_TIME = 2000;
    /**
     * number of consecutive spectra with a signal in order to characterize as real feature
     */
    final static int BINSIZE = 7;

    /**
     * intensity threshold for distinguishing signal from noise
     */
    final static int THRESHOLD = 150;
    /**
     * number of features detected
     */
    protected int numFeatures = 0;


    /**
     * features stored in hashtable for random access, binned mass is key
     */
    private Hashtable peaks = new Hashtable();

    /**
     * max scan to process in file, debug only
     */
    protected int maxScan = 0;

    // default constructor
    public FindFeatures() {

    }

    /**
     * Constructor for debug purposes.  Only process until scan # given by variable 'scan'.
     *
     * @param scan
     */
    public FindFeatures(int scan) {

        maxScan = scan;

    }


    /**
     * Instantiates mzXML parser on input file and loops through available scans.  Within a scan, loops through
     * datapoints in spectrum, storing peak if above threshold.
     *
     * @param newfile mzXML file for parsing
     */
    public void fileHandler(File newfile) {

        // xml parser
        MZXMLRead xmlRead = new MZXMLRead(newfile);

        if (maxScan == 0) {
            maxScan = xmlRead.getScanCount() + 1;
        }

        // main loop
        for (int i = 1; i < maxScan; i++) {
            scan = i;
            Scan newScan = xmlRead.getScan(i);
            // get spectrum: array of mass/intensity pairs
            float[][] peaks = newScan.getMassIntensityList();

            int size = Array.getLength(peaks[0]);
            for (int j = 0; j < size; j++) {
                float mass = peaks[0][j];
                float intensity = peaks[1][j];

                // if peak is present, hash peak
                if (intensity > THRESHOLD) {
                    Float newmass = new Float(mass);
                    Float newintens = new Float(intensity);
                    storeHash(newmass, newintens);

                    numFeatures++;
                }
            }
        }
        //System.out.println("Number of features: "+ hashBuckets);
        cleanHash();
        System.out.println("Num raw peaks: " + numFeatures);
        System.out.println("Number of features: " + getNumBuckets());
    }


    /**
     * Find out if mass/intensity pair matches to feature already detected in previous scans.  If not, store
     * as new feature.
     *
     * @param mass      m/z of peak
     * @param intensity intensity of peak
     */
    public void storeHash(Float mass, Float intensity) {

        boolean inHash = false;
        int i = 0;

        // round mass to 1 decimal for storage in hashtable
        float mass2 = round(mass.floatValue(), ROUND_DIGITS);

        Float roundmass = new Float(mass2);

        String stringmass = roundmass.toString();

        while (inHash == false) {
            // see if peak is already in hashtable
            if (peaks.containsKey(stringmass)) {


                // get previously stored data at hash location
                Float[] oldpeak = (Float[]) peaks.get(stringmass);

                // if peak is within retention time of last peak, store
                // look at previously stored item
                float endRT = oldpeak[3].floatValue();
                float startRT = oldpeak[2].floatValue();

                // does peak fall within same elution window as bin?
                if ((scan - endRT) < SCAN_GAP) {
                    // remove from hashtable
                    peaks.remove(stringmass);

                    // store
                    Float[] feature = addFeature(mass, intensity, scan, oldpeak);

                    // put list at specified mass back in hashtable
                    peaks.put(stringmass, feature);

                    inHash = true;
                } else {  //else make new feature in hastable because retention times don't match
                    if (endRT - startRT < BINSIZE) {
                        // remove and start over
                        peaks.remove(stringmass);
                    } else {
                        stringmass = roundmass.toString() + "_" + i;
                    }
                }

            } else {  // no peak detected, hash peak
                Float[] feature = addFeature(mass, intensity, scan);

                peaks.put(stringmass, feature);
                inHash = true;
            }
            i++;
        }
    }


    /**
     * Adds mass intensity pair to feature previously detected, summing intensity.
     *
     * @param mass
     * @param intensity
     * @param scan
     * @param newPeaks  Previous value in hashtable
     * @return Float array containing feature information (mass,intensity,startscan,endscan,maxscan,maxintensity)
     */
    public Float[] addFeature(Float mass, Float intensity, int scan, Float[] newPeaks) {

        float newintensity = newPeaks[1].floatValue() + intensity.floatValue();

        // last scan
        float endRT = scan;

        float maxRT, maxRTint, maxMass, startRT;
        // get previous start point
        startRT = newPeaks[2].floatValue();
        // if largest peak in hash, store accurate mass
        if (intensity.floatValue() > newPeaks[5].floatValue()) {
            maxRT = scan;
            maxRTint = intensity.floatValue();
            // Take accurate mass before dead time
            if (intensity.floatValue() < DEAD_TIME) {
                maxMass = mass.floatValue();
            } else {
                maxMass = newPeaks[0].floatValue();
            }
        } else {

            maxRT = newPeaks[4].floatValue();
            maxRTint = newPeaks[5].floatValue();
            maxMass = newPeaks[0].floatValue();
        }

        Float[] feature = new Float[6];


        feature[0] = new Float(maxMass); // accurate mass
        feature[1] = new Float(newintensity);  //summed intensity
        feature[2] = new Float(startRT);  //initial retention time
        feature[3] = new Float(endRT);  //end retention time
        feature[4] = new Float(maxRT);  //retention time at max
        feature[5] = new Float(maxRTint); //intensity at max retention time
        return feature;
    }

    /**
     * Stores a mass/intensity pair as a Float[] feature with scan number (time)
     *
     * @param mass
     * @param intensity
     * @param scan
     * @return Float array containing feature information (mass,intensity,startscan,endscan,maxscan,maxintensity)
     */
    public Float[] addFeature(Float mass, Float intensity, int scan) {

        Float[] feature = new Float[6];

        // mass
        feature[0] = mass;
        // intensity
        feature[1] = intensity;
        // peak start
        feature[2] = new Float(scan);
        // peak end
        feature[3] = new Float(scan);
        // peak max
        feature[4] = new Float(scan);
        // intensity at peak max
        feature[5] = intensity;
        return feature;
    }

    /**
     * Iterates through hashtable of features and removes features that have elution profiles <5 seconds.
     * These are probably not real peptides.
     */
    public void cleanHash() {
        for (Enumeration e = peaks.keys(); e.hasMoreElements();) {
            String masskey = (String) e.nextElement();
            if (peaks.containsKey(masskey)) {
                Float[] newPeak = (Float[]) peaks.get(masskey);
                float startRT = newPeak[2].floatValue();
                float endRT = newPeak[3].floatValue();
                if ((endRT - startRT) < BINSIZE) {
                    peaks.remove(masskey);
                    // System.out.println("Removed peak: "+masskey+" "+startRT+" "+endRT);
                }
            }
        }
    }

    /**
     * Round a float value to a specified number of decimal
     * places.
     */
    public static float round(float val, int places) {
        long factor = (long) Math.pow(10, places);

        // Shift the decimal the correct number of places
        // to the right.
        val = val * factor;

        // Round to the nearest integer.
        long tmp = Math.round(val);

        // Shift the decimal the correct number of places
        // back to the left.
        return (float) tmp / factor;
    }


    /**
     * Round a double value to a specified number of decimal
     * places.
     */
    public static double round(double val, int places) {
        long factor = (long) Math.pow(10, places);

        // Shift the decimal the correct number of places
        // to the right.
        val = val * factor;

        // Round to the nearest integer.
        long tmp = Math.round(val);

        // Shift the decimal the correct number of places
        // back to the left.
        return (double) tmp / factor;
    }

    /**
     * getter for hashtable of features
     *
     * @return hashtable of features in mzXML file.  Keys are masses of features.
     */
    public Hashtable getHashTable() {
        return peaks;
    }

    /**
     * get number of features in hashtable
     *
     * @return number of features in an mzXML file.
     */
    public int getNumBuckets() {
        Hashtable newpeak = getHashTable();
        int numpeaks = newpeak.size();
        return numpeaks;
    }



}
