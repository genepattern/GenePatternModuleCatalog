/**
 * Copyright (C) 2005 Brian D. Piening
 *
 * The contents of this file are subject to the Academic Free License 2.1,
 * you may not use this file except in compliance with the License.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 **/

package org.fhcrc.edi.proteoArray;

import sun.misc.Queue;


import java.io.*;

import java.util.*;

import java.util.zip.*;

import java.lang.reflect.Array;


/**
 * Software package for batch processing of mzXML files into a peptide array.  Process includes storing and binning
 * <p/>
 * features by mass and retention time in a single ms experiment, computing signal intensity of each feature,
 * <p/>
 * aligning features across multiple ms experiments by mass and retention time.
 * <p/>
 * <p/>
 * <p/>
 * Output file is a peptide feature array
 * <p/>
 * in .gct file format as supported by GenePattern (Broad Institute) for statistical discovery analyses (clustering,
 * <p/>
 * class neighbors).
 *
 * @author Brian D. Piening <bpiening@fhcrc.org>
 * @version 0.1
 * @see ProteoArray
 */

public class ProteoArray {


    /**
     * Hashtable containing features
     */

    Hashtable peaks = new Hashtable();



    // number of samples

    int samples = 0;

    int totSample = 0;


    /**
     * Unzips the given zip file
     *
     * @param zipPathname the zip file
     * @return an array of mzXML files
     * @throws IOException if an error occurs while extracting the zip file
     */

    public static File[] unzip(String zipPathname) throws IOException {

        ZipFile zipFile = null;

        File destinationDir = new File(System.getProperty("user.dir"));

        List files = new ArrayList();

        try {

            zipFile = new ZipFile(zipPathname);

            for (Enumeration eEntries = zipFile.entries(); eEntries.hasMoreElements();) {

                ZipEntry zipEntry = (ZipEntry) eEntries.nextElement();

                OutputStream os = null;

                InputStream is = null;

                try {

                    is = zipFile.getInputStream(zipEntry);

                    String name = zipEntry.getName();

                    if (zipEntry.isDirectory() || name.indexOf("/") != -1 || name.indexOf("\\") != -1) {

                        // TODO: mkdirs()

                        continue;

                    }

                    File outFile = new File(destinationDir, name);

                    if (outFile.getName().toLowerCase().endsWith(".mzxml")) {

                        files.add(outFile);

                    }


                    os = new FileOutputStream(outFile);

                    long fileLength = zipEntry.getSize();

                    byte[] buf = new byte[100000];

                    int i = 0;

                    while ((i = is.read(buf, 0, buf.length)) > 0) {

                        os.write(buf, 0, i);

                    }

                    os.close();

                    outFile.setLastModified(zipEntry.getTime());

                    outFile.deleteOnExit();

                } finally {

                    if (os != null) {

                        os.close();

                    }

                    is.close();

                }

            }

        } finally {

            if (zipFile != null) {

                zipFile.close();

            }

        }

        return (File[]) files.toArray(new File[0]);

    }


    /**
     * Load a directory
     *
     * @param directoryname directory containing mzXML dataset
     * @param outfilename
     */

    public void loadDir(String directoryname, String outfilename) {

        System.out.println(directoryname);


        Queue queue = new Queue();

        File dir = new File(directoryname);     // root directory


        File[] files = dir.listFiles();

        if (Array.getLength(files) == 0) {

            System.out.println("No files found in directory " + directoryname);

        }

        System.out.println(Array.getLength(files));

        processBatch(files, outfilename);


    }


    /**
     * Process all mzXML files in a directory.
     *
     * @param files
     * @param outfilename
     */

    public void processBatch(File[] files, String outfilename) {


        //   int i = 0;

        //   samples = 0;





        int totFiles = Array.getLength(files);







        // instance of readMzFlat

        AlignRuns ar = new AlignRuns();

        try {


            for (int i = 0; i < totFiles; i++) {


                String filename = files[i].getCanonicalPath();

                String extension = filename.substring(filename.length() - 6, filename.length());

                if (extension.equalsIgnoreCase(".mzXML")) {

                    totSample++;

                }

            }


            ar.setTotSample(totSample);

            System.out.println("Total Samples " + totSample);

            for (int i = 0; i < totFiles; i++) {

                String filename = files[i].getCanonicalPath();

                String extension = filename.substring(filename.length() - 6, filename.length());

                if (extension.equalsIgnoreCase(".mzXML")) {

                    ar.loadFile(files[i]);

                }

            }


        } catch (IOException e) {

            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.

        }

        // load files, align peaks, store in hash

        //loadBatch(nameArray, totSample, ar);



        peaks = ar.getHashTable();

        GCTWrite gctWrite = new GCTWrite(totSample, files, peaks);

        gctWrite.writeGctFile(outfilename);

    }


    /**
     * Process an array of mzXML files.
     *
     * @param files,      an array of mzXML files
     * @param outfilename the output gct file name
     */

    public void processMZXMLFiles(File[] files, String outfilename) {

        totSample = files.length;

        AlignRuns ar = new AlignRuns();

        ar.setTotSample(files.length);

        System.out.println("Total Samples " + totSample);

        for (int i = 0; i < totSample; i++) {

            ar.loadFile(files[i]);

        }



        // load files, align peaks, store in hash

        peaks = ar.getHashTable();

        GCTWrite gctWrite = new GCTWrite(totSample, files, peaks);

        gctWrite.writeGctFile(outfilename);

    }


    /**
     * @return hashtable of aligned features
     */

    public Hashtable getHashtable() {

        return peaks;

    }


    public static void main(String[] args) {


        File[] mzXMLFiles = null;

        if (args.length == 2) {

            ProteoArray newProt = new ProteoArray();

            try {

                mzXMLFiles = unzip(args[0]);

            } catch (IOException ioe) {

                System.err.println("An error occurred while extracting the zip file.");

                System.exit(1);

            }

            if (mzXMLFiles.length == 0) {

                System.err.println("No mzXML files found");

                System.exit(1);

            }

            newProt.processMZXMLFiles(mzXMLFiles, args[1]);

        } else {

            System.out.println("Usage: ProteoArray [zip file] [outfilename] ");

            System.exit(0);


        }

    }

}





