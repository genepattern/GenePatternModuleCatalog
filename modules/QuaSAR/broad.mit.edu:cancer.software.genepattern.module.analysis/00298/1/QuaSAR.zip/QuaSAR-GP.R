# $Id: QuaSAR-GP.R 107 2012-06-25 18:37:49Z rahmad $
print ("$Id: QuaSAR-GP.R 107 2012-06-25 18:37:49Z rahmad $", quote=FALSE)

# The Broad Institute of MIT and Harvard
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2009) by the
# Broad Institute. All rights are reserved.

# This software is supplied without any warranty or guaranteed support
# whatsoever. The Broad Institute cannot be responsible for its
# use, misuse, or functionality.

## suppress warnings (else GenePattern thinks an error has occurred)
options (warn = -1)
debug = FALSE

##
## Command line processing and other functions to support GenePattern
##

parse.cmdline <- function (...) {
  # set up for command line processing (if needed)
  # arguments are specified positionally (since there are no optional arguments) and
  args <- list (...)
  if ( length (args) != 16 )
    # expected arguments not present -- error
    stop ("USAGE: R --slave --no-save --args '<libdir> <skyline.file> <concentration.file> <title> <analyte> <standard>\n
                  <generate.cv.table> <generate.calcurves> <generate.lodloq.table> <generate.peak.area.plots> <use.par> <max.calcurve.linear.scale>\n
                  <max.calcurve.log.scale> <perform.audit> <audit.cv.threshold> <output.prefix>' < QuaSAR-GP.r\n")
    
  for (i in 1:16) {
    arg <- args [i]
    # remove leading and trailing blanks
    arg <- gsub ("^ *", "", arg)
    arg <- gsub (" *$", "", arg)
    # remove any embedded quotation marks
    arg <- gsub ("['\'\"]", "", arg)
    if (i==1) libdir <<- arg
    if (i==2) skylineFile <<- arg
    if (i==3) concentrationFile <<- arg
    if (i==4) site <<- arg
    if (i==5) analyteName <<- arg
    if (i==6) standardName <<- arg
    if (i==7) generateCVTable <<- as.numeric (arg)
    if (i==8) generateCalcurves <<- as.numeric (arg)
    if (i==9) generateLODLOQTable <<- as.numeric (arg)
    if (i==10) generatePeakAreaPlots <<- as.numeric (arg)
    if (i==11) usePAR <<- as.numeric (arg)
    if (i==12) maxLinearScale <<- as.numeric (arg)
    if (i==13) maxLogScale <<- as.numeric (arg)
    if (i==14) performAudit <<- as.numeric (arg)
    if (i==15) CVThreshold <<- as.numeric (arg)
    if (i==16) outputPrefix <<- arg
  }
  if (libdir == "NULL") libdir <- NULL

  # for use in GenePattern
  if (! is.null (libdir) ) {
    source (paste (libdir, "QuaSAR.R", sep=''))
    source (paste (libdir, "common.R", sep=''))
    if (libdir!='') {
      setLibPath(libdir)
      install.required.packages(libdir)
    }
  }  

  # load libraries
  suppressPackageStartupMessages(library(RColorBrewer))
  suppressPackageStartupMessages(library(gtools))
  suppressPackageStartupMessages(library(MASS))
  suppressPackageStartupMessages(library(reshape))
  suppressPackageStartupMessages(library(lattice))
  suppressPackageStartupMessages(library(ggplot2))

  # write summary of experiment to a summary file
  filename <- paste (outputPrefix, '-parameters-summary.csv', sep='')

  # get the input CSV file names
  file.name <- unlist(strsplit(skylineFile, "/"))
  input.file.name <- file.name[length(file.name)]
  file.name <- unlist(strsplit(concentrationFile, "/"))
  conc.file.name <- file.name[length(file.name)]

  params <- c("Input Data File", "Input Concentration File", "Experiment Title", 
               "Analyte Name", "Internal Standard Name", "Perform AuDIT", "Generate CV Table", "Generate Calibration Curves", 
               "Generate LOD and  LOQ Tables", "Generate Peak Area Plots", "Use PAR for analysis", "Liner Scale Maximum", "Log Scale Maximum",
               "AuDIT: CV threshold")

  if (performAudit) {audit <- "yes"} else {audit <- "no"}
  if (generateCVTable) {cvtable <- "yes"} else {cvtable <- "no"}
  if (generateCalcurves) {calcurves <- "yes"} else {calcurves <- "no"}
  if (generateLODLOQTable) {lodloqtable <- "yes"} else {lodloqtable <- "no"}
  if (generatePeakAreaPlots) {peakareaplots <- "yes"} else {peakareaplots <- "no"}
  if (usePAR) {dopar <- "yes"} else {dopar <- "no"}
  if (generatePeakAreaPlots) {peakareaplots <- "yes"} else {peakareaplots <- "no"}

  params.values <- c(input.file.name, conc.file.name, site, 
                     analyteName, standardName, audit, cvtable, calcurves,
                     lodloqtable, peakareaplots, dopar, maxLinearScale, maxLogScale,
                     CVThreshold)

  paramdata <- data.frame(parameters=params, values=params.values)
  write.table(paramdata, filename, sep=",",row.names=F)

  # library for displaying minor tick marks on a plot
  # example: minor.tick(nx=2, ny=2, tick.ratio=0.5)
  # library(Hmisc)

  # get user specified analyte and internal standard names. 
  # this has to match the column header names in the input CSV file
  light.label <- make.names(analyteName)
  heavy.label <- make.names(standardName)

  # check format of input data file and preprocess
  # currently only processing Skyline formatted data files
  data <- preprocess.datafile (skylineFile, skyline.export=TRUE, light.label=light.label,heavy.label=heavy.label)
  concentrationFile <- preprocess.concfile (concentrationFile)

  # determine if the internal standard concentration is the same for all analytes
  unique.is.conc <- unique(concentrationFile[,"is.conc"])
  if (length(unique.is.conc) == 1) {
	heavySpikeConc = unique.is.conc[1]
  } else {
	heavySpikeConc = "variable"
  }

  if (debug) write.csv (concentrationFile, file = paste (outputPrefix, '-concentraionFile.csv', sep=''), row.names=FALSE)


  # if peak are ratio, PAR, is used for analysis then set area.ratio.multiplier=1, i.e. heavySpikeConc = 1
  # also for this case no corrections will be applied within the calculate function
  # this will override the user supplied value if peak area ratio is selected
  if (usePAR) {
    heavySpikeConc = 1
  }

  # if calibration curves or peak area plots are generated then LOD/LOQ has to be calculated
  # the LOD values are displayed in these plots, so force generateLODLOQTable = TRUE
  # if AuDIT is run then the bad transitions are plotted on the calibration curve plot
  if (generateCalcurves | generatePeakAreaPlots) generateLODLOQTable = TRUE

  # Call function that generates the data used for lod-loq tables and calibration plots 
  suppressMessages(calculate (data, concentrationFile,
                  output.prefix=outputPrefix, 
                  area.ratio.multiplier=heavySpikeConc,
                  lodloq.table=generateLODLOQTable, 
                  cv.table=generateCVTable, 
                  run.audit=performAudit, 
                  gen.peak.area.plots=generatePeakAreaPlots,
                  generate.cal.curves=generateCalcurves,
                  use.par=usePAR,
                  audit.cv.threshold=CVThreshold,
                  audit.row.limit=10000,
                  site.name=site, 
                  max.linear.scale=maxLinearScale, 
                  max.log.scale=maxLogScale,
                  plot.title=site))
}

install.required.packages <- function (libdir) {
  # install all required packages
  if (!is.package.installed (libdir, "gtools")) {
    install.package (libdir, "gtools_2.6.1.zip", "gtools_2.6.1.tgz","gtools_2.6.1.tar.gz")
  }
  
  if (!is.package.installed (libdir, "RColorBrewer")) {
    install.package (libdir, "RColorBrewer_1.0-5.zip", "RColorBrewer_1.0-5.tgz","RColorBrewer_1.0-5.tar.gz")
  }
  
  if (!is.package.installed (libdir, "MASS")) {
    install.package (libdir, "MASS_7.3-14.zip", "MASS_7.3-14.tgz","MASS_7.3-14.tar.gz")
  }
}


# END
