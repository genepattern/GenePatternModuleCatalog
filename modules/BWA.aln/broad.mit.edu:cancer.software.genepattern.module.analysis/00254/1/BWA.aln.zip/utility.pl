#!/usr/bin/perl

$zip_command = "zip";
$unzip_command = "unzip";

sub checkCompatibility
{
    $executable = shift;
    $exec_result = system(${executable}.' 2>/dev/null');

    #check if usage statistics were output
    if($exec_result == 256)
    {
        return 'true';
    }
    else
    {
        return 'false';
    }
}

sub zip_func
{
    $source = shift;
    $dest = shift;
    $options = shift;

    system("${zip_command} $options \"${dest}\" ${source}");
}

sub unzip_func
{
    $file = shift;
    $dest = shift;
    $options = shift;

    system("${unzip_command} $options -q -d ${dest} \"${file}\"");
}

sub setupExecutables
{
    $mac_version = shift;

	if (($Config{osname} eq 'linux') && ($Config{archname} =~m/64/))
    {
        $bwa_dir=$bwa_linux64_dir;
        $bwa_zip=$bwa_linux64_zip;
    }
    elsif (($Config{osname} eq 'darwin'))
    {
        if($mac_version eq 'mac64')
        {
            print "\nTrying to run 64-bit version";
            $bwa_dir=$bwa_mac64_dir;
            $bwa_zip=$bwa_mac64_zip;
        }
        elsif($mac_version eq 'mac32')
        {
            print "\nTrying to run 32-bit version";
            $bwa_dir=$bwa_mac32_dir;
            $bwa_zip=$bwa_mac32_zip;
        }
        else
        {
            print STDERR "\nUnexpected value for mac_version $mac_version. Expecting either mac64 or mac32";
            exit(1);
        }
    }
    else
    {
        print STDERR "\nThis module is not currently supported on this platform.";
        print STDERR "\nosname: $Config{osname}";
        print STDERR "\narchname: $Config{archname}\n";
        exit(1);
    }

    #extract bwa binary from zip if not already done
    if (!(-d "${bwa_dir}"))
    {
        unzip_func($bwa_zip, $libdir, '-q');
        rmtree(${bwa_zip});
    }
}