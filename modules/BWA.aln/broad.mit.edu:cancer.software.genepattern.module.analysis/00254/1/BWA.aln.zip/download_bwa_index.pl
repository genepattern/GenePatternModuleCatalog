#!/usr/bin/perl

use Net::FTP;
use Digest::MD5;
use File::Path;
require ${libdir}."utility.pl";

$ftp_host = "ftp.broadinstitute.org";
$index_path ="pub/genepattern/rna_seq/pre_built_index/bwa_index";
$filelock = "bwa_index_lock.txt";
$filelock_path = "";
$created_lock = "false";
$lock_wait_seconds = 5;

%genomeFileMap = ();
$md5CheckSumMap{"b_taurus_3.0_alg-bwtsw.1.zip"} = "597d1283aa10a418ebf51c4d38f1ee44";
$md5CheckSumMap{"b_taurus_3.0_alg-bwtsw.2.zip"} = "9585d7b37b06463d3e858caabaadf865";

$md5CheckSumMap{"hg19_alg-bwtsw.1.zip"} = "d6fc400583362f6051e6d2ec07b17c10";
$md5CheckSumMap{"hg19_alg-bwtsw.2.zip"} = "3724cd297c75e574729b1f78fdb76463";

$md5CheckSumMap{"hg18_alg-bwtsw.1.zip"} = "40e95b2ba9b2e4d1d865ede0afb979ed";
$md5CheckSumMap{"hg18_alg-bwtsw.2.zip"} = "3e08c24024c2c52ab1618141e6ecff1c";

$md5CheckSumMap{"mm9_alg-bwtsw.1.zip"} = "9e5a347580d6b94ce64ad23773ed99e0";
$md5CheckSumMap{"mm9_alg-bwtsw.2.zip"} = "470755b26acb5981753c15c06ed52819";

$md5CheckSumMap{"mm8_alg-bwtsw.1.zip"} = "d18b59a6eba7da3c868929f9bd0c91fc";
$md5CheckSumMap{"mm8_alg-bwtsw.2.zip"} = "ae1ba482b89cab6f0d3b2dc677dc0544";

$md5CheckSumMap{"m_musculus_MGSCv37_alg-bwtsw.1.zip"} = "6e2b02b93cfaadca05ae26c4fa960bad";
$md5CheckSumMap{"m_musculus_MGSCv37_alg-bwtsw.2.zip"} = "c94b3e2f1e1380ada24ad7f421a15f58";

$md5CheckSumMap{"a_thaliana_TAIR8_alg-is.zip"} = "a3a153941287a25f27feb88255918ff6";

$md5CheckSumMap{"c_elegans_WS200_alg-is.zip"} = "e4a43ef847a39001c0b4297e59f41872";

$md5CheckSumMap{"ecoli_NC_008253_ncbi536_alg-is.zip"} = "eb7c3486be4bd1e0de815edad4b712f5";

$md5CheckSumMap{"s_cerevisiae_alg-is.zip"} = "11a62b74f10dd193d2dee7300d34d1f5";


sub get_index_file_name
{
    $genome_id = shift;
    %genomeFileMap = ();

    $genomeFileMap {"hg19_alg-bwtsw"} = "hg19_alg-bwtsw.1.zip,hg19_alg-bwtsw.2.zip";
    $genomeFileMap {"hg18_alg-bwtsw"} = "hg18_alg-bwtsw.1.zip,hg18_alg-bwtsw.2.zip";
    $genomeFileMap {"mm9_alg-bwtsw"} = "mm9_alg-bwtsw.1.zip,mm9_alg-bwtsw.2.zip";
    $genomeFileMap {"mm8_alg-bwtsw"} = "mm9_alg-bwtsw.1.zip,mm9_alg-bwtsw.2.zip";
    $genomeFileMap {"a_thaliana_TAIR8_alg-is"} = "a_thaliana_TAIR8_alg-is.zip";
    $genomeFileMap {"b_taurus_3.0_alg-bwtsw"} = "b_taurus_3.0_alg-bwtsw.1.zip,b_taurus_3.0_alg-bwtsw.2.zip";
    $genomeFileMap {"c_elegans_WS200_alg-is"} = "c_elegans_WS200_alg-is.zip";
    $genomeFileMap {"ecoli_NC_008253_ncbi536_alg-is"} = "ecoli_NC_008253_ncbi536_alg-is.zip";
    $genomeFileMap {"m_musculus_MGSCv37_alg-bwtsw"} = "m_musculus_MGSCv37_alg-bwtsw.1.zip,m_musculus_MGSCv37_alg-bwtsw.2.zip";
    $genomeFileMap {"s_cerevisiae_alg-is"} = "s_cerevisiae.ebwt.zip";

    return $genomeFileMap{$genome_id};
}


sub download_bwa_index
{
    $genome_id = shift;
    $dir_path = shift;

    $index_file = $genome_id.".zip";
    $indexes = get_index_file_name($genome_id);

    @index_files = split(',', $indexes);

    #check the list of bwa index is not 0
    $index_length = @index_files;
    if($index_length == 0)
    {
        print STDERR "\nNo index files were found for $genome_id";
        exit(1);
    }

    $filelock_path = $dir_path;

    print "\nChecking for bwa index lock file: $filelock_path$filelock\n";
    if(is_downloading() eq "false")
    {
         if (!(-e ${dir_path}) || bwaIndexExist($dir_path) ne "true")
         {
            #create file lock
            mkpath($filelock_path);

            open(LOCK,'>',$filelock_path.$filelock) or die "Could not create file $filelock_path$filelock: $!";
            close(LOCK);
            $created_lock = "true";

            foreach $bwa_file (@index_files)
            {
                if (!(-e ${dir_path}.${bwa_file}))
                {
                    download($ftp_host, $index_path, $bwa_file, $dir_path);
                    push(@last_bwa_index, ${dir_path}.${bwa_file});
                    unzip_func(${dir_path}.${bwa_file}, $dir_path);
                    rmtree(${dir_path}.${bwa_file});
                }
            }

            sleep(5);
            rmtree($filelock_path.$filelock);
        }
    }
    else
    {
        while(is_downloading() eq "true")
        {
            sleep(5);
        }
    }


    return(@result_files);
}

sub bwaIndexExist
{
    $dir = shift;
    opendir(DIR, ${bwa_index});
    $count = 0;
    while (my $file = readdir(DIR))
    {
        if(rindex($file, ".amb") != -1
            ||rindex($file, ".ann") != -1
            ||rindex($file, ".bwt") != -1
            ||rindex($file, ".pac") != -1
            ||rindex($file, ".rbwt") != -1
            ||rindex($file, ".rpac") != -1
            ||rindex($file, ".rsa") != -1
            ||rindex($file, ".sa") != -1)

        {
            $count = $count +1;
        }       

        if($count == 8)
        {
            return "true";
        }
    }

    return "false";
}

sub download
{
    $host = shift;
    $path = shift;
    $file = shift;
    $dest = shift;

    $ftp_url = $ftp_host."/".$index_path."/".$file;

    print "\nDownloading file at: $ftp_url\n";

    print $host;
    $ftp = Net::FTP->new($host, Timeout => 60);

    print $ftp;
    $ftp->login('anonymous')
       or die "Can't login to ($host):" . $ftp->message;


    $ftp->cwd($path) or
        die "Can't change directory ($host):" .
            $ftp->message;

    @ls = $ftp->ls('-lR');

    #download file and fail if any file could not be downloaded
    $ftp->binary();
    $ftp->get($file, $dest.$file) or
                die "Could not download file at: '$ftp_url'";
    $ftp<-quit;

    if($md5CheckSumMap{$file} ne "")
    {
        $result = doMd5Checksum($dest.$file, $md5CheckSumMap{$file});
    }
    else
    {
        print "\nNo md5 checksum found for file: $file";
    }

    if($result eq "false")
    {
        if(-e $dest.$file)
        {
            rmtree($dest.$file);
        }

        die "\nFile checksum verification failed for file $file downloaded from $ftp_url";
    }
}

sub doMd5Checksum
{
    $file = shift;
    $checksum= shift;

    open(FILE, $file) or die "\nCan't open '$file'";
    binmode(FILE);
    $md5 = Digest::MD5->new->addfile(*FILE)->hexdigest;

    if($md5 ne $checksum)
    {
        return "false";
    }

    return "true";
}

sub is_downloading
{
     if(-e $filelock_path.$filelock)
     {
        return "true";
     }
     else
     {
        return "false";
     }
}

END
{
    foreach $index (@last_bwa_index)
    {
        if(is_downloading() ne "true")
        {
            if(-e $index)
            {
                rmtree($index);
            }
        }
    }

    if($created_lock eq "true")
    {
        if(-e $filelock_path.$filelock)
        {
            rmtree($filelock_path.$filelock);
        }
    }
}