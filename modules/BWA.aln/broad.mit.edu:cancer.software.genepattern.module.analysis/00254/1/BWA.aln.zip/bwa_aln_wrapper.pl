#!/usr/bin/perl

use Config;
use File::Basename;
use File::Path;
use IPC::Open3;
use IO::Select;
use IO::Handle;
use Getopt::Long;

$result = GetOptions ("libdir:s" => \$libdir,
                      "y:s" => \$bwa_index_cache,
                      "w1:s" => \$prebuilt_index,
                      "w2:s" => \$custom_index,
                      "p1:s" => \$pair1,
                      "p2:s" => \$pair2,
                      "n1:s" =>  \$maxEditDist,
					  "g:s" =>  \$maxNumGap,
					  "e:s" =>  \$maxNumGapExt,
                      "d:s" =>  \$maxDelLen,
                      "i:s" =>  \$maxInDelLen,
                      "l:s" =>  \$seedLen,
                      "k:s" =>  \$maxSeedEditDist,
                      "t:s" =>  \$numThreads,
                      "m:s" =>  \$mismatchPen,
                      "o1:s" =>  \$gapOpenPen,
                      "r:s" =>  \$maxBestHits,
                      "c:s" =>  \$reverseQuery,
                      "n2:s" =>  \$iterSearch,
                      "q:s" =>  \$trimRead,
                      "i:s" =>  \$illumina1_3,
                      "b:s" =>  \$barcodeLen,
                      "u:s" =>  \$maxOccur,
                      "a:s" =>  \$maxInsertSize,
                      "x1:s" =>  \$maxAlignments,
                      "x2:s" =>  \$maxDCAlignments,
                      "bm:s"  =>  \$bamMapping,
					  "o2:s" =>  \$outputPrefix
					  );
require ${libdir}."utility.pl";
require ${libdir}."download_bwa_index.pl";

$zip_command = "zip";
$unzip_command = "unzip";

$custom_bwa_index_path = "bwa_index/";

$bwa_linux64_zip=${libdir}."bwa-0.5.9.Linux_x86_64.zip";
$bwa_linux64_dir=${libdir}."bwa-0.5.9.Linux_x86_64/";
$bwa_mac64_zip=${libdir}."bwa-0.5.9.OSX_x86_64.zip";
$bwa_mac64_dir=${libdir}."bwa-0.5.9.OSX_x86_64/";
$bwa_mac32_zip=${libdir}."bwa-0.5.9.OSX_i386.zip";
$bwa_mac32_dir=${libdir}."bwa-0.5.9.OSX_i386/";

setupExecutables('mac64');

$bwa_exec=$bwa_dir."bwa";
if(checkCompatibility($bwa_exec) eq "false")
{
    rmtree($bwa_mac64_dir);

    setupExecutables('mac32');

    #check compatibility with 32-bit version
    if(checkCompatibility($bwa_exec) eq "false")
    {
        print STDERR "\nBWA.aligner is not currently supported on this platform.";
        print STDERR "\nosname: $Config{osname}";
        print STDERR "\narchname: $Config{archname}\n";
        exit(1);
    }
}

if($pair1 eq "")
{
    print STDERR "\nA read file must be specified";
    exit(1);

}
if($outputPrefix eq "")
{
    print STDERR "\nAn output prefix must be specified";
    exit(1);

}

if(rindex($pair1, '.bam') != -1 && $bamMapping eq "")
{
    print STDERR "\nA bam mapping must be specified for a bam input file";
    exit(1);
}

if(rindex($pair1, '.bam') == -1 && $bamMapping ne "")
{
    print STDERR "\nA bam mapping should only be specified for a bam input file";
    exit(1);
}

if($bwa_index_cache ne "")
{
    if($ENV{'bwa.index.dir'} ne "")
    {
        $bwa_index_cache = $ENV{'bwa.index.dir'};
    }
}

if($prebuilt_index ne "none")
{
    $bwa_index = $bwa_index_cache.$prebuilt_index."/";
    download_bwa_index($prebuilt_index, $bwa_index);
    $bwa_index .= $prebuilt_index;
}
elsif($custom_index ne "")
{
    if(rindex($custom_index, ".zip") != -1)
    {
        unzip_func($custom_index, $custom_bwa_index_path, "-j");
    }

    opendir(DIR, ${custom_bwa_index_path});

    while (my $file = readdir(DIR))
    {
        $file_prefix = substr basename($file), 0, index(basename($file), '.');
        if($file !~ m/^\./)
        {
            $bwa_index_name = $file_prefix;
        }
    }
      
    closedir(DIR);
    #check if index name was found
    if(!defined($bwa_index_name))
    {
        print STDERR "Unable to detect the name of the BWA index.";
        exit(1);
    }

    $bwa_index = $custom_bwa_index_path.$bwa_index_name;
}
else
{
    print STDERR "\nEither a prebuilt BWA index or custom BWA index must be specified"; 
    exit(1);
}

if($maxEditDist ne "")
{
    $aln_cmd .= " -n $maxEditDist";
}
if($maxNumGap ne "")
{
    $aln_cmd .= " -o $maxNumGap";
}
if($maxNumGapExt ne "")
{
    $aln_cmd .= " -e $maxNumGapExt";
}
if($maxDelLen ne "")
{
    $aln_cmd .= " -d $maxDelLen";
}
if($maxInDelLen ne "")
{
    $aln_cmd .= " -i $maxInDelLen";
}
if($seedLen ne "")
{
    $aln_cmd .= " -l $seedLen";
}
if($maxSeedEditDist ne "")
{
    $aln_cmd .= " -k $maxSeedEditDist";
}
if($numThreads ne "")
{
    $aln_cmd .= " -t $numThreads";
}
if($mismatchPen ne "")
{
    #mismatch penalty
    $aln_cmd .= " -M $mismatchPen";
}
if($gapOpenPen ne "")
{
    #gap open penalty
    $aln_cmd .= " -O $gapOpenPen";
}
if($gapExtenPen ne "")
{
    #gap extension penalty
    $aln_cmd .= " -E $gapExtenPen";
}
if($maxBestHits ne "")
{
    #max equally best hits
    $aln_cmd .= " -R $maxBestHits";
}
if($reverseQuery eq "yes")
{
    #reverse query but not complement it (required for colorspace alignment)
    $aln_cmd .= " -c";
}
if($iterSearch eq "yes")
{
    #disable iterative search
    $aln_cmd .= " -N";
}
if($trimRead ne "")
{
    #param for reaad trimming
    $aln_cmd .= " -q $trimRead";
}
if($illumina1_3 eq "yes")
{
    #format is Illumina 1.3+
    $aln_cmd .= " -I";
}
if($barcodeLen ne "")
{
    #gap extension penalty
    $aln_cmd .= " -B $barcodeLen";
}

if($bamMapping eq "single")
{
    #only use single-end reads in mapping if input file is in bam format
    $bam1 = "-b0";
}
elsif($bamMapping eq "first")
{
    #only use first read in a read pair in mapping if input file is in bam format
    $bam1 = "-b1";
}
elsif($bamMapping eq "second")
{
    #only use second read in a read pair in mapping if input file is in bam format
    $bam1 = "-b2";
}
elsif($bamMapping eq "paired")
{
    #use both first and second read pair in mapping if input file is in bam format
    $bam1 = "-b1";
    $bam2 = "-b2";
    $pair2 = $pair1;
}

#samse/sampe cmd
if($maxOccur ne "")
{
    #Maximum occurrences of a read for pairing
    $sam_cmd .= " -o $maxOccur";
}
if($maxInsertSize ne "")
{
    #Maximum insert size for a read pair to be considered being mapped properly
    $sam_cmd .= " -a $maxInsertSize";
}

if($maxAlignments ne "")
{
    #max number of alignments to report in the XA tag for reads paired properly
    $sam_cmd .= " -n $maxAlignments";
}
if($maxAlignments ne "")
{
    #max number of alignments to report in the XA tag for disconcordant read pairs (excluding singletons)
    $sam_cmd .= " -N $maxDCAlignments";
}

$aln_cmd = "$bwa_exec aln";

if($pair2 ne "")
{
    $read1_result = ${outputPrefix}."1.sai";
    $pair1_aln_cmd =$aln_cmd." $bam1 $bwa_index $pair1 > $read1_result";
    print "\npair 1 aln command: ".$pair1_aln_cmd."\n";
    runCmd($pair1_aln_cmd);

    $read2_result = ${outputPrefix}."2.sai";
    $pair2_aln_cmd = $aln_cmd." $bam2 $bwa_index $pair2 > $read2_result";
    print "\npair 2 aln command: ".$pair2_aln_cmd."\n";
    runCmd($pair2_aln_cmd);

    #samse/sampe cmd
    $sam_cmd = "$bwa_exec sampe ".$sam_cmd;
    $sam_cmd .= " $bwa_index $read1_result $read2_result $pair1 $pair2";
}
else
{
    $read_result = ${outputPrefix}."1.sai";
    $pair1_aln_cmd = $aln_cmd." $bam1 $bwa_index $pair1 > $read_result";
    print "\npair 1 aln command: ".$pair1_aln_cmd."\n";
    runCmd($pair1_aln_cmd);

    #samse/sampe cmd
    $sam_cmd = "$bwa_exec samse ".$sam_cmd;
    $sam_cmd .= " $bwa_index $read_result $pair1";
}

$outputFile = $outputPrefix.".sam";
$sam_cmd .= " > ".$outputFile;

print "\nCommand: $sam_cmd\n";

runCmd($sam_cmd);
verifySamOutput($outputFile);


sub verifySamOutput()
{
    $samFile = shift;

    $SAMFILE = $samFile;
    open(SAMFILE) or die("Could not open sam file: $samFile");
    foreach $line (<SAMFILE>)
    {
        if($line !~ "^@")
        {
            close(SAMFILE);
            exit(1);
        }
    }

    close(SAMFILE);

    print STDERR "An incomplement SAM file was created. Please check that a valid input file was provided.";
}

sub runCmd()
{
    $cmd = shift;
    $Pin  = new IO::Handle;       $Pin->fdopen(10, "w");
    $Pout = new IO::Handle;       $Pout->fdopen(11, "r");
    $Perr = new IO::Handle;       $Perr->fdopen(12, "r");
    $Proc = open3($Pin, $Pout, $Perr, $cmd);

    my $sel = IO::Select->new();
    $sel->add($Perr, $Pout);

    while (my @ready = $sel->can_read)
    {
        foreach my $handle (@ready)
        {
            if (fileno($handle) == fileno($Perr))
            {
                # process has printed something on standard error
                my ($count, $data);
                $count = sysread($handle, $data, 1024);
                if ($count == 0)
                {
                    $sel->remove($handle);
                    next;
                }
                if ($data =~ m/Abort/i || $data =~ m/Not enough memory allocated!/i)  #if stderr output looks like an error message, write to stderr
    	        {
    		        print STDERR $data;
                }
                else
                {
            		print STDOUT $data;
                }
            }
            else
            {
                # process has printed something on standard out
                my ($count, $data);
                $count = sysread($handle, $data, 1024);
                if ($count == 0)
                {
                    $sel->remove($handle);
                    next;
                }
                print STDOUT $data;
            }
        }
    }
}

sub cleanup()
{
    #delete custom BWA index files and .sai files in the current directory
    rmtree($custom_bwa_index_path);
    unlink("${outputPrefix}1.sai");
    unlink("${outputPrefix}2.sai");
}

END
{
    cleanup();
}
