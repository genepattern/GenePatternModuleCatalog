sparsecluster <- function(libdir, file,  method=c("average", "complete", "single", "centroid"), wbound=NULL, cluster.features=FALSE, method.features=c("average", "complete", "single", "centroid"), maxnumgenes=NULL, standardize.arrays=TRUE) {   
	suppressMessages(.sparsecluster(libdir,file, method, wbound, cluster.features,method.features,maxnumgenes,standardize.arrays));
}


install.required.packages <- function(libdir) {
  if(!is.package.installed(libdir, "sparcl")) {
                install.package(libdir, "sparcl_1.0.1.zip","sparcl_1.0.1.tgz","sparcl_1.0.1.tar.gz")
   }
}


is.package.installed <- function(libdir, pkg) {
f <- paste(libdir, pkg, sep='')
return(file.exists(f) && file.info(f)[["isdir"]])
}


install.package <- function(dir, windows, mac, other) {
print ("installing R packages")
isWindows <- Sys.info()[["sysname"]]=="Windows"
isMac <- Sys.info()[["sysname"]]=="Darwin"
if(isWindows) {
f <- paste(dir, windows, sep="")
.install.windows(f)
} else if(isMac) {
f <- paste(dir, mac, sep="")
      .install.unix(f)
} else { # install from source
f <- paste(dir, other, sep="")
.install.unix(f)
}
}

.install.windows <- function(pkg) {
suppressMessages(install.packages(pkg, .libPaths()[1], repos=NULL))
}

.install.unix <- function(pkg) {
    lib <- .libPaths()[1]
   cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL")
    cmd <- paste(cmd, "-l", lib)
    cmd <- paste(cmd, " '", pkg, "'", sep = "")
    status <- suppressMessages(system(cmd))
    if (status != 0)
     cat("\tpackage installation failed\n")
}

## from the main Hierarchical Sparse clustering file, with a 2 to make different 
extract.prefix2 <- function(file){
  i=0
  while(substring(file,i,i)!="." & (i <nchar(file))) {i=i+1}
  if(i==nchar(file)){stop('Error in file name')}
  pre=substring(file,1,i-1)
  return(pre)
}

.sparsecluster <- function(libdir, file,  method=c("average", "complete", "single", "centroid"), wbound=NULL, cluster.features=FALSE, method.features=c("average", "complete", "single", "centroid"), maxnumgenes=NULL, standardize.arrays=TRUE) {   
	wbound <- as.numeric(wbound)
	#niter <- as.numeric(niter)
	niter <- 15
	# dissimilarity ("squared.distance", "absolute.value")
	maxnumgenes <- as.numeric(maxnumgenes)
	if (maxnumgenes==-1) {
		maxnumgenes <- NULL;
	}
	output.cluster.files <- TRUE
	silent <- FALSE
	if (cluster.features == "true") {
		cluster.features <- TRUE
	}
	else {
		cluster.features <- FALSE
	}
	if (standardize.arrays == "false") {
		standardize.arrays <- FALSE
	}
	else {
		standardize.arrays <- TRUE
	}
	if (wbound==-1) {
		wbound <- NULL
	}
	#source(paste(libdir,"common.R", sep=''))
	#setLibPath(libdir)
        libPath <- libdir
        if(!file.exists(libdir)) {
                # remove trailing /
                libPath <- substr(libdir, 0, nchar(libdir)-1)
        }
        .libPaths(libPath)

	install.required.packages(libdir)
  	library(sparcl)

	#print ("WBOUND")
	#print (wbound)
	#print ("MAXNUMGENES")
	#print (maxnumgenes)
	

	outputfile.prefix <- extract.prefix2(basename(file))

	HierarchicalSparseCluster.wrapper(file, method, wbound, silent, cluster.features,method.features,output.cluster.files,outputfile.prefix,maxnumgenes,standardize.arrays);

    out.file <- paste(outputfile.prefix, "out", sep=".")
    perm.file <- paste(outputfile.prefix, "wbound","txt", sep=".")
    success <- file.rename(out.file, perm.file)
    if(success == FALSE)
    {
        cat("\nCould not rename file", out.file, "to", perm.file)
    }

    txt.file <- paste(outputfile.prefix, "txt", sep=".")
    weight.file <- paste(outputfile.prefix, "weights","txt", sep=".")
    success <- file.rename(txt.file, weight.file)
    if(success == FALSE)
    {
        cat("\nCould not rename file", txt.file, "to", weight.file)
    }
}



