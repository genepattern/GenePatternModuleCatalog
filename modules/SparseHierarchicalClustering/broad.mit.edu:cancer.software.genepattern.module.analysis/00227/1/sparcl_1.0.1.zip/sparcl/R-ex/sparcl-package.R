### Name: sparcl-package
### Title: Performs sparse hierarchical and sparse K-means clustering
### Aliases: sparcl-package sparcl


### ** Examples




