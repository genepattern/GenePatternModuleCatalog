# Metagene Projection
# The Broad Institute
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2003-2007) by the
# Broad Institute/Massachusetts Institute of Technology. All rights are
# reserved.
# This software is supplied without any warranty or guaranteed support
# whatsoever. Neither the Broad Institute nor MIT can be responsible for its
# use, misuse, or functionality.


metagene.projection.cmdline <-
# processes the cmd line for the MetageneProjection
function(...)
{
    model.gct.filename     <- ''
    model.cls.filename     <- ''
    model.preprocess.file   <- ''
    test.gct.filename      <- ''
    test.cls.filename      <- ''
    test.preprocess.file    <- ''
    identifier              <- ''
    k.proj                  <- ''
    alg                     <- ''
    niter                   <- ''
    seed                    <- ''
    nchar.phen              <- ''
    postprojnorm            <- ''
    heatmap.row.norm        <- ''
    heatmap.cmap.type       <- ''
    high.conf.thres         <- ''
    colors                  <- ''
    symbols                 <- ''
    symbol.scaling          <- ''
    kernel                  <- ''
    cost                    <- ''
    gamma                   <- ''
    theta                   <- ''
    lambda                  <- ''
    model.set.refinement    <- ''
    symbs.mapping           <- list(circle=21, square=22, diamond=23, triangle=24, reverse_triangle=25)
    output.dir              <- paste(getwd(), "/", sep="")


    temp.dir <- getwd()
    temp.dir <- paste(getwd(), "/temp", sep="")
    dir.create(temp.dir)
	on.exit(unlink(temp.dir, recursive=TRUE))
	
    args <- list(...)
    for(i in 1:length(args))
    {
        flag <- substring(args[[i]], 0, 2)
		value <- substring(args[[i]], 3, nchar(args[[i]]))

		if(value=='')
		{
			next
		}
		else if(flag == '-l')
		{
		    libdir <- value
		}
		else if(flag == '-m')
		{
		    model.gct.filename <- value
		}
		else if(flag == '-d')
		{
		    model.cls.filename <- value
		}
		else if(flag == '-p')
		{
		    model.preprocess.file <- value
		}
		else if(flag == '-z')
		{
		    test.gct.filename <- value
            ext <- regexpr(paste("zip", "$", sep=""), tolower(test.gct.filename))
		    if(ext[[1]] != -1)
		    {
                unzip.file(test.gct.filename, temp.dir)
                test.dir <- temp.dir
		    }
		    else
		        test.dir <- ''
		}
		else if(flag == '-x')
		{
		    test.cls.filename <- value
            ext <- regexpr(paste("zip", "$", sep=""), tolower(test.cls.filename))
		    if(ext[[1]] != -1)
		    {
                unzip.file(test.cls.filename, temp.dir)
		    }
		}
		else if(flag == '-t')
		{
		    test.preprocess.file <- value
		}
		else if(flag == '-i')
		{
		    identifier <- value
		}
		else if(flag == '-k')
		{
		    k.proj <- as.numeric(value)
		}
		else if(flag == '-o')
		{
		    alg <- value
		}
		else if(flag == '-n')
		{
		    niter <- as.numeric(value)
		}
		else if(flag == '-s')
		{
		    seed <- as.numeric(value)
		}
		else if(flag == '-u')
		{
		    nchar.phen <- as.numeric(value)
		}
		else if(flag == '-j')
		{		  
		    postprojnorm <- as.logical(value)
		}
		else if(flag == '-w')
		{
		    heatmap.row.norm <- as.logical(value)
		}		
		else if(flag == '-h')
		{
		    heatmap.cmap.type <- as.numeric(value)
		}
		else if(flag == '-f')
		{
		    high.conf.thres <- as.numeric(value)
		}
		else if(flag == '-v')
		{
		    phenotype.colors.table <- read.table(value, as.is=TRUE)
		    colors <- phenotype.colors.table[,1]
		}
		else if(flag == '-q')
		{
		    symbols <- get.phenotype.symbols(value, symbs.mapping)
		}
		else if(flag == '-y')
		{
		    symbol.scaling <- as.numeric(value)
		}
		else if(flag == '-e')
		{
		    kernel <- value
		}
		else if(flag == '-c')
		{
		    cost <- as.numeric(value)
		}
		else if(flag == '-g')
		{
		    gamma <- as.numeric(value)
		}
		else if(flag == '-a')
		{
		    theta <- as.numeric(value)
		}
		else if(flag == '-b')
		{
		    lambda <- as.numeric(value)
		}
		else if(flag == '-r')
		{
		    model.set.refinement <- as.logical(value)
		}
		else
		    stop("Unknown option", flag)
    }

    if(test.gct.filename != '' && test.cls.filename == '')
        stop(paste("Missing test.cls.file"))

    if(test.gct.filename == '' && test.cls.filename != '')
        stop(paste("Missing test.gct.file"))

    input.tables <- create.input.tables(model.preprocess.file, test.preprocess.file, test.dir, model.gct.filename, model.cls.filename, test.gct.filename, test.cls.filename)

    setup(libdir)

    source(paste(libdir,"/MP.Library.R", sep=""))

    if (length(colors) == 1 && colors == '') colors <- eval(formals(Metagene.Projection)$col)

    if (length(symbols) == 1 && symbols == '') symbols <- eval(formals(Metagene.Projection)$symbs)

    suppressWarnings(
                        Metagene.Projection(model.dataset.table = input.tables$model, test.datasets.table = input.tables$test,
                        identifier = identifier, k.proj = k.proj, alg = alg, niter = niter, seed = seed,
                        nchar.phen = nchar.phen,  postprojnorm =  postprojnorm, heatmap.row.norm = heatmap.row.norm,
                        heatmap.cmap.type = heatmap.cmap.type, high.conf.thres = high.conf.thres, output.dir = output.dir,
                        col = colors, symbs = symbols, symbol.scaling = symbol.scaling, kernel = kernel, cost = cost,
                        gamma = gamma, theta = theta, lambda = lambda, model.set.refinement = model.set.refinement)
                   )
}

unzip.file <- function(input.filename, temp.dir)
{    
	isWindows <- Sys.info()[["sysname"]]=="Windows"

	if(isWindows)
	{
		zip.unpack(input.filename, dest = temp.dir)
	}
	else
	{
        zip <- getOption("unzip")
		system(paste(zip, "-q", input.filename, "-d", temp.dir))
	}
}

create.input.tables <-
function(model.preprocess.file, test.preprocess.file, temp.dir, model.gct.filename, model.cls.filename, test.gct.filename, test.cls.filename)
{
    # Create model table
    model.table <- read.table(model.preprocess.file, sep="=", strip.white = TRUE, quote = "", as.is=TRUE)
    
    model.table <- as.matrix(model.table)
    model.table.dataset <- NULL

    for(r in 1:length(model.table[,1]))
    {
        name <- model.table[r,1]
        value <- model.table[r,2]

        if((name == "column.subset" || name == "row.subset") && value != "\"ALL\"")
        {
            value <- eval(parse(text = value))
        }
        else if(regexpr("\"", value) == -1 || regexpr("\"$", value) == -1)
            value <- as.numeric(value)
        else
            value <- gsub("\"", "", value)

        if((name == "ceil" || name == "norm") && value != "NULL")
            value <- as.integer(value)
        
        if(name == "gct.file") {
            if(!file.exists(value)) {
				value = model.gct.filename  #take full path name from input parameter instead of filename from parameters file

				if(!file.exists(value)) {
					stop(paste("Could not find file:", basename(value)))
				}
			}
		}
		
		if(name == "cls.file") {
            if(!file.exists(value)) {
				value = model.cls.filename  #take full path name from input parameter instead of filename from parameters file
			
				if(!file.exists(value)) {
					stop(paste("Could not find file: ", basename(value)))
				}
			}
		}

        model.table.dataset <- c(model.table.dataset, list(value))
        len <- length(model.table.dataset)
        names(model.table.dataset)[len] <- name
    }

    test.table.dataset <- NULL
    # Create test table
    if(!is.null(test.preprocess.file) && test.preprocess.file != '')
    {
        test.table <- read.table(test.preprocess.file, sep="=", strip.white = TRUE, quote = "", as.is = TRUE)
        test.table <- as.matrix(test.table)
    
        test.table.dataset <- list()
        test.preprocess.list <- NULL
        list.count <- 1
        for(r in 1:length(test.table[,1]))
        {
            name <- test.table[r,1]
            value <- test.table[r,2]

            if((name == "column.subset" || name == "row.subset") && value != "\"ALL\"")
            {
                value <- eval(parse(text = value))
            }
            else if(regexpr("\"", value) == -1 || regexpr("\"$", value) == -1)
            {
                value <- as.numeric(value)
            }
            else
                value <- gsub("\"", "", value)
         
            if((name == "ceil" || name == "norm") && value != "NULL")
                value <- as.numeric(value)
        

            if(name == "gct.file")
            {
                if(temp.dir != '')
                    value <- paste(temp.dir, value, sep="/")
				else {
					value = test.gct.filename
				}
                if(!file.exists(value))
                    stop(paste("Could not find file: ", basename(value)))				
            }
			if(name == "cls.file") {
				if(temp.dir != '')
                   value <- paste(temp.dir, value, sep="/")
				else {
					value = test.cls.filename
				}
				if(!file.exists(value))
                   stop(paste("Could not find file: ", basename(value)))				
			}				

            if(r != 1 && name == "gct.file")
            {
                test.preprocess.list <- NULL
                list.count <- list.count + 1
            }

            test.preprocess.list <- c(test.preprocess.list, list(value))
            len <- length(test.preprocess.list)
            names(test.preprocess.list)[len] <- name

            test.table.dataset[list.count] <- list(test.preprocess.list)
        }
    }
    
    return (list(model=model.table.dataset, test = test.table.dataset))
}

get.phenotype.symbols <-
function(phenotype.file, symbol.mapping.table)
{
    phenotype.table <- read.table(phenotype.file, as.is = TRUE)

    symbs.data <- phenotype.table[,1]

    symbs.list <- NULL
    for(i in 1:length(symbs.data))
    {
        symb <- symbs.data[[i]]
        symbs.list <- c(symbs.list , symbol.mapping.table[[symb]])
    }
}

setup <-
function(libdir)
{
	source(paste(libdir, "common.R", sep=''))
	setLibPath(libdir)
	install.required.packages(libdir)
	library(RLIBSVM)
}

install.required.packages <- function(libdir)
{
    info(libdir)
    if(!is.package.installed(libdir, "tree"))
    {
        install.package(libdir, "tree_1.0-26.zip", "tree_1.0-26.tgz", "tree_1.0-26.tar.gz")
    }

    if(!is.package.installed(libdir, "scatterplot3d"))
    {
        install.package(libdir, "scatterplot3d_0.3-21.zip", "scatterplot3d_0.3-21.tgz", "scatterplot3d_0.3-21.tar.gz")
    }
    
    if(!is.package.installed(libdir, "RLIBSVM"))
    {
        install.package(libdir, "RLIBSVM_1.0-0.zip", "RLIBSVM_1.0-0.tgz", "RLIBSVM_1.0-0.tar.gz")
    }
}

