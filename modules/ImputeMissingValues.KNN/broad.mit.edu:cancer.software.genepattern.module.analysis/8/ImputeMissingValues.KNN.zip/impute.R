
impute <- function(data.file.name, k, rowmax, colmax, output.file.name, ...) {
   username <- 'GenePattern'
   libdir <- ""
	other.args <- list(...)
	if(length(other.args)==1) {
		libdir <- other.args[[1]]
	}
	options("warn"=-1)
   
	if(!require("impute", quietly=TRUE)) {
		install.package(libdir, "impute", "1.0.2")
	}
	library(impute, verbose=FALSE)
	library(GenePattern, verbose=FALSE)
   
   result <- regexpr(paste(".gct","$",sep=""), tolower(data.file.name))
	if(result[[1]] != -1) {
      d <- read.gct(data.file.name)
   } else {
      stop("input data is not a gct file")  
   }
   data <- d@data
   
   library(impute)
   
   r <- impute.knn(as.matrix(data),k = as.integer(k), rowmax = as.numeric(rowmax), colmax = as.numeric(colmax))
   r <- r$data
   d@data <- as.data.frame(r)
   if(class(d)=='res') {
      result <- regexpr(paste(".res","$",sep=""), tolower(output.file.name))
      if(result[[1]] == -1) { 
         output.file.name <- paste(output.file.name, ".res", sep="") 
      }
      write.res(d, output.file.name)
   } else {
      result <- regexpr(paste(".gct","$",sep=""), tolower(output.file.name))
      if(result[[1]] == -1) { 
         output.file.name <- paste(output.file.name, ".gct", sep="") 
      }
      write.gct(d, output.file.name)
   }
   return(c(output.file.name))
}


read.dataset <- function(file) {
	
		return(read.gct(file))
	result <- regexpr(paste(".res","$",sep=""), tolower(file))
	if(result[[1]] != -1)
		return(read.res(file))
	
	stop("Input is not a res or gct file.")	
}

install.package <- function(dir, library, version) {
	isWindows <- Sys.info()[["sysname"]]=="Windows"
	isMac <- Sys.info()[["sysname"]]=="Darwin" 
	if(isWindows) {
		f <- paste(dir, library, "_", version, ".zip", sep="")
		.install.windows(f)
	} else if(isMac) {
		f <- paste(dir, library, "_", version, ".tgz", sep="") 
		if(!file.exists(f)) { # see if mac binary exists
			f <- paste(dir, library, "_", version, ".tar.gz", sep="")
		}
		.install.unix(f)
	} else { # install from source
		f <- paste(dir, library, "_", version, ".tar.gz", sep="")
		.install.unix(f)
	}	
}

.install.windows <- function(pkg) {
	install.packages(pkg, .libPaths()[1], CRAN=NULL, installWithVers=FALSE)
}

.install.unix <- function(pkg) {
    lib <- .libPaths()[1]
   # cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL --with-package-versions")
	 cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL")
    cmd <- paste(cmd, "-l", lib)
    cmd <- paste(cmd, " '", pkg, "'", sep = "")
    status <- system(cmd)
    if (status != 0) 
    	cat("\tpackage installation failed\n")
}
