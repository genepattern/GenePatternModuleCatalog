DEBUG <<- FALSE
log <- function(s) {
	if(DEBUG) {
		cat(paste(s, "\n", sep=''))
	}
}

impute <- function(data.file.name, k, rowmax, colmax, output.file.name, libdir) {
    ret <- try(
        .impute(data.file.name, k, rowmax, colmax, output.file.name, libdir)
    )
    if(class(ret)=="try-error") {
      traceback()
   }
}

.impute <- function(data.file.name, k, rowmax, colmax, output.file.name, libdir) {
   options("warn"=-1)
   username <- 'GenePattern'
	
   if(libdir!='') {
   	libPath <- libdir
   	if(!file.exists(libdir)) {
   		# remove trailing /
   		libPath <- substr(libdir, 0, nchar(libdir)-1)
   	}
		log(paste("adding ", libPath, " to libpath"))
		.libPaths(libPath)
		log(paste("libpath", .libPaths()))
		install.required.packages(libdir)
	}	
   library(impute, verbose=FALSE)
	library(GenePattern, verbose=FALSE)
	
   result <- regexpr(paste(".gct","$",sep=""), tolower(data.file.name))
	if(result[[1]] != -1) {
      d <- read.gct(data.file.name)
   } else {
      stop("input data is not a gct file")  
   }
   data <- d@data
   
   r <- impute.knn(as.matrix(data),k = as.integer(k), rowmax = as.numeric(rowmax), colmax = as.numeric(colmax))
   log(class(r))
    
   imputed.data <- r 
   if(class(r)=="list") { # windows
   	imputed.data <- r$data
   }
   d@data <- as.data.frame(imputed.data)
   log("converted to data frame")
   if(class(d)=='res') {
      result <- regexpr(paste(".res","$",sep=""), tolower(output.file.name))
      if(result[[1]] == -1) { 
         output.file.name <- paste(output.file.name, ".res", sep="") 
      }
      write.res(d, output.file.name)
   } else {
      result <- regexpr(paste(".gct","$",sep=""), tolower(output.file.name))
      if(result[[1]] == -1) { 
         output.file.name <- paste(output.file.name, ".gct", sep="") 
      }
      write.gct(d, output.file.name)
   }
   return(c(output.file.name))
}



read.dataset <- function(file) {
	return(read.gct(file))
	result <- regexpr(paste(".res","$",sep=""), tolower(file))
	if(result[[1]] != -1)
		return(read.res(file))
	
	stop("Input is not a res or gct file.")	
}

install.required.packages <- function(libdir) {
	if(!is.package.installed(libdir, "impute")) {
		install.package(libdir, "impute_1.0.2.zip", "impute_1.0-2.tgz", "impute_1.0-3.tar.gz")
	}
}

is.package.installed <- function(libdir, pkg) {
	f <- paste(libdir, pkg, sep='')
	log(paste("checking if", f, "exists"))
	return(file.exists(f) && file.info(f)[["isdir"]])
}

install.package <- function(dir, windows, mac, other) {
	isWindows <- Sys.info()[["sysname"]]=="Windows"
	isMac <- Sys.info()[["sysname"]]=="Darwin" 
	if(isWindows) {
		f <- paste(dir, windows, sep="")
		.install.windows(f)
	} else if(isMac) {
		f <- paste(dir, mac, sep="")
      .install.unix(f)
	} else { # install from source
		f <- paste(dir, other, sep="")
		.install.unix(f)
	}	
}

.install.windows <- function(pkg) {
	log(paste("installing", pkg, "to ", .libPaths()[1]))
	install.packages(pkg, .libPaths()[1], CRAN=NULL, installWithVers=FALSE)
}

.install.unix <- function(pkg) {
    lib <- .libPaths()[1]
   # cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL --with-package-versions")
	 cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL")
    cmd <- paste(cmd, "-l", lib)
    cmd <- paste(cmd, " '", pkg, "'", sep = "")
    status <- system(cmd)
    if (status != 0) 
    	cat("\tpackage installation failed\n")
}