DEBUG <<- FALSE
log <- function(s) {
	if(DEBUG) {
		cat(paste(s, "\n", sep=''))
	}
}

impute <- function(data.file.name, k, rowmax, colmax, output.file.name, libdir) {
    ret <- try(
        .impute(data.file.name, k, rowmax, colmax, output.file.name, libdir)
    )
    if(class(ret)=="try-error") {
      traceback()
   }
}

.impute <- function(data.file.name, k, rowmax, colmax, output.file.name, libdir) {
   options("warn"=-1)
   source(paste(libdir, "common.R", sep=''))
	setLibPath(libdir)
	install.required.packages(libdir)
   library(impute, verbose=FALSE)
   d <- read.dataset(data.file.name)
	data <- d$data 
   r <- impute.knn(as.matrix(data),k = as.integer(k), rowmax = as.numeric(rowmax), colmax = as.numeric(colmax))
   log(class(r))
    
   imputed.data <- r 
   if(class(r)=="list") { # windows
   	imputed.data <- r$data
   }
   d$data <- as.data.frame(imputed.data)
   log("converted to data frame")
 	output.file.name <- write.gct(d, output.file.name)
   return(c(output.file.name))
}

install.required.packages <- function(libdir) {
	if(!is.package.installed(libdir, "impute")) {
		install.package(libdir, "impute_1.0.2.zip", "impute_1.0-2.tgz", "impute_1.0-3.tar.gz")
	}
}




