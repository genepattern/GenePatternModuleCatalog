#!/usr/bin/perl

use Config;
use File::Basename;
use File::Path;
use IPC::Open3;
use IO::Select;
use IO::Handle;
use Getopt::Long;

$result = GetOptions ("libdir:s" => \$libdir,
                      "f:s" => \$inputFile,
					  "a:s" => \$alg,
					  "c:s" => \$colorspace,
					  "o:s" => \$output
					  );

require ${libdir}."utility.pl";


$bwa_linux64_zip=${libdir}."bwa-0.5.9.Linux_x86_64.zip";
$bwa_linux64_dir=${libdir}."bwa-0.5.9.Linux_x86_64/";
$bwa_mac64_zip=${libdir}."bwa-0.5.9.OSX_x86_64.zip";
$bwa_mac64_dir=${libdir}."bwa-0.5.9.OSX_x86_64/";
$bwa_mac32_zip=${libdir}."bwa-0.5.9.OSX_i386.zip";
$bwa_mac32_dir=${libdir}."bwa-0.5.9.OSX_i386/";

print "\nTrying to run 64-bit version";
setupExecutables('mac64');

$bwa_exec=$bwa_dir."bwa";

if(checkCompatibility($bwa_exec) eq "false")
{
    rmtree($bwa_mac64_dir);

    print "\nTrying to run 32-bit version";
    setupExecutables('mac32');

    #check compatibility with 32-bit version
    if(checkCompatibility() eq "false")
    {
        print STDERR "\nBWA.indexer is not currently supported on this platform.";
        print STDERR "\nosname: $Config{osname}";
        print STDERR "\narchname: $Config{archname}\n";
        exit(1);
    }
}

$cmd = "$bwa_exec index";

if($colorspace eq "yes")
{
    $cmd .= " -c ";
}

$cmd .= " -a $alg -p $output \"$inputFile\"";

print "\nCommand: $cmd\n";

$Pin  = new IO::Handle;       $Pin->fdopen(10, "w");
$Pout = new IO::Handle;       $Pout->fdopen(11, "r");
$Perr = new IO::Handle;       $Perr->fdopen(12, "r");
$Proc = open3($Pin, $Pout, $Perr, $cmd);

my $sel = IO::Select->new();
$sel->add($Perr, $Pout);

while (my @ready = $sel->can_read)
{
    foreach my $handle (@ready)
    {
        if (fileno($handle) == fileno($Perr))
        {
            # process has printed something on standard error
            my ($count, $data);
            $count = sysread($handle, $data, 1024);
            if ($count == 0)
            {
                $sel->remove($handle);
                next;
            }
            if ($data =~ m/Abort/i || $data =~ m/Not enough memory allocated!/i)  #if stderr output looks like an error message, write to stderr
	        {
		        print STDERR $data;		        
            }
            else
            {
        		print STDOUT $data;
            }
        }
        else
        {
            # process has printed something on standard out
            my ($count, $data);
            $count = sysread($handle, $data, 1024);
            if ($count == 0)
            {
                $sel->remove($handle);
                next;
            }
            print STDOUT $data;
        }
    }
}


#zip output files
zip_func("\"".$output."\"*", $output.".zip", "-m -q");
 
sub setupExecutables
{
    $mac_version = shift;

	if (($Config{osname} eq 'linux') && ($Config{archname} =~m/64/))
    {
        $bwa_dir=$bwa_linux64_dir;
        $bwa_zip=$bwa_linux64_zip;
    }
    elsif (($Config{osname} eq 'darwin'))
    {
        if($mac_version eq 'mac64')
        {
            $bwa_dir=$bwa_mac64_dir;
            $bwa_zip=$bwa_mac64_zip;
        }
        elsif($mac_version eq 'mac32')
        {
            $bwa_dir=$bwa_mac32_dir;
            $bwa_zip=$bwa_mac32_zip;
        }
        else
        {
            print STDERR "\nUnexpected value for mac_version $mac_version. Expecting either mac64 or mac32";
            exit(1);
        }
    }
    else
    {
        print STDERR "\nBWA.indexer is not currently supported on this platform.";
        print STDERR "\nosname: $Config{osname}";
        print STDERR "\narchname: $Config{archname}\n";
        exit(1);
    }

    #extract bwa binary from zip if not already done
    if (!(-d "${bwa_dir}"))
    {
        unzip_func($bwa_zip, $libdir, '-q');
        rmtree(${bwa_zip});
    }
}




