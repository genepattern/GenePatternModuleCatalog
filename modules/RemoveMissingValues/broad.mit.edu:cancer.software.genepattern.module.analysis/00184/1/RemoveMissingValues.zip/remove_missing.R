# The Broad Institute
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2003-2010) by the
# Broad Institute/Massachusetts Institute of Technology. All rights are
# reserved.

# This software is supplied without any warranty or guaranteed support
# whatsoever. Neither the Broad Institute nor MIT can be responsible for its
# use, misuse, or functionality.

setup <- function(libdir) {
	source(paste(libdir, "common.R", sep=''))
	setLibPath(libdir)
}

corrCmdLine <-function(...)
{
    suppressMessages(remove_missing(...)) #what to do with this?
}

remove_missing <-function(...)
{
	libdir <- ''
	dataset.file <- ''
	output.file <- ''
#	na.limit <- ''
	
	remove.opts <- c("rows","cols","both")

	args <- list(...)
	for(i in 1:length(args)) {
		flag <- substring(args[[i]], 0, 2)
		value <- substring(args[[i]], 3, nchar(args[[i]]))

		if(value=='') {
			next
		} else if(flag == '-l') {
			libdir <- value
		} else if(flag == '-i') {
			dataset.file <- value
		} else if (flag == '-m') {
			na.limit <- value
		} else if(flag == '-r') {
			remove.idx <- as.integer(value)
			if ((remove.idx < 1) || (remove.idx > length(remove.opts))) {
					stop(paste("Unrecognized option for -r: ", remove.idx))
				} else {
					remove <- remove.opts[remove.idx]
				}
		} else if(flag == '-o') {
			output.file <- value
		} else{
		    stop(paste("unknown flag: ", flag))
		}
	}

 	suppressMessages(setup(libdir))

	dataset <- read.dataset(dataset.file)
	
	data <- dataset$data
	row.desc <- dataset$row.descriptions
	
	final.rows <- c(1:length(data[,1]))
	final.cols <- c(1:length(data[1,]))
	
	if ((remove == "rows") || (remove == "both")) {
		for (i in 1:length(data[,1])) {
			if ( !all(!is.na(data[i,]))) {
				final.rows <- final.rows[-which(final.rows==i)]
			}
		}
	} 
	
	if ((remove == "cols") || (remove == "both"))	{
		for (i in 1:length(data[1,])) {
			if ( !all (!is.na(data[,i]))) {
			final.cols <- final.cols[-which(final.cols==i)]
			}
		}
	}

	if ((length(final.rows)==0) || (length(final.cols)==0)) {
      stop("The resulting dataset contains no values")	
	}
	
	result <- data[final.rows, final.cols]    
	row.names(result) <- row.names(data)[final.rows]
	colnames(result)<- colnames(data)[final.cols]
	result.desc <- row.desc[final.rows]
	
    gct <- list(data = result, row.descriptions = result.desc)
    write.gct(gct, output.file)
}
