use Getopt::Long;

sub trim($);

$result = GetOptions ("input=s" => \$inputFile,
					  "rownames=s" => \$rowName,
					  "rowdesc=s" => \$rowDesc,
					  "filterDashRowNames=s" => \$filterDashRowNames,
					  "output=s"  => \$outputPrefix);  

if (!($inputFile =~ /\.tmap$/i)) {
	print STDERR "Incorrect input file type. Expected .tmap file.\n";
	exit(1);
}

$outputFile = $outputPrefix;
if ($outputPrefix eq "") {
	$outputFile = "output.gct";
} elsif (!($outputFile =~ /\.gct$/i)) {
	$outputFile = $outputPrefix . ".gct";
}

open(IN, "<$inputFile") || die("Can't open file: $!");
@lines = <IN>;
close(IN);

#remove newlines, even if from different platforms
$joined = join('',@lines); #several lines may be present in each element of @lines
$joined =~ s/[\r\n]+/\n/g;
@lines = split(/\n/, $joined);

if ($#lines < 1)  {
	print STDERR "Error: The input file contains no data, or is not a valid .tmap file.\n";
	exit(1);
}

@colNames = split(/\t/, $lines[0]);
for $j (0..$#colNames) { trim($colNames[$j]); }

$rnIndex = -1; #col index of rownames that will be written to GCT
$rnIndex++ until ($colNames[$rnIndex] eq $rowName) or ($rnIndex > $#colNames);
if ($rnIndex > $#colNames) { 
	print STDERR "$rowName not found among TMAP file column names: @colNames.\nMissing headerline or invalid TMAP file.\n";
	exit(1);
}

$rdIndex = -1; #col index of row descriptions that will be written to GCT
$rdIndex++ until ($colNames[$rdIndex] eq $rowDesc) or ($rdIndex > $#colNames);
if ($rdIndex > $#colNames) { 
	print STDERR "$rowDesc not found among TMAP file column names: @colNames.\nMissing headerline or invalid TMAP file.\n";
	exit(1);
}

$dataName = "FPKM";
$dataIndex = -1;  #col index of data which will be written to GCT file
$dataIndex++ until ($colNames[$dataIndex] eq $dataName) or ($dataIndex > $#colNames);
if ($dataIndex > $#colNames) { 
	print STDERR "$dataName not found among TMAP file column names: @colNames.\nMissing headerline or invalid TMAP file.\n";
	exit(1);
}

@data = ();
@rowNames = ();
@rowDescs = ();
foreach $line (@lines[1..$#lines]) {
	@vals = split(/\t/, $line);
	push(@rowNames, trim($vals[$rnIndex]));
	push(@rowDescs, trim($vals[$rdIndex]));	
	push(@data, trim($vals[$dataIndex]));
}
	
#return error if all rownames are the same
$validRowNames = 0;
$char = $rowNames[0];
foreach $rn (@rowNames) {
	if ($rn ne $char) {
		$validRowNames = 1;
		last;
	}
}
if (!$validRowNames) {
	print STDERR "Error: The input file does not contain any valid rownames for \"$rowName\". Please make an alternate selection for rownames.\n";
	exit(1);
}

#if filterDashRowNames==yes, remove rows with "-" as rowName.
@kept_i = ();
if ($filterDashRowNames eq "yes") {
	for ($j=0;$j<=$#rowNames;$j++) {
		if ($rowNames[$j] ne "-") {
			push(@kept_i, $j);
		}
	}
	$numRemovedRows = $#rowNames - $#kept_i;	
	print "Filtered $numRemovedRows rows with invalid row names\n";
} else {
	@kept_i = (0..$#rowNames);  #keep all rows
}

#return error if all data values to be written to the GCT file are zero
$validData = 0;
for $i (@kept_i) {
	if ($data[$i] != 0) {
		$validData = 1;
		last;
	}	
}
if (!$validData && $numRemovedRows > 0) {
	print STDERR "Error: After filtering rows with invalid row names, all remaining $dataName values are zero.\n";
	exit(1);
} elsif (!$validData) {
	print STDERR "Error: The input file contains all-zero $dataName values.\n";
	exit(1);
}

#write GCT file	
open(OUT, ">$outputFile") || die ("Can't open file: $!");
print OUT "#1.2\n";
print OUT $#kept_i+1, "\t1\n";
print OUT $colNames[$rnIndex], "\tDescription\t$dataName\n";
for $i (@kept_i) {
	print OUT $rowNames[$i], "\t", $rowDescs[$i], "\t", $data[$i], "\n";
}


# Perl trim function to remove whitespace from the start and end of the string
sub trim($)
{
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}

