cleanup <- function() {
	files <- dir()
	for(file in files) {
		if(file != zip.file.name && file!=output.data.file.name && file!=output.cls.file.name) {
         unlink(file, recursive=TRUE)
      }
	}
		
}

setup <- function(libdir) {
	source(paste(libdir, "common.R", sep=''))
	setLibPath(libdir)
   options(warn=-1)
   options("verbose"=FALSE)
   if(!is.package.installed(libdir, "mclust")) {
   	log("installing package mclust")
   	install.package(libdir, "mclust_2.1-11.zip", "mclust_2.1-7.tgz", "mclust_2.1-11.tar.gz")
   }
   source(paste(libdir, "util.r", sep=""))
   source(paste(libdir, "process.r", sep=""))
}


pipeline.wrapper <- function(zip.filename, output.file.name, libdir, ...) {
	args <- list(...)
	
	quality.threshold <- 0.45
	mz.precision <- 0.00125
	fill.na <- TRUE
	normalize <- "tan"
	peak.matching <- 'em' # not in UI
	peaks <- 'detect'
	p2n.filter <- TRUE
	p2n.factor <- 10
	nclust.minfactor <- 0.9 # not in UI
	nclust.maxfactor <- 1.5 # not in UI
	input.peaks <- NULL # (if peaks = input) 
	random.seed <- 1 # (if peaks = random) 
	random.npeaks <- 200 # (if peaks = random) 

	low.Da <- NULL
	high.Da <- NULL
	percentile <- 0.65
	size.sm <- 21
	strength.abc <- 0.75
	size.abc  <- 21
	strength.hp <- 10
	factor.hp  <- 5
	
	for(i in 1:length(args)) {
		flag <- substring(args[[i]], 0, 3)
		value <- substring(args[[i]], 4, nchar(args[[i]]))
		
		if(value == '') {
			next
		}
		if(flag=='-_3') {
			quality.threshold <- as.numeric(value)
		} else if(flag=='-_4') {
			mz.precision <- as.numeric(value)
		} else if(flag=='-_5') {
			if(value=='yes') {
         	fill.na <- TRUE
         } else {
         	fill.na <- FALSE
         }
		} else if(flag=='-_6') {
			normalize <- value
		} else if(flag=='-_7') {
			peaks <- value
		} else if(flag=='-_8') {
			if(value=='yes') {
         	p2n.filter <- TRUE
         } else {
         	p2n.filter <- FALSE
         }
		} else if(flag=='-_9') {
			p2n.factor <- as.numeric(value)
		} else if(flag=='-10') {
			input.peaks <- read.table(value, colClasses=c('numeric'))
			input.peaks <- input.peaks[, 1]
		} else if(flag=='-11') {
			random.seed <- as.numeric(value)
		} else if(flag=='-12') {
			random.npeaks <- as.numeric(value)
		} else if(flag=='-13') {
			low.Da <- as.numeric(value)
		} else if(flag=='-14') {
			high.Da <- as.numeric(value)
		} else if(flag=='-15') {
			percentile <- as.numeric(value)
		} else if(flag=='-16') {
			size.sm <- as.numeric(value)
		} else if(flag=='-17') {
			strength.abc <- as.numeric(value)
		} else if(flag=='-18') {
			size.abc <- as.numeric(value)
		} else if(flag=='-19') {
			strength.hp <- as.numeric(value)
		} else if(flag=='-20') {
			factor.hp <- as.numeric(value)
		} else {
			stop("Unknown flag")
		}
   }    

   isWindows <- Sys.info()[["sysname"]]=="Windows"
	if(isWindows) {
		zip.unpack(zip.filename, dest=getwd())
	} else {
      zip <- getOption("unzip")
      system(paste(zip, "-q", zip.filename))
	}
   setup(libdir)
   
   files <- dir(recursive=TRUE)
   f <- file("names.txt", "w")
   
   for(i in 1:length(files)) {
      result <- regexpr(paste(".csv","$",sep=""), tolower(files[i]))
      if(result[[1]] != -1) {
         cat(files[i], "\n", file=f, append=TRUE, sep='') 
      }
   }
   close(f)
   
   limits.input <- c(low.Da, high.Da)
	result <- pipeline(filename="names.txt", data.directory=getwd(), structured.names=FALSE, limits.input=limits.input, combine.duplicate.peaks=max, checkpoint=FALSE, debug=FALSE, quality.threshold=quality.threshold, mz.precision=mz.precision, fill.na=fill.na, normalize=normalize, peak.matching=peak.matching, peaks=peaks, p2n.filter=p2n.filter, p2n.factor=p2n.factor, nclust.minfactor=nclust.minfactor, nclust.maxfactor=nclust.maxfactor, input.peaks=input.peaks, random.seed=random.seed, random.npeaks=random.npeaks, percentile=percentile, size.sm=size.sm, strength.abc=strength.abc, size.abc=size.abc, strength.hp=strength.hp, factor.hp=factor.hp)
	
   
   col.names <- colnames(result$output[[1]]$peaktable)
   
   col.names <- gsub('X-X-', '', col.names)
   col.names <- gsub('-0-X', '', col.names)
   
   colnames(result$output[[1]]$peaktable) <- col.names
   
   
   gct.file.name <- check.extension(output.file.name, ".gct")
   export(result$output[[1]]$peaktable, gct.file.name) # save as gct
 
   output.files <- list()
   output.files[1] <- gct.file.name
   output.files[2] <- zip.filename
  
   
   stats <- rbind(result$input, result$discard) # stats.odf file with statistics (min, max, normalization factor, selection flag, etc.) for every input spectrum.
   # names date chip eam sample fraction replicate energy   quality selected low.Da high.Da     area      min      max      avg n.peaks avg.peaks norm.factor
   
   stats <- cbind(stats['names'], stats['quality'], stats['selected'], stats['area'], stats['min'], stats['max'], stats['avg'], stats['n.peaks'], stats['avg.peaks'], stats['norm.factor'])
   
   stats.filename <- paste(output.file.name, "-stats.odf", sep='')
   output.files[3] <- stats.filename
   stats.file <- file(stats.filename, "w")
   cat("ODF 1.0\n", append=TRUE, file=stats.file)
   cat("HeaderLines=4\n", append=TRUE, file=stats.file)
   cat("COLUMN_NAMES:", append=TRUE, file=stats.file)
   for(i in 1:length(names(stats))) {
      if(i > 1) {
         cat(paste("\t", names(stats)[i], sep=''), append=TRUE, file=stats.file) 
      } else {
         cat(paste(names(stats)[i], sep=''), append=TRUE, file=stats.file) 
      }
   }
   cat("\n", append=TRUE, file=stats.file)
   cat("COLUMN_TYPES:String\tfloat\tString\tfloat\tfloat\tfloat\tfloat\tint\tfloat\tfloat", append=TRUE, file=stats.file)
   cat("\n", append=TRUE, file=stats.file)
   cat("Model=Proteomics Analysis Statistics\n", append=TRUE, file=stats.file)
   cat("DataLines=", NROW(stats), "\n", sep='', append=TRUE, file=stats.file)
   write.table(stats, file=stats.file, col.names=FALSE, row.names=FALSE, quote=FALSE, append=TRUE, sep="\t")
   close(stats.file)
   
   
   mzarray.filename <- paste(output.file.name, "-mzarray.odf", sep='') # mzarray.odf file listing the actual peaks detected for every input spectrum.
   output.files[4] <- mzarray.filename
   mzarray <- result$output[[1]]$allpeaks
   mzarray.file <- file(mzarray.filename, "w")
   cat("ODF 1.0\n", append=TRUE, file=mzarray.file)
   cat("HeaderLines=4\n", append=TRUE, file=mzarray.file)
   cat("COLUMN_NAMES:", append=TRUE, file=mzarray.file)
   mzarray.names <- dimnames(mzarray)[[2]]
   for(i in 1:length(mzarray.names)) {
      if(i > 1) {
         cat(paste("\t", mzarray.names[i], sep=''), append=TRUE, file=mzarray.file)  
      } else {
         cat(mzarray.names[i], append=TRUE, file=mzarray.file) 
      }
   }
   cat("\n", append=TRUE, file=mzarray.file)
   cat("COLUMN_TYPES:", append=TRUE, file=mzarray.file)
   for(j in 1:NCOL(mzarray)) {
      if(j > 1) {
         cat("\tfloat", append=TRUE, file=mzarray.file)  
      } else {
         cat("float", append=TRUE, file=mzarray.file) 
      }
   }
   cat("\n", append=TRUE, file=mzarray.file)
   cat("Model=Actual Peaks\n", append=TRUE, file=mzarray.file)
   cat("DataLines=", NROW(mzarray), "\n", sep='', append=TRUE, file=mzarray.file)
   write.table(mzarray, file=mzarray.file, col.names=FALSE, row.names=FALSE, quote=FALSE, append=TRUE, sep="\t")
   close(mzarray.file)

   if(peak.matching=='em') {
      em.peaks <- cbind (Mean=result$output[[1]]$em.results$em$mu, Variance=result$output[[1]]$em.results$em$sigma, Probability=result$output[[1]]$em.results$em$pro)
      
      empeaks.filename <- paste(output.file.name, "-empeaks.odf", sep='') # file containing a table listing the mean, variance and mixing probability for the Gaussian mixtures representing the matched peaks
      output.files[5] <- empeaks.filename
      empeaks.file <- file(empeaks.filename, "w")
      cat("ODF 1.0\n", append=TRUE, file=empeaks.file)
      cat("HeaderLines=4\n", append=TRUE, file=empeaks.file)
      cat("COLUMN_NAMES:Mean\tVariance\tMixing Probability\n", append=TRUE, file=empeaks.file)
      cat("COLUMN_TYPES:float\tfloat\tfloat", append=TRUE, file=empeaks.file)
      cat("\n", append=TRUE, file=empeaks.file)
      cat("Model=EM Gaussian Mixtures\n", append=TRUE, file=empeaks.file)
      cat("DataLines=", NROW(em.peaks), "\n", sep='', append=TRUE, file=empeaks.file)
      write.table(em.peaks, file=empeaks.file, col.names=FALSE, row.names=FALSE, quote=FALSE, append=TRUE, sep="\t")
      close(empeaks.file)
   
      
      allpeaks.em <- result$output[[1]]$em.results$allpeaks.em
      mzarrayem.filename <- paste(output.file.name, "-mzarray-em.odf", sep='') # file that shows the mapping of actual peaks to EM-matched peaks for every spectrum
      output.files[6] <- mzarrayem.filename
      mzarrayem.file <- file(mzarrayem.filename, "w")
      cat("ODF 1.0\n", append=TRUE, file=mzarrayem.file)
      cat("HeaderLines=4\n", append=TRUE, file=mzarrayem.file)
      cat("COLUMN_NAMES:", append=TRUE, file=mzarrayem.file)
      allpeaks.em.names <- dimnames(allpeaks.em)[[2]]
      for(i in 1:length(allpeaks.em.names)) {
         if(i > 1) {
            cat(paste("\t", allpeaks.em.names[i], sep=''), append=TRUE, file=mzarrayem.file)  
         } else {
             cat(paste(allpeaks.em.names[i], sep=''), append=TRUE, file=mzarrayem.file)  
         }
      }
      cat("\n", append=TRUE, file=mzarrayem.file)
      cat("COLUMN_TYPES:", append=TRUE, file=mzarrayem.file)
      for(j in 1:NCOL(allpeaks.em)) {
         if(j > 1) {
            cat("\tfloat", append=TRUE, file=mzarrayem.file)  
         } else {
            cat("float", append=TRUE, file=mzarrayem.file)
         }
      }
      cat("\n", append=TRUE, file=mzarrayem.file)
      cat("Model=Actual Peaks To EM-matched Peaks \n", append=TRUE, file=mzarrayem.file)
      cat("DataLines=", NROW(allpeaks.em), "\n", sep='', append=TRUE, file=mzarrayem.file)
      write.table(allpeaks.em, file=mzarrayem.file, col.names=FALSE, row.names=FALSE, quote=FALSE, append=TRUE, sep="\t")
      close(mzarrayem.file)
   }
   

   contains <- function(list, data) {
      for(i in list) {
         if(i==data) {
            return(TRUE)  
         }
      }
      return(FALSE)
   }
   
   # delete all other files except gct file, input zip file
   files <- dir()
	for(file in files) {
		if(!contains(output.files, file)) {
         unlink(file, recursive=TRUE)
      }
	}

}

areachange.wrapper <- function(spectra.file, output.file, threshold, libdir, ...)  {
   args <- list(...)
   window.filter <- 5
   factor <- 3
   smooth <- "median"
   
	for(i in 1:length(args)) {
		flag <- substring(args[[i]], 0, 2)
		value <- substring(args[[i]], 3, nchar(args[[i]]))
		
		if(flag=='-l') {
			low.Da <- as.numeric(value)
      } else if(flag=='-h') {
         high.Da <- as.numeric(value)
      } else if(flag=='-w') {
			window.filter <- as.numeric(value)
			if(is.na(window.filter)) {
				window.filter <- 5
			}
      } else if(flag=='-f') {
			factor <- as.numeric(value)
			if(is.na(factor)) {
				factor <- 3
			}
      } else if(flag=='-s') {
			smooth <- value
      }
   }
             
   threshold <- as.numeric(threshold)
   if(threshold > 1 || threshold < 0) {
      stop("threshold must be between 0 and 1")  
   }
   setup(libdir)
   data <- read.spectrum(spectra.file)
   if(is.na(low.Da)) {
		low.Da <- min(data[,1])
	}
   if(is.na(high.Da)) {
		high.Da <- max(data[,1])
	}
   window.noise <- (100*window.filter - 1)
   r <- areachange(data, as.numeric(low.Da), as.numeric(high.Da), threshold, window.filter=window.filter, window.noise=window.noise, factor=factor, smooth=smooth)
   areachange <- r[[1]]
   area.original <- r[[2]]
   selected <- r[[3]]
   spectra <- r[4]$spectra
   
   output.file <- check.extension(output.file, ".odf")
   f <- file(output.file, "w")
   cat("ODF 1.0\n", append=TRUE, file=f)
   cat("HeaderLines=8\n", append=TRUE, file=f)
   cat("COLUMN_NAMES:M/Z\tIntensity\tNoise Env\tNoise\n", append=TRUE, file=f)
   cat("COLUMN_TYPES:float\tfloat\tfloat\tfloat\n", append=TRUE, file=f)
   cat("Model=Spectrum Area Change\n", append=TRUE, file=f)
   cat("Spectrum=", spectra.file, "\n", sep='', append=TRUE, file=f)
   cat('area change=', areachange, "\n", sep='', append=TRUE, file=f)
   cat('original area=', area.original, "\n", sep='', append=TRUE, file=f)
   cat('selected=', selected, "\n", sep='', append=TRUE, file=f)
   cat("DataLines=", NROW(spectra), "\n", sep='', append=TRUE, file=f)
   write.table(spectra, file=f, col.names=FALSE, row.names=FALSE, quote=FALSE, append=TRUE, sep="\t")
   close(f)
   
   
}

peaks.wrapper  <- function(spectra.file, output.file.name, libdir, ...) {
   setup(libdir)
   data <- read.spectrum(spectra.file)
   args <- list(...)
   for(i in 1:length(args)) {
		flag <- substring(args[[i]], 0, 2)
		value <- substring(args[[i]], 3, nchar(args[[i]]))
		
		if(flag=='-l') {
			low.Da <- as.numeric(value)
      } else if(flag=='-h') {
         high.Da <- as.numeric(value)
      } else if(flag=='-p') {
         percentile <- as.numeric(value)
      } else if(flag=='-a') {
         size.sm <- as.numeric(value)
      } else if(flag=='-b') {
         strength.abc<- as.numeric(value)
      } else if(flag=='-c') {
         size.abc <- as.numeric(value)
      } else if(flag=='-d') {
         strength.hp <- as.numeric(value)
      } else if(flag=='-e') {
      	factor.hp <- as.numeric(value)
      }
   }
                   
   if(is.na(low.Da)) {
		low.Da <- min(data[,1])
	}
   if(is.na(high.Da)) {
		high.Da <- max(data[,1])
	}
	
   result <- peaks(data, low.Da=low.Da, high.Da=high.Da, percentile=percentile, size.sm=size.sm, strength.abc=strength.abc, size.abc=size.abc, strength.hp=strength.hp, factor.hp=factor.hp)
   output.file.name <- check.extension(output.file.name, ".odf")
   f <- file(output.file.name, "w")
   cat("ODF 1.0\n", append=TRUE, file=f)
   cat("HeaderLines=5\n", append=TRUE, file=f)
   cat("COLUMN_NAMES:M/Z\tIntensity\tPeak\n", append=TRUE, file=f)
   cat("COLUMN_TYPES:float\tfloat\tfloat\n", append=TRUE, file=f)
   cat("Model=Spectrum Peaks\n", append=TRUE, file=f)
   cat("Spectrum=", spectra.file, "\n", sep='', append=TRUE, file=f)
   cat("DataLines=", NROW(result), "\n", sep='', append=TRUE, file=f)
   write.table(result, file=f, row.names=FALSE, col.names=FALSE, quote=FALSE, append=TRUE, sep="\t")
   close(f)
   
}

read.output.from.peaks <- function(output.from.peaks) {
   ret <- try(
      read.table(output.from.peaks, header=FALSE, row.names=NULL, skip=7, sep="\t"), 
      silent=TRUE
   )
   if(class(ret)=="try-error") {
      stop(paste("An error occurred while reading the file ", output.from.peaks, sep=''), call.=FALSE)
   }
   ret
}

read.spectrum <- function(spectrum.file) {
   ret <- try(
      read.table(spectrum.file, sep=",", colClasses=c('numeric', 'numeric'), header=TRUE), 
      silent=TRUE
   )
   if(class(ret)=="try-error") {
      stop(paste("An error occurred while reading the file ", spectrum.file, sep=''), call.=FALSE)
   }
   ret
}

peaks.locate.wrapper <- function (output.from.peaks, output.file.name, peak.locate, libdir) {
   setup(libdir)
   data <- read.output.from.peaks(output.from.peaks)
   result <- peaks.locate(data, peak.locate=peak.locate)
   output.file.name <- check.extension(output.file.name, ".odf")
   f <- file(output.file.name, "w")
   cat("ODF 1.0\n", append=TRUE, file=f)
   cat("HeaderLines=6\n", append=TRUE, file=f)
   cat("COLUMN_NAMES:M/Z\tIntensity\tPeak\tPeak Center\n", append=TRUE, file=f)
   cat("COLUMN_TYPES:float\tfloat\tfloat\tfloat\n", append=TRUE, file=f)
   cat("Model=Spectrum Peaks Locate\n", append=TRUE, file=f)
   cat("Input File=", output.from.peaks, "\n", sep='', append=TRUE, file=f)
   cat("Peak Locate=", peak.locate, "\n", sep='', append=TRUE, file=f)
   cat("DataLines=", NROW(result), "\n", sep='', append=TRUE, file=f)
   write.table(result, file=f, row.names=FALSE, col.names=FALSE, quote=FALSE, append=TRUE, sep="\t")
   close(f)
   
}

plot.peaks.wrapper <- function (output.from.peaks, output.file.name, libdir) {
   setup(libdir)
   output.file.name <- check.extension(output.file.name, ".pdf")
   data <- read.output.from.peaks(output.from.peaks)
   pdf(file=output.file.name)
   plot.peaks(data, xlab="M/Z", ylab="Intensity")
   dev.off()
  	return(output.file.name)
}



check.extension <- function(s, extension) {
   ext <- regexpr(paste(extension,"$",sep=""), tolower(s))
	if(ext[[1]] == -1) {
		s <- paste(s, extension, sep="") # ensure correct file extension
	}
   s
}

spectra.compare.wrapper <- function(spectra.file1, spectra.file2, output.file.name, libdir, ...) {
   
   setup(libdir)
   
   data1 <- read.spectrum(spectra.file1)
  
   data2 <- read.spectrum(spectra.file2)
   args <- list(...)
	
	for(i in 1:length(args)) {
		flag <- substring(args[[i]], 0, 2)
		if(flag=='-l') {
			low.Da <- as.numeric(substring(args[[i]], 3, nchar(args[[i]])))
      } else if(flag=='-h') {
         high.Da <- as.numeric(substring(args[[i]], 3, nchar(args[[i]])))
      } 
   }
   
   if(is.na(low.Da)) {
		 min1 <- min(data1[,1])
       min2 <- min(data2[,2])
       low.Da <- min(min1, min2)
	}
   
   if(is.na(high.Da)) {
		max1 <- max(data1[,1])
      max2 <- max(data2[,2])
      high.Da <- max(max1, max2)
	}
  
   result <- spectra.compare(spectra.file1, spectra.file2, dir=getwd(), low.Da=low.Da, high.Da=high.Da)
   
   output.file.name <- check.extension(output.file.name, ".odf")
   f <- file(output.file.name, "w")
   cat("ODF 1.0\n", append=TRUE, file=f)
   cat("HeaderLines=5\n", append=TRUE, file=f)
   cat("Model=Spectra Similarity\n", append=TRUE, file=f)
   cat("Spectrum 1=", spectra.file1, "\n", sep='', append=TRUE, file=f)
   cat("Spectrum 2=", spectra.file2, "\n", sep='', append=TRUE, file=f) 
   cat("Similarity score=", result, "\n", sep='', append=TRUE, file=f) 
   cat("DataLines=0\n", append=TRUE, file=f)
   close(f)
}
   
   
                     
                     



