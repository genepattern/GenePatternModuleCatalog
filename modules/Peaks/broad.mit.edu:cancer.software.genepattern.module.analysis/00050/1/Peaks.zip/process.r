#
# $Id: process.r,v 1.3 2005/01/04 22:10:44 jgould Exp $
#
# Main pipeline script for proteomics data processing.
# This file is self contained, and necessary functions from other
# stats subdirectories have been copied to this file, to enable
# independent modification for pipeline processing purposes
#
#
#
# ANALYSIS PIPELINE
#
# read a file with names of spectra
#
# QUALITY
# for each low energy spectrum
#   compute quality
# quality for other energies = low energy spectrum quality
# delete spectra with "poor" quality
# create final list of spectra
#
# NORMALIZATION
# for each spectrum
#   compute area
# for low, high energy spectra (separately)
#   avgarea = sum (area) / # spectra
# for each spectrum
#   normalize (multiply by avgarea/spectrum area)
#
# PEAK DETECTION
# for each spectrum
#   run peak detection
#
# POST PROCESSING
# determine "same" peaks (based on EM or m/z variation)
# tabluate union of peaks for spectra by chip x eam x energy x fraction
#
#
#
# NOTE: All processing is done by reading a spectrum, processing it,
#       and then discarding it. This enables less dependence on memory
#       availability, albeit at a slight performance penalty
#
#
#
# PIPELINE INPUT:
#  * A single file listing spectra to be processed:
#     - one spectrum on each line
#     - spectrum name must conform to name.components
#        separated by name.sep (see Global constants)
#     - spectra listed in desired output order
#
# PIPELINE OUTPUT:
#  * A List with the following elements
#     - output
#        . a list with one list for each chip x eam combination
#        . each list has [[chip, eam, peaktable]]
#        . peaktable: [ m.z, sample1, sample 2, ... ]
#     - input
#        . table with names of spectra,
#        . columns explicating the names
#        . area and normalization factors
#     - allpeaks
#        . table listing all peaks for all spectra (across all
#          chip, eam, energy, fraction and sample combinations)
#
#


library (ts)
library (mclust)

#
# "Global" constants
#
# column labels
date <- 'date'
chip <- 'chip'
eam <- 'eam'
sample <- 'sample'
fraction <- 'fraction'
replicate <- 'replicate'
energy <- 'energy'
# valid values
chips <- list (wcx='W', imac='I', c16='C', none='X')
eams <- list (chca='C', spa='S', none='X')
fractions <- list (one='1', two='2', three='3', four='4', five='5', six='6',
                   unfractionated='0', none='X', longitudinal='L')
replicates <- list (one='1', two='2')
energies <- list (low='L', high='H', none='X')
limits <- c('low.Da', 'high.Da')
# structure of spectrum file names
name.components <- c(date,chip,eam,sample,fraction,replicate,energy)
name.components.default <- list (date=date(), chip='X', eam='X', sample=NA, fraction='0',
                                 replicate='1', energy='X')
name.sep <- '-'

# implemented normalization schemes
#  tan: total area normalization
#  tin: total intensity normalization
#  01:  x' = (x-min) / (max-min)
#  NB: total ion current (tic) is now renamed tan
normalizations <- c ('tan', 'tin', '01', 'none')

# supported peak location schemes
#  detect:  detect peaks using peak detector
#  random:  select random m/z values for "peaks"
#  input:   list of peak m/z values given
peaks.location <- c ('detect', 'random', 'input')

# supported peak matching schemes
#  window:  uses mean +- 3*sd window in a +-mz.precision frontier for matching peaks
#  em:      EM-based mixture of gaussians model for peak matching
#            (with em, "duplicate" peaks in a sample are combined using
#            the function specified in combine.duplicate.peaks)
peak.matching.algo <- c ('window', 'em')

# m/z cutoffs (spectrum ranges) for eams x energies
# mainly to ignore matrix signature for peak detection / normalization
m.z <- c (900,   1500,   0,            # low.Da for eams, energies==L   (x low.Da.qfactor for quality)
          20000, 20000,  1e6,          # high.Da for eams, energies==L
          20000, 20000,  0,            # low.Da for eams, energies==H
          50000, 50000,  1e6,          # high.Da for eams, energies==H
          0,     0,      0,            # low.Da for eams, energies==X
          1e6,   1e6,    1e6)          # high.Da for eams, energies==X
dim (m.z) <- c( length(eams),length(limits),length(energies) )  # [eam, limits, energy]
dimnames (m.z) <- list (eams, limits, energies)
low.Da.qfactor <- 1.4                # for quality computation, multiply low.Da by this factor
# entire spectrum
m.z.all <- c (0,     0,      0,            # low.Da for eams, energies==L
              20000, 20000,  1e6,          # high.Da for eams, energies==L
              20000, 20000,  0,            # low.Da for eams, energies==H
              50000, 50000,  1e6,          # high.Da for eams, energies==H
              0,     0,      0,            # low.Da for eams, energies==X
              1e6,   1e6,    1e6)          # high.Da for eams, energies==X
dim (m.z.all) <- c( length(eams),length(limits),length(energies) )  # [eam, limits, energy]
dimnames (m.z.all) <- list (eams, limits, energies)


#
# Data validation
#
data.check <- function (data) {
  # returns FALSE if data has invalid values for columns noted above
  index <- rep (FALSE, dim(data)[1])
  index.c <- index; for (c in chips) { index.c <- index.c | data[,chip]==c }
  index.e <- index; for (e in eams) { index.e <- index.e | data[,eam]==e }
  index.f <- index; for (f in fractions) { index.f <- index.f | data[,fraction]==f }
  index.g <- index; for (g in energies) { index.g <- index.g | data[,energy]==g }
  index.r <- index; for (r in replicates) { index.r <- index.r | data[,replicate]==r }

  min ( index.c & index.e & index.f & index.g & index.r )
}


#
# Noise
#
noise <- function (trace, window.filter=5, window.noise=(100*window.filter - 1),
                   factor=3, smooth="median") {

  w.filter <- floor (window.filter / 2)
  w.noise <- floor (window.noise / 2)
  
  # apply low pass filter to remove noise; then
  # noise = original trace - filtered (noise-free) trace
  n <- length (trace)
  
  noise <- 1:n
  for (i in 1:n) {
    if ( i <= w.filter || i >= (n-w.filter) ) noise[i] <- 0
    else {
      if (smooth == "median")
        noise[i] <- trace[i] - median ( trace[(i-w.filter):(i+w.filter)] )
      else if (smooth == "mean")
        noise[i] <- trace[i] - mean ( trace[(i-w.filter):(i+w.filter)] )
      else stop ("Averaging function must be smooth=mean|median.")
    }
  }

  noise.envelope <- 1:n
  for (i in 1:n) {
    if ( i <= w.noise || i >= (n-w.noise) ) noise.envelope[i] <- 0
    else noise.envelope[i] <- factor * sd ( noise[(i-w.noise):(i+w.noise)] )
  }

  cbind (noise, noise.envelope)
}


#
# Quality Assessment
#
areachange <- function (data1, low.Da, high.Da, threshold, ...) {

  # compute noise and noise envelope
  noise1.all <- noise (data1[,2], ...)
  noise1 <- noise1.all[,2]
  # subtract noise envelope
  intensity.abs <- abs (data1[,2])   # so that only the +ve noise envelope can be used
  spec1 <- intensity.abs - noise1
  spec1[spec1 < 0] <- 0

  ds1 <- cbind (data1[,1], intensity.abs, spec1)

  i1 <- ds1[,1] >= low.Da & ds1[,1] <= high.Da
  trace1 <- ds1[i1,]
  n <- dim(trace1)[1] - 1

  # compute area under original spectrum 
  area <- (trace1[-1,1]-trace1[,1]) * (trace1[,2]+trace1[-1,2]) / 2
  area.orig <- sum ( area [1:n] )

  # compute area after noise env is removed
  area <- (trace1[-1,1]-trace1[,1]) * (trace1[,3]+trace1[-1,3]) / 2
  area.new <- sum ( area [1:n] )

  area.ratio <- area.new / area.orig

  # check if threshold needs to be overridden
  selected <- (area.ratio >= threshold)
  
  if (! selected) {
    # override threshold if there are "peaks" that did not
    # contribute enough to area computation
    factor <- 5
    limit <- 1.00  # percent
    protrusions <- abs (data1[,2]) - factor * noise1
    ds <- cbind (data1, noise1, protrusions)
    trace <- ds [ ds[,1]>low.Da & ds[,1]<high.Da & ds[,3]!=0, 4]
    protrusions.percent <- 100 * length ( trace [trace>0] ) / length (trace)
    
    if (protrusions.percent > limit) selected <- TRUE
  }

  # combine noise and spectra
  all <- cbind (trace1[,1:2], noise1[i1], (noise1.all[,1])[i1])
  return.value <- list (area.change=area.ratio, area.original=area.orig,
                        selected=selected, spectra=all)
  # returns: [[area.ratio]], [[area.orig]], [[selected]],
  #          [[M/Z, orig, noise_env, noise]]
  invisible (return.value)
}



#
# Filters (for peak detection)
#
filter.padded <- function (data, f, pad.value=0) {
  len <-length (f)
  data.padded <- c ( rep(pad.value,len), data, rep(pad.value,len) )
  data.padded.f <- filter (data.padded, f)
  data.f <- data.padded.f [ (len+1) : (length(data.padded.f)-len) ]

  data.f
}


makefilter <- function (f, factor, normalize=TRUE) {
  f.expanded <- NULL

  for (i in 1:length(f)) {
    f.expanded <- c ( f.expanded, rep (f[i], factor) )
  }

  if (normalize == TRUE)
    f.expanded <- f.expanded / length(f.expanded)
  
  f.expanded
}


smooth <- function (data, size=21, pad=TRUE) {
  f <- rep (1, size)
  f <- f/length(f)

  if (pad == FALSE) data.f <- filter (data, f)
  else data.f <- filter.padded (data, f)
  
  data.f
}


smooth.median <- function (data, size=21, threshold=2) {
  # thresholded median filter (pg. 162, Gonzalez & Wintz)
  data.f <- data
  n <- length (data)
  for (i in 1:n) {
    if ( i <= size || i >= n-size ) data.f[i] <- 0
    else {
      m <- median ( data[(i-size):(i+size)] )
      if ( abs(data[i] - m) < threshold ) data.f[i] <- m
    }
  }

  data.f
}


highpass <- function (data, strength=15, factor=1, pad=TRUE) {
  # use odd sized factor to ensure filter symmetry
  hp <- c(-1,-1,-1,-2,1,strength,1,-2,-1,-1,-1)
  hp.expanded <- makefilter (hp, factor)

  if (pad == FALSE) data.f <- filter (data, hp.expanded)
  else data.f <- filter.padded (data, hp.expanded)
  
  data.f
}


abc <- function (data, strength=0.75, size=21, pad=TRUE) {
  # adaptive background correction (unsharp masking) filter
  data.f <- data - strength * smooth(data, size, pad)
  data.f
}




#
# Peak Detection
#
peaks <- function (data, low.Da=min(data[,1]), high.Da=max(data[,1]),
                   percentile=0.65, size.sm=21,
                   strength.abc=0.75, size.abc=21,
                   strength.hp=10, factor.hp=5,
                   plot.filters=FALSE, plot.final=FALSE, ... ) {

  # take data in required range
  data <- data [ data[,1]>=low.Da & data[,1]<=high.Da, ]

  # apply sequence of filters
  data.1 <- smooth (data[,2], size.sm)
  data.2 <- abc (data.1, strength.abc, size.abc)
  data.3 <- highpass (data.2, strength.hp, factor.hp)

  # smooth output of highpass filter (above) and identify peaks by
  # adaptive thresholding (based on percentile of data above threshold)
  data.final <- smooth (data.3)
  threshold <- quantile (data.final, prob=percentile, na.rm=TRUE, names=FALSE)
  #data.final [ data.final < threshold ] <- 0
  data.final <- data.final - threshold
  data.final [ data.final < 0 ] <- 0

  # plot if needed
  if (plot.filters == TRUE) plot.filter (data, data.1, data.2, data.3, ... )
  if (plot.final == TRUE) points (data[,1], data.final, type="l", pch=".", col=5)

  # return m/z, orginal, peaks
  return.value <- cbind (data[,1], data [,2], data.final)
  invisible (return.value)
}



peaks.seg <- function (data.low, data.high=NULL, low.Da=min(data.low[,1]),
                       high.Da=max(data.high[,1]),
                       split.Da=5000, low.max=20000, delta.Da=500, ... ) {
  #
  # segmented peak detector
  # takes low & high energy spectra, chops into fragments,
  # and detects peaks in each fragment
  #
  
  d <- NULL
  
  # run peaks() for each segment of length split.Da daltons;
  # this segmentation accommodates peak broadening at higher molecular weights
  for ( i in seq (low.Da, high.Da-split.Da, by=split.Da) ) {
    if (i < low.max) data <- data.low
    else if (! is.null(data.high) ) data <- data.high
    else stop ("Can't find data for segmented peak detection.")
    p <- peaks (data, low.Da=i-delta.Da, high.Da=i+split.Da+delta.Da,
                plot.filters=FALSE, ... )
    d <- rbind ( d, p[ p[,1]>=i & p[,1]<=i+split.Da, ] )
  }

  return.value <- d
  invisible (return.value)
}


peaks.locate <- function (d, peak.locate="max") {
  # input data d is the output of peaks()
  
  # for each identified peak (i.e., set of non-zero filtered values
  # flanked by 0's), locate the peaks as
  #   (peak.locate=max)  location of maximum filtered value
  #   (peak.locate=area) center of area of the peak
  i <- 1
  n <- length (d[,1])
  peaks.center <- rep (0, n)
  repeat {
    if (i >= n) break
    # find next peak
    while ( d[i,3] == 0 || is.na(d[,3]) ) {
      i <- i+1
      if (i >= n) break
    }
    start <- i
    while ( d[i,3] != 0 ) {
      i <- i+1
      if (i >= n) break
    }
    end <- i-1

    if (start < end) {
      # locate new peak
      p.n <- d[start:end,]
      if (peak.locate == "max") {
        index <- p.n[,3] == max(p.n[,3])
      } else if (peak.locate == "area") {
        area <- (p.n[-1,1]-p.n[,1]) * (p.n[,3]+p.n[-1,3]) / 2
        area <- c (0, area[1:(length(area)-1)]) # delete extraneous last element
        area.diff <- abs ( cumsum (area) - (sum(area)/2) )
        index <- area.diff == min(area.diff)
      } else stop ("peak.locate must be max | area.")
      peaks.center[start:end] <- p.n[,2] * index
    }
  }

  d.final <- cbind (d, peaks.center)
  invisible (d.final)
}



#
# Normalization
#
norm.parameters <- function (data, low.Da, high.Da, norm.type, stats) {
  # computes values needed for normalizing based on norm.type
  # computes all values if stats=TRUE
  area <- 0
  min <- 0
  max <- 0
  mean <- 0

  if ( norm.type == 'none' && !stats )
    return ( list (area=area, min=min, max=max, mean=mean) )
  
  i <- data[,1] > low.Da & data[,1] < high.Da
  trace <- data[i,]
  n <- dim(trace)[1] - 1

  if ( norm.type == 'tan' || stats ) {
    # compute area under spectrum 
    area.v <- (trace[-1,1]-trace[,1]) * (trace[,2]+trace[-1,2]) / 2
    area <- sum ( area.v [1:n] )
  }

  if ( norm.type == 'tin' || stats )
    # compute average spectrum intensity
    mean <- mean (trace[,2])

  if ( norm.type == '01' || stats ) {
    # compute max and min for spectrum intensities
    min <- min (trace[,2])
    max <- max (trace[,2])
  }

  return ( list (area=area, min=min, max=max, mean=mean) )
}


normalize <- function (values, factors, type) {
  if (type == 'none') return (values)
  else if (type == 'tan' || type == 'tin') return (values * factors$norm.factor)
  else if (type =='01') return ( (values - factors$min) * factors$norm.factor )
  else stop ("Unknown normalization scheme escaped error check!")
}



#
# Graphics
#
plot.noise <- function (data, ...) {
  # data[m.z, intensity, noise, noise.envelope]
  plot (data[,1], data[,2], pch=".", type="o", ...)
  points (data[,1], data[,3], pch=".", type="o", col=2)
  points (data[,1], data[,4], pch=".", type="o", col=3)
}


plot.filter <- function (data, data.f, data.f1=NULL, data.f2=NULL,
                         data.f3=NULL, data.f4=NULL, data.f5=NULL, ... ) {
  # data[x, data.unfiltered]
  plot (data[,1], data[,2], pch=".", type="l", ... )
  points (data[,1], data.f, pch=".", type="l", col=2)
  if (! is.null(data.f1) ) points (data[,1], data.f1, pch=".", type="l", col=3)
  if (! is.null(data.f2) ) points (data[,1], data.f2, pch=".", type="l", col=4)
  if (! is.null(data.f3) ) points (data[,1], data.f3, pch=".", type="l", col=5)
  if (! is.null(data.f4) ) points (data[,1], data.f4, pch=".", type="l", col=6)
  if (! is.null(data.f5) ) points (data[,1], data.f5, pch=".", type="l", col=7)
}


plot.peaks <- function (data, ...) {
  # data has [m/z, original, peaks], as returned by peaks()
  plot (data[,1], data[,2], pch=".", type="l", ...)
  for ( i in 3:dim(data)[2] ) {
    points (data[,1], data[,i], pch=".", type="l", col=i-1)
  }
}



#
# Filling in peaks
#
fill.NAs <- function (table, files, dir, norm.factors, norm.type) {
  m.z <- table[,1]
  for (r in 2:dim(table)[2]) {
    NAs <- is.na (table[,r])
    if ( max (NAs) == 1 ) {
      mz.na <- m.z [NAs]
      data <- read.csv ( paste(dir,files[r-1],sep='/') )
      values <- approx (data[,1], data[,2], mz.na)$y
      table[NAs, r] <- normalize (values, norm.factors[r-1,], norm.type)
    }
  }
  table
}


# this function was used for interpolation in the pipeline and in fill.NAs
# approx (...) does the same thing much faster and has replaced fill.value
fill.value <- function (m.z, data) {
  e <- data[ data[,1]==m.z, ]
  if ( dim (e)[1] != 0 ) v <- e[,2]  
  else {
    # exact m.z not available in data
    i <- match (TRUE, data[,1]>m.z)
    l <- data[i-1,]   # low
    h <- data[i,]     # high
    v <- h[,2] - (h[,1]-m.z) * (h[,2]-l[,2])/(h[,1]-l[,1])  # interpolate
  }

  v
} 



# 
# Equality Checking
#
eq.row <- function (v1, v2) {
  # check if all elements of v1 and v2 are identical
  if ( length(v1) != length(v2) ) return (FALSE)

  return.value <- all (v1 == v2)
  return.value
}


eq.rows <- function (data, row, columns) {
  # returns a vector v of size dim(data)[1]
  # with v[i]==TRUE if data[i,columns]==row[columns]

  
  # conceptually, the following is what needs to be done
  # (and was being done previously):
  #     return.value <- NULL
  #     for (i in 1:dim(data)[1])
  #       return.value <- c ( return.value, eq.row(data[i,columns],row[columns]) )
  # but the above is too slow when data has lots (thousands) of rows
  # the following is much faster

  return.value <- rep ( TRUE, nrow(data) )
  for ( i in 1:length(columns) )
    return.value <- return.value & data[,columns[i]] == row[,columns[i]]
  
  return.value
}



#
# Likelihood/EM based peak matching support
#
reassemble <- function (fit, d.orig) {
  peaks <- dim(d.orig)[1]   # rows
  samples <- dim(d.orig)[2] # columns
  
  blank <- rep (NA, peaks*samples)
  fit.array <- array (blank, dim(d.orig))

  n.peaks <- unlist ( lapply (1:samples, function (i) { sum (!is.na(d.orig[,i])) }) )
  for (s in 1:samples) {
    if (n.peaks[s] == 0) next  # no peaks for this sample
    fit.array [1:n.peaks[s], s] <- fit [1:n.peaks[s]]
    fit <- fit [ (n.peaks[s]+1):length(fit) ]
  }

  return (fit.array)
}



  

#
# Main Pipeline
#
pipeline <- function (filename,                     # list of spectra filenames
                      data.directory,               # directory where spectra files are located
                      structured.names=TRUE,        # spectra file names indicate prep/scanning conditions
                      limits.input=NULL,            # limits=c(low.Da,high.Da) when structured.names=FALSE
                      quality.threshold=0.45,       # discard spectra with quality < quality.threshold
                      quality.input=NULL,           # data frame listing precomputed quality
                      peaks.segmented=FALSE,        # use segmented peak detection?
                      mz.precision=0.00125,         # m/z precision for window peak matching
                      mz.center="mean",             # locating matched peaks [mean|median]
                      fill.na=TRUE,                 # fill missing peaks?
                      normalize="tan",              # normalization strategy [tan|tin|01|none]
                      proc.replicates="best",       # dealing with replicates [best|average]
                      entire.spectrum=FALSE,        # process entire spectrum (incl. matrix)?
                      peaks='detect',               # peak detection method [detect|input|random]
                      peak.matching='em',           # peak matching technique [window|em]
                      p2n.filter=TRUE,              # filter peaks based on peak intensity / noise 
                      p2n.factor=10,                # peak intensity >= p2n.factor * sd(noise)
                      perturb=TRUE,                 # perturb peaks for em peak matching
                      perturb.factor=100,           # perturbation sd decided by perturb.factor
                      nclust.minfactor=0.9,         # for em, start with n = max peaks * nclust.minfactor
                      nclust.maxfactor=1.5,         # for em, stop with n = max peaks * nclust.maxfactor
                      combine.duplicate.peaks=max,  # intensity for peaks collapsed by em matching
                      input.peaks=NULL,             # m/z for input peaks when peaks='input'
                      random.npeaks=200,            # no. of random m/z's selected when peaks='random'
                      random.seed=1,                # randnum generator seed for peaks='random' [int|NULL]
                      stats=TRUE,                   # collect statistics?
                      stats.only=FALSE,             # collect stats, but don't create final table?
                      checkpoint=TRUE,              # enable checkpointing?
                      checkpoint.dir="checkpoint",  # directory where checkpointing files are written
                      debug=TRUE, ...) {
  # filename points to a file containing the spectra filenames (in data.directory)
  # for all spectra to be processed, with one spectrum file listed on each line

  # read spectra names from file, disassemble name,
  # and create table for storing "quality" and "selected" info
  if (debug) print ("Processing spectra file names ...", quote=FALSE)
  names <- sort (scan ( filename, what="string", sep="\n", quiet = TRUE))
  
  # remove file extension (careful, there might be other .'s in the name)
  split.on.dot <- t ( data.frame (strsplit(names,'\\.')) )
  names.noext <-
    unlist ( lapply (1:dim(split.on.dot)[1],
                     function (i) { paste (lapply (split.on.dot[i,1:(dim(split.on.dot)[2]-1)],
                                                   toString),
                                           sep='.', collapse='.') }) )

  default.value <- 0
  n.names <- length (names)

  if (structured.names) {
    # split name at seperator
    names.split <- strsplit (names.noext, name.sep)
    spectra.all <- t ( data.frame(names.split, row.names=name.components) )
  } else {
    # spectra file names do not contain metadata -- create spectra.all using name.components.default
    # also initialize m.z and m.z.all arrays to use low.Da.input and high.Da.input
    spectra.all <- NULL
    for ( i in 1:length(name.components) )
      spectra.all <- cbind (spectra.all, rep ( name.components.default[[i]], n.names ))
    colnames (spectra.all) <- name.components
    spectra.all[,sample] <- names.noext  # use spectra filenames as sample names
    for ( i in 1:length(limits) ) 
      m.z [name.components.default$eam, limits[i], name.components.default$energy] <-
        m.z.all [name.components.default$eam, limits[i], name.components.default$energy] <-
          limits.input[i]
  }
  
  # cleanup, add needed variables
  row.names (spectra.all) <- NULL
  selected <- rep (TRUE, n.names)
  low.Da <- rep (default.value, n.names)
  high.Da <- rep (default.value, n.names)
  area <- rep (default.value, n.names)
  min <- rep (default.value, n.names)
  max <- rep (default.value, n.names)
  avg <- rep (default.value, n.names)
  n.peaks <- rep (default.value, n.names)
  avg.peaks <- rep (default.value, n.names)
  norm.factor <- rep (default.value, n.names)
  if ( is.null(quality.input) ) quality <- rep (default.value, n.names)
  else {
    # quality.input is specified; should contain names and quality
    quality <- merge ( data.frame (I(names)), quality.input,
                       by='names', all.x=TRUE, sort=TRUE ) [,'quality']
    quality [ is.na(quality) ] <- default.value
  }
  if (debug) print ("Assembling spectra.all table ...", quote=FALSE)
  spectra.all <- data.frame (I(names), spectra.all, quality, I(selected),
                             low.Da, high.Da, area, min, max, avg,
                             n.peaks, avg.peaks, norm.factor)

  # error checking
  # abort if invalid values are detected in spectra.all
  if (debug) print ("Validating spectra file names ...", quote=FALSE)
  if (! data.check(spectra.all) )
    stop ("Invalid values detected in spectra filename(s)")
  # abort if normalization scheme requested is unknown
  if (! normalize %in% normalizations)
    stop ( paste ("Unknown normalization scheme:", normalize) )
  # abort if peak location scheme unknown
  if (! peaks %in% peaks.location)
    stop ( paste ("Unknown peak location scheme:", peaks) )
  # abort if peak matching scheme unknown
  if (! peak.matching %in% peak.matching.algo)
    stop ( paste ("Unknown peak matching scheme:", peak.matching) )
  

  # set spectrum range; ignore matrix signal for low energy spectra
  if (debug) print ("Initializing M/Z limits ...", quote=FALSE)
  s.e <- spectra.all[,energy]
  s.m <- spectra.all[,eam]
  mz.limits <- if (entire.spectrum==TRUE) m.z.all else m.z
  for (m in eams) 
    for (l in limits) 
      for (e in energies)
        spectra.all [ s.m==m & s.e==e, l ] <- mz.limits[m,l,e]

  # compute quality for spectrum and set "selected";
  # quality assessment is based on low energy scan;
  # ignore matrix signal while computing quality;
  # include area (= ion current) computation for normalization
  if ( quality.threshold != 0 || normalize != 'none' ) {
    if (debug) print ("Starting quality / normalization factor computation ...", quote=FALSE)
    for ( f in spectra.all [,'names'] ) {
      if (debug) print ( paste("  ...", f), quote=FALSE )
      data <- read.csv ( paste(data.directory,f,sep='/') )
      f.row <- spectra.all [ spectra.all[,'names']==f, ]
      if (quality.threshold != 0 && (f.row$energy == energies$low ||
                                     nlevels(spectra.all[,energy]) == 1)) { # single energy
        # spectrum quality (don't compute if already supplied by input,
        # unless lower than quality.threshold, in which case 'selected' could
        # be TRUE if there are sharp peaks)
        if (f.row$quality == default.value || f.row$quality < quality.threshold)
          # quality not specified, or quality < threshold (reevaluates selected)
          q <- areachange (data, low.Da.qfactor * f.row$low.Da, f.row$high.Da,
                           quality.threshold)
        else q <- list (area.change=f.row$quality, selected=TRUE)
        # use low energy quality/selected for all energies
        columns <- setdiff ( name.components, c(date,energy) )
        f.index <- eq.rows ( spectra.all, f.row, columns )
        spectra.all [ f.index, 'quality' ] <- q$area.change
        spectra.all [ f.index, 'selected' ] <- q$selected
      }
      # normalization parameters
      # (only those required for current normalization scheme are computed)
      p <- norm.parameters (data, f.row$low.Da, f.row$high.Da, normalize, stats)
      spectra.all [ spectra.all[,'names']==f, 'area' ] <- p$area
      spectra.all [ spectra.all[,'names']==f, 'min' ] <- p$min
      spectra.all [ spectra.all[,'names']==f, 'max' ] <- p$max
      spectra.all [ spectra.all[,'names']==f, 'avg' ] <- p$mean
    }
  }

  # retain only selected spectra
  if (debug) print ("Discarding unselected spectra ...", quote=FALSE)
  spectra.discard <- spectra.all [ spectra.all[,'selected']==FALSE, ]
  spectra.all <- spectra.all [ spectra.all[,'selected']==TRUE, ]

  
  # compute normalization factors
  # (grouped by chip x eam x energy x fraction)
  if (debug) print ("Computing final normalization factors ...", quote=FALSE)
  if ( normalize == 'tan' || normalize == 'tin' ) {
    property <- if (normalize == 'tan') 'area' else 'avg'
    group.avg <- by (spectra.all[,property], spectra.all[,c(chip,eam,energy,fraction)], mean)
    for ( c in levels(spectra.all[,chip]) )
      for ( m in levels(spectra.all[,eam]) )
        for ( e in levels(spectra.all[,energy]) )
          for ( f in levels(spectra.all[,fraction]) )
            spectra.all [ spectra.all[,chip]==c &
                          spectra.all[,eam]==m &
                          spectra.all[,energy]==e &
                          spectra.all[,fraction]==f , 'norm.factor' ] <- group.avg[c, m, e, f]
    # norm.factor now contains average area/intensity for each group;
    # divide by corresponding area/intensity to get normalization factor
    spectra.all [,'norm.factor'] <- spectra.all[,'norm.factor'] / spectra.all[,property]
  } else if ( normalize == '01' )
    spectra.all [,'norm.factor'] <- 1 / ( spectra.all[,'max'] - spectra.all[,'min'] )
  else if ( normalize != 'none' )
    stop ("Unknown normalization scheme escaped error check!")

  # compute only (pre-normalization) stats and normalization factors
  # (no peak detection or table assembly)
  if (stats.only) 
    return (invisible ( list (output=NULL, input=spectra.all, discard=spectra.discard) ))

  # run peak detection for all selected spectra
  if (debug) print ("Starting peak detection ...", quote=FALSE)
  peaks.all <- NULL
  for ( f in spectra.all [,'names'] ) {
    if (debug) print ( paste("  ...", f), quote=FALSE )
    data <- read.csv ( paste(data.directory,f,sep='/') )
    f.row <- spectra.all [ spectra.all[,'names']==f, ]
    # normalize spectrum and run peak detector
    data [,2] <- normalize (data[,2], f.row, normalize)
    if ( peaks == 'detect' ) {
      if (peaks.segmented)
        peaks.1 <- peaks.seg (data, low.Da=f.row$low.Da, high.Da=f.row$high.Da, ...)
      else
        peaks.1 <- peaks (data, low.Da=f.row$low.Da, high.Da=f.row$high.Da, ...)
      peaks.2 <- peaks.locate (peaks.1)
      # peaks.2 is [m.z, normalized intensity, thresholded peaks, located peaks]
      # see peaks() and peaks.locate() for details
      if (p2n.filter) {
        ix <- data[,1] >= f.row$low.Da & data[,1] <= f.row$high.Da
        p2n.noise <- ( p2n.factor * noise(data[,2],factor=1)[,'noise.envelope'] )[ix]
        peaks.2 <- peaks.2 [ peaks.2[,2] > p2n.noise, ]
      }
      peaks.list <- peaks.2 [ peaks.2[,4] != 0, c(1,4) ]
    } else if ( peaks == 'input' ) {
      # list of m/z values for "peaks" supplied in input.peaks
      mz.peaks <- sort (input.peaks)
      intensities <- approx (data[,1], data[,2], mz.peaks)$y # data is normalized
      peaks.list <- cbind (mz.peaks, intensities)
    } else if ( peaks == 'random' ) {
      # generate random peaks --
      #  select random.npeaks m.z values ONCE for each eam x energy combination
      # set fill.na to TRUE so that intensity values at these m.z values
      # are filled in for all spectra in the next stage
      if ( is.null(peaks.all) ) {
        # first time around -- initialize flag array to track which
        # [chip,eam,energy] have been processed
        mz.selected <- array ( rep (FALSE ,length(chips)*length(eams)*length(energies)),
                               dim = c(length(chips),length(eams),length(energies)),
                               dimnames = list (chips, eams, energies) )
        # book-keeping
        peak.matching <- 'window'  # EM matching may fail for identical peaks across samples
        fill.na <- TRUE
        if (! is.null (random.seed) )
          # if random.seed==NULL, don't set seed; uses system time to seed randnum generation
          set.seed (random.seed)
      }
      if ( mz.selected [f.row$chip, f.row$eam, f.row$energy] == FALSE ) {
        mz.selected [f.row$chip, f.row$eam, f.row$energy] <- TRUE
        d <- data [ data[,1]>=f.row$low.Da & data[,1]<=f.row$high.Da, ]
        peaks.list <- d [ sort (sample (1:dim(d)[1],random.npeaks)), ]
      } else { peaks.list <- NULL }
    } else stop ("Unknown peak location scheme escaped error check!")

    peaks.all <- c ( peaks.all, list ( list (name=f, peaks=peaks.list) ) )
    if (stats && peaks != 'random') {
      # when using peaks=='random' this info is not available for all spectra
      spectra.all [ spectra.all[,'names']==f, 'n.peaks' ] <- dim(peaks.list)[1]
      spectra.all [ spectra.all[,'names']==f, 'avg.peaks' ] <- mean (peaks.list[,2])
    }
  }


  # assemble table of peaks for all samples
  # one table for each chip x eam x energy x fraction combination
  if (debug) print ("Assembling table of peaks ...", quote=FALSE)
  data.final <- NULL
  for ( c in levels(spectra.all[,chip]) )
    for ( m in levels(spectra.all[,eam]) )
      for ( e in levels (spectra.all[,energy]) )
        for ( f in levels(spectra.all[,fraction]) ) {
          if (debug) print ( paste("  ... ", c, " x ", m, " x ", e, " x ", f, sep=""), quote=FALSE )
          spectra <- spectra.all [ spectra.all[,chip]==c & spectra.all[,eam]==m &
                                   spectra.all[,energy]==e & spectra.all[,fraction]==f, ]
          samples.current <-  spectra [,'names' ]
          # get peaks for samples.current
          peaks.current <- NULL
          selection <- ( lapply (peaks.all, function (p) {p$name}) ) %in% samples.current
          for ( i in 1:length(selection) )
            if (selection[i]) peaks.current <- c ( peaks.current, list (peaks.all[[i]]) )

          n.samples <- length (peaks.current)
          if (n.samples == 0) next   # no samples to process

          mz.current <- lapply ( peaks.current, function(x) { x[['peaks']][,1] } )
          intensity.current <- lapply ( peaks.current, function(x) { x[['peaks']][,2] } )
          maxpeaks.each <- c (lapply(mz.current,length), recursive=TRUE)
          maxpeaks <- max ( maxpeaks.each )
          mz.array <- rep ( NA, maxpeaks*n.samples )
          dim (mz.array) <- c ( maxpeaks, n.samples )
          colnames (mz.array) <- samples.current
          for (i in 1:n.samples) {
            sample <- mz.current[[i]]
            if (! is.null(sample) )
              # sample can be NULL when peaks == 'random'
              mz.array [1:length(sample),i] <- sample
          }


          final.current <- NULL
          if (debug) print ("  ..... determining common peaks for all spectra ...", quote=FALSE)
          if (peaks != 'detect') {
            # no peak matching needed -- "peaks" are given as input
            for (i in 1:maxpeaks) {
              center <- mz.array [i,1]   # peaks are same for all samples; pick the first
              peak.current <- c( lapply ( 1:n.samples,
                                          function (j) { intensity.current[[j]][i] } ),
                                 recursive=TRUE ) 
              final.current <- rbind ( final.current, c(center, peak.current) )
            }
          } else if (peak.matching == 'window') {
            # window based peak matching
            if (debug) print ("  ........ window-based peak matching ...", quote=FALSE)
            row.index <- rep (1, n.samples)
            while ( min (row.index > maxpeaks.each) == 0 ) {
              # row.index maintains the "frontier" of peaks currently being processed
              # processing terminates when this frontier is completely beyond the last peak
              col.index <- col ( matrix (row.index, ncol=length(row.index)) )
              frontier <- c( lapply ( col.index,
                                      function (j) { if (row.index[j] > maxpeaks.each[j]) NA
                                                     else {
                                                       i <- row.index[j]
                                                       mz.array[i,j]
                                                     }
                                                   } ),
                             recursive=TRUE )
              # assemble current peak 
              # same peak definition:
              # . select m/z values that lie within 2*mz.precision of minimum
              # . in this range, same peak == mean +/- sd.factor * sd
              # . peaks in min + 2*mz.precision, but outside mean +/- 3*sd 
              #   are different peaks
              dev.factor <- 3
              mz.low <- min (frontier, na.rm=TRUE)
              current.selection <- frontier < mz.low * (1 + 2*mz.precision)
              current.selection [ is.na(current.selection) ] <- FALSE
              
              subselection <- current.selection
              repeat {
                if (mz.center == 'median') {
                  center <- median ( frontier[subselection] )
                  dev <- mad ( frontier[subselection] )
                } else {
                  if (mz.center != 'mean')
                    warning ("Unknown mz.center function; using mean instead.")
                  center <- mean ( frontier[subselection] )
                  dev <- sd ( frontier[subselection] )
                }
                if ( is.na(dev) || dev == 0 )
                  # when frontier has only one value, or all frontier values are identical,
                  # set dev to a small "epsilon" to avoid problems with float equality testing
                  dev <- 1e-6
                
                subselection <- current.selection == TRUE &
                                frontier >= (center - dev.factor*dev) &
                                frontier <= (center + dev.factor*dev)
                if ( max (frontier[subselection] == mz.low) > 0 ) {
                  # mz.low included -- continue as usual
                  current.selection <- subselection
                  break
                } else {
                  # mz.low not included; process peaks occuring before peak centered at 'center'
                  subselection <- current.selection == TRUE &
                                  frontier < (center - dev.factor*dev)
                }
              }
            
              peak.current <- c( lapply ( col.index,
                                          function (j) { if (row.index[j] > maxpeaks.each[j]) NA
                                                         else {
                                                           i <- row.index[j]
                                                           intensity.current[[j]][i]
                                                         }
                                                       } ),
                                 recursive=TRUE ) 
              peak.current [ current.selection==FALSE ] <- NA
              final.current <- rbind ( final.current, c(center, peak.current) )
              # increment frontier
              row.index [current.selection] <- row.index [current.selection] + 1
            }
          } else {
            if (peak.matching != 'em') warning ("Unknown peak.matching value; using em instead.")
            # EM based peak matching
            if (debug) print ("  ........ mixture model-based (EM) peak matching ...", quote=FALSE)
            # constants
            model.type <- 'V'
            iteration.max <- 10
            
            mz.flat <- unlist (as.vector (mz.array))  # flatten mz.array for input to EM
            mz.flat.sorted <- sort ( as.vector (mz.flat [ !is.na(mz.flat) ]), index=TRUE )
            mz.list <- mz.flat.sorted$x
            mz.index <- mz.flat.sorted$ix
            mz.len <- length (mz.list)
            mz.perturb <- rep (0, mz.len)
            if (perturb) {
              mz.unique <- unique (mz.list)
              mz.mindiff <- mz.unique[-1] - mz.unique[1:(length(mz.unique)-1)]
              mz.perturb <- rnorm ( mz.len, mean=0, sd=mz.mindiff/perturb.factor )
            }

            # explore nclust in range [nclust.minfactor -- nclust.maxfactor] * maxpeaks
            nclust.min <- round ( nclust.minfactor * maxpeaks )
            nclust.max <- round ( nclust.maxfactor * maxpeaks )
            bic.max <- NA
            nclust.best <- 0
            iteration <- 0
            repeat {
              iteration <- iteration + 1
              for (nclust in nclust.min:nclust.max) {
                # using starting clusters based on sorted input,
                # run EM and pick nclust with highest bic index
                z <- unmap (rep (1:nclust, each=mz.len/nclust, length.out=mz.len))
                em <- me (model.type, mz.list+mz.perturb, z)
                if (! is.null(attr(em,"warn")) ) {
                  if (debug) print ( paste ("  .......... nclust = ", nclust, "; ", attr(em,'warn'),
                                            "; continuing ...", sep=''), quote=FALSE )
                  next
                }
                bic <- bic (em$modelName, em$loglik, em$n, em$d, em$G)
                if (debug) print ( paste ("  .......... nclust = ", nclust, "; bic = ", bic, sep=''),
                                   quote=FALSE)
                if (nclust.best == 0 || bic > bic.max) {
                  bic.max <- bic
                  nclust.best <- nclust
                }
              }
              if (nclust.best!=0 && nclust.best!=nclust.min && nclust.best!=nclust.max) break
              else {
                if (nclust.best==0 || nclust.best== nclust.min) {
                  # EM failed for all nclust, or max BIC is at nclust.min -- try smaller nclust values
                  if ( iteration > iteration.max ) {
                    # we've tried long enough
                    if (debug) print ("  ******** can't find reasonable nclust value ... skipping",
                                      quote=FALSE)
                    warning ("Can't find nclust.best ... skipping")
                    break
                  }
                  nclust.max <- nclust.min + 1   # overlap to avoid unnecessary iterations
                  nclust.min <- round (nclust.minfactor * nclust.min)
                } else { # nclust.best == nclust.max
                  nclust.min <- nclust.max - 1   # overlap to avoid unnecessary iterations
                  nclust.max <- round (nclust.maxfactor * nclust.max)
                }
              }
            }
            
            if (debug) print (paste ("  ........ best nclust = ", nclust.best,
                                     ";  max bic = ", bic.max, sep=''), quote=FALSE)
            if (nclust.best==0) next    # EM didn't work for this set of conditions ... skip to next
            z.final <- unmap (rep (1:nclust.best, each=mz.len/nclust.best, length.out=mz.len))
            em.final <- me (model.type, mz.list+mz.perturb, z.final)
    
            # re-assmemble new mz.array based on EM estimated peak matching
            # mz.array.new corresponds 1-1 with mz.array and hence to intensities in intensity.current
            input.z <- map (em.final$z)
            input.assign <- input.z [ sort(mz.index,index=TRUE)$ix ]
            input.mz.new <- em.final$mu [ input.assign ]
            mz.array.new <- reassemble ( as.vector(input.mz.new), mz.array )
            colnames (mz.array.new) <- colnames (mz.array)

            em.peaks <- sort(em.final$mu)
            final.current <- cbind (m.z=em.peaks)
            for (s in 1:dim(mz.array.new)[2]) {
              # fill in appropriate final.current column for each sample;
              # multiple peaks in a sample could be mapped to a single peak in the
              # final table based on EM peak matching -- intensities for these
              # peaks are combined based on combine.duplicate.peaks
              s.peaks <- mz.array.new[,s]
              s.intensities <- intensity.current[[s]]
              dups <- unique ( s.peaks [ duplicated(s.peaks) ] )
              for (d in dups) {
                s.d.index <- s.peaks == d
                s.intensities [s.d.index] <- combine.duplicate.peaks (s.intensities[s.d.index],
                                                                      na.rm=TRUE)
              }
              s.peaks.index <- match (em.peaks, s.peaks)
              final.current <- cbind (final.current, s.intensities[s.peaks.index])
            }

            em.results <- list (em=em.final, allpeaks.em=mz.array.new)
          }

          
          if (fill.na) {
            if (debug) print ("  ..... filling in intensity values ...", quote=FALSE)
            final.current <- fill.NAs (final.current, samples.current, data.directory,
                                       spectra, normalize)
          }

          colnames (final.current) <- c ('m.z', samples.current)

          new <- prettyNum (final.current [, 'm.z'], digits=5)
          new.colnames <- c ('m.z')
          # combine replicates
          # proc.replicates == average  =>  take average of all replicates
          # proc.replicates == best     =>  pick replicate with best quality
          if (debug) print ("  ..... combining replicates ...", quote=FALSE)
          replicate.cols <- setdiff ( name.components, c(date,replicate) )
          for ( r in by (spectra[,'names'], spectra[,replicate.cols],
                         function (x) { x[1] }) ) {
            if ( is.na (r) || is.null (r) ) next   # ignore invalid 'by' combinations
            if (debug) print ( paste("  ....... for", r), quote=FALSE )
            f.row <- spectra [ spectra[,'names']==r, ]
            index <- eq.rows ( spectra, f.row, replicate.cols )
            samples <- spectra [ index, ]
            samples.colname <- paste ( lapply (f.row[replicate.cols],toString),
                                       sep='-', collapse='-' )
            if ( proc.replicates == 'best' ) {
              # break ties by picking the first one in the list
              samples.names <- samples [ samples[,'quality'] == max (samples[,'quality']),
                                         'names' ][1]
            } else {
              if ( proc.replicates != 'average' )
                warning ("Unknown proc.replicates value; using average instead.")
              samples.names <- samples [, 'names']
            }
            samples.peaks <- final.current [, samples.names]
            if ( length(samples.names) > 1 )
              peaks <- unlist ( lapply (1:dim(samples.peaks)[1],
                                        function (i) { mean (samples.peaks[i,]) }) )
            else peaks <- samples.peaks
            new <- cbind (new, peaks)
            new.colnames <- c (new.colnames, samples.colname)
          }
          colnames (new) <- new.colnames

          # the above code deals with replicates; 
          # different energy levels and fraction are handled by the
          # chip x eam x energy x fraction outer loop
      
          data.final <- c ( data.final, list ( list (chip=c, eam=m, energy=e, fraction=f,
                                                     peaktable=new, allpeaks=mz.array,
                                                     em.results=if (exists('em.results')) em.results
                                                                else NULL) ) )

          if (checkpoint) {
            if (! file.exists(checkpoint.dir) ) dir.create (checkpoint.dir)
            intermediate <- list (output=data.final, input=spectra.all, discard=spectra.discard)
            run (filename, data.directory, output.dir=checkpoint.dir,
                 filenames.prefix=paste('pid',Sys.getpid(),'-',sep=''), out=intermediate)
          }
        }
  
  # return [[ [[(final peaktable, actual peaks) for each chip x eam x energy x fraction combination]],
  #           spectra.all, spectra.discard ]]
  invisible ( list (output=data.final, input=spectra.all, discard=spectra.discard) )
}



#
# Functions for running the pipeline and writing out results
#  (previously in util.r; moved here to avoid cross-sourcing)
#
finalize.qc.data <- function (table, samples.map.file) {
  if ( dim(table)[1] == 0 ) {
    # empty table -- hack two more new columns and return
    table.final <- data.frame (cbind (table, table[,c(1,2)]))
    colnames (table.final) <- c (colnames(table), 'data.actual', 'class')
    return ( invisible (table.final) )
  }

  samples.map <- read.csv (samples.map.file, header=FALSE)
  colnames (samples.map) <- c ('class', 'sample')
  
  date.actual <- unlist (lapply (table[,'date'],
                                 function (x) {
                                   month <- substr (x, 1, 2)
                                   day <- substr (x, 3, 4)
                                   year <- substr (x, 5, 6)
                                   paste (month, day, year, sep='/')
                                 }))
  table.temp <- data.frame (cbind (table, date.actual))
  
  table.final <- merge (table.temp, samples.map, by='sample', all.x=TRUE)
  invisible (table.final)
}


run <- function (file, dir, samples.map.file=NULL,
                 output.dir='.', filenames.prefix=NULL, out=NULL, ...) {
  # runs the pipeline using spectra listed in 'file', located in 'dir'
  # and saves results to files
  # (if out is given as input, the data in out is just written out to files
  #  without invoking the pipeline)
  if (is.null(out)) out <- pipeline (file, dir, ...)

  prefix.1 <- paste (output.dir, '/', filenames.prefix, sep='')
  if (! is.null(out$output) ) {
    for ( p in 1:length(out$output) ) {
      this <- out$output[[p]]
      prefix.2 <- paste (this$chip, this$eam, this$energy, this$fraction, sep="x")
      prefix <- paste (prefix.1, prefix.2, sep='')
      export ( this$peaktable, paste (prefix, '.gct', sep="") )
      write.table ( this$allpeaks, paste (prefix, '-mz-array', '.csv', sep=""),
                    quote=FALSE, sep=',', row.names=FALSE)
      # EM results, if present
      if (! is.null(this$em.results) ) {
        write.table ( this$em.results$allpeaks.em, paste (prefix, '-mz-array-em', '.csv', sep=""),
                      quote=FALSE, sep=',', row.names=FALSE)
        em.peaks <- cbind (mean=this$em.results$em$mu, var=this$em.results$em$sigma,
                           prob=this$em.results$em$pro)
        write.table ( em.peaks, paste (prefix, '-em-peaks', '.csv', sep=""),
                      quote=FALSE, sep=',', row.names=FALSE)
      }
    }
  }
  if (! is.null(samples.map.file) ) {
    out.input <- finalize.qc.data (out$input, samples.map.file)
    out.discard <- finalize.qc.data (out$discard, samples.map.file)
  } else {
    out.input <- out$input
    out.discard <- out$discard
  }

  
  write.table ( out.input, paste (prefix.1, file, '-select.csv', sep=""),
                quote=FALSE, sep=',', row.names=FALSE)
  write.table ( out.discard, paste (prefix.1, file, '-discard.csv', sep=""),
                quote=FALSE, sep=',', row.names=FALSE)
}


prun <- function (file, dir, code.pre=NULL, code.post=NULL, run.file.prefix='run',
                  run.args=NULL) {
  # splits file into parts based on condition and invokes 'run' for each
  # condition => LSF-based parallelism

  
  ## dissect names and create table
  names <- sort (scan ( file, what="string", sep="\n" , quiet = TRUE))
  # remove file extension (careful, there might be other .'s in the name)
  split.on.dot <- t ( data.frame (strsplit(names,'\\.')) )
  names.noext <-
    unlist ( lapply (1:dim(split.on.dot)[1],
                     function (i) { paste (lapply (split.on.dot[i,1:(dim(split.on.dot)[2]-1)],
                                                   toString),
                                           sep='.', collapse='.') }) )
  # split name at seperator
  names.split <- strsplit (names.noext, name.sep)
  spectra.all <- t ( data.frame(names.split, row.names=name.components) )
  spectra.all <- data.frame (I(names), spectra.all)
  

  ## spin off separate process for each condition
  for ( c in levels(spectra.all[,chip]) )
    for ( m in levels(spectra.all[,eam]) )
      for ( e in levels(spectra.all[,energy]) )
        for ( f in levels(spectra.all[,fraction]) ) {
          names.subset <- spectra.all [ spectra.all[,chip]==c &
                                        spectra.all[,eam]==m &
                                        spectra.all[,energy]==e &
                                        spectra.all[,fraction]==f , 'names' ]
          if ( length(names.subset) == 0 ) next
          condition <- paste (c, m, e, f, sep='x')
          # new files list
          subset.file <- paste (file, condition, Sys.getpid(), sep='-')
          write (names.subset, subset.file, ncolumns=1)
          # new run script
          run.file <- paste (run.file.prefix, '-', condition, '-', Sys.getpid(), '.r', sep='')
          if (! is.null(code.pre) ) {
            file.copy (code.pre, run.file)
          } else {
            code.dir <- Sys.getenv ('PROTEOMICS_CODEBASE')
            if ( code.dir == "" ) stop ('PROTEOMICS_CODEBASE not set in environment.')
            source.txt <- paste ('source ("',code.dir,'/','proteomics.r','")',sep='')
            write (source.txt, run.file)
          }
          args <- paste ("'", subset.file, "', '", dir, "'", sep='')
          if (! is.null(run.args) ) args <- paste (args, ',', run.args, sep='')
          write ( paste ('run (', args, ')'), run.file, append=TRUE )
          if (! is.null(code.post) ) file.append (run.file, code.post)
          # start new job
          cmd <- paste ('bsub R CMD BATCH --vanilla', run.file)
          system (cmd)
        }
}




#
# Functions for creating and writing raw data.
# Every sampling point in a spectrum is treated as a "peak".
# All spectra are interpolated to the same set of m/z values.
#
export <- function (data, file, ignorefirstcolumn=TRUE, format='gct',
                    Name=data[,1], Description=data[,1], na.rm=TRUE) {
  # name and/or description, if not provided, defaults to the first column of data
  # by default, data[,1] is ignored, unless ignorefirstcolumn==FALSE
  if (ignorefirstcolumn) {
    cols <- dim(data)[2]
    data.out <- cbind (Name, Description, data[,2:cols])
    colnames (data.out) <- c ( 'Name', 'Description', colnames(data)[2:cols] )
  } else {
    data.out <- cbind (Name, Description, data)
    colnames (data.out) <- c ( 'Name', 'Description', colnames(data) )
  }
  data.out <- data.frame (data.out)
  if (na.rm) {
    # remove rows that contain any NAs (usually present at start/end due
    # to insufficient data for extrapolation)
    index.table <- apply (data.out, MARGIN=2, FUN=is.na)
    index <- unlist (lapply (1:nrow(index.table),
                             function (i) { ! any (index.table[i,]) }))
    data.out <- data.out [ index, ]
  }
  
  if (format == 'csv')
    write.table (data.out, file, quote=FALSE, sep=',', row.names=FALSE)
  else if (format == 'gct') {
    # gct files always require "Name" & "Description", in addition to header
    version <- '#1.2'
    size <- dim (data.out)
    size[2] <- size[2] - 2  # adjust for "Name" & "Description"
    write.table (version, file, quote=FALSE, sep='\t', row.names=FALSE, col.names=FALSE)
    write.table (rbind(size), file, append=TRUE, quote=FALSE, sep='\t',
                 row.names=FALSE, col.names=FALSE)
    write.table (data.out, file, append=TRUE, quote=FALSE, sep='\t', row.names=FALSE)
  } else stop ( paste ("Unknown output format", format) )
}



rawdata <- function (data.directory, prefix.file.out,
                     stats.file,              # stats table output by pipeline(...)
                     stats.components=c('names', name.components, 'quality', 'selected',
                                        'low.Da', 'high.Da', 'area', 'min', 'max', 'avg',
                                        'norm.factor'),
                     selected.only=TRUE,
                     normalize='tin',         # normalization type [tin|tan|01|none]
                     proc.replicates='best',  # replicate processing [best|average|none]
                     debug=TRUE, max.samples=512) {
  
  # reads spectra in data.directory and creates tables for each condition;
  # the first spectrum supplies m/z values and the other spectra are
  # interpolated to derive intesity values at this set of m/z values;
  # normalization and quality information are derived from stats.file;
  # stats.file must be produced by pipeline(...) with stats=TRUE;
  # NOTE: even though possible, this functionality has not been folded into
  #       pipeline(...) since it would entail retaining all raw spectra in
  #       memory

  if (! normalize %in% normalizations)
    stop ( paste ("Unknown normalization scheme:", normalize) )

  spectra.all <- read.csv (stats.file, comment.char='')
  # check to see if spectra.all has all components needed
  if ( !all ( stats.components %in% colnames(spectra.all) ) )
    stop ("Missing components in stats.file -- can't proceed.")
  if (selected.only) spectra.all <- spectra.all [ spectra.all[,'selected'], ]
  spectra.all [ ,'fraction'] <- as.factor (spectra.all [,'fraction'])
  spectra.all [ ,'names'] <- unlist (lapply (spectra.all [,'names'], toString))

  
  # recompute normalization factors (old factors may not be valid)
  # (following code copied from pipeline(...)
  if (debug) print ("Recomputing normalization factors ...", quote=FALSE)
  if ( normalize == 'tan' || normalize == 'tin' ) {
    property <- if (normalize == 'tan') 'area' else 'avg'
    group.avg <- by (spectra.all[,property], spectra.all[,c(chip,eam,energy,fraction)], mean)
    for ( c in levels(spectra.all[,chip]) )
      for ( m in levels(spectra.all[,eam]) )
        for ( e in levels(spectra.all[,energy]) )
          for ( f in levels(spectra.all[,fraction]) )
            spectra.all [ spectra.all[,chip]==c &
                          spectra.all[,eam]==m &
                          spectra.all[,energy]==e &
                          spectra.all[,fraction]==f , 'norm.factor' ] <- group.avg[c, m, e, f]
    # norm.factor now contains average area/intensity for each group;
    # divide by corresponding area/intensity to get normalization factor
    spectra.all [,'norm.factor'] <- spectra.all[,'norm.factor'] / spectra.all[,property]
  } else if ( normalize == '01' )
    spectra.all [,'norm.factor'] <- 1 / ( spectra.all[,'max'] - spectra.all[,'min'] )
  else if ( normalize != 'none' )
    stop ("Unknown normalization scheme escaped error check!")


  # assemble table of raw spectra values for all samples
  # one table for each chip x eam x energy x fraction combination
  if (debug) print ("Assembling raw data tables ...", quote=FALSE)
  for ( c in levels(spectra.all[,chip]) )
    for ( m in levels(spectra.all[,eam]) )
      for ( e in levels (spectra.all[,energy]) )
        for ( f in levels(spectra.all[,fraction]) ) {
          combo <- paste (c, m, e, f, sep="x")
          if (debug) print ( paste("  ... ", combo, sep=""), quote=FALSE )
          spectra <- spectra.all [ spectra.all[,chip]==c & spectra.all[,eam]==m &
                                   spectra.all[,energy]==e & spectra.all[,fraction]==f, ]
	  if (nrow(spectra) == 0) next    # no samples to process
          low.Da <- max (spectra [,'low.Da'])
          high.Da <- min (spectra [,'high.Da'])
          # derive list of files to process based on proc.replicates
          if ( proc.replicates=='best' || proc.replicates=='average' ) {
            # replicate processing needed
            replicate.cols <- setdiff ( name.components, c(date,replicate) )
            samples.current <- by (spectra[,'names'], spectra[,replicate.cols],
                                   function (x) { toString(x[1]) })
            samples.current <- samples.current [ !is.na (samples.current) &     # ignore invalid
                                                 !is.null (samples.current) ]   # 'by' combinations
          } else {
            # keep all replicates: proc.replicates == 'none' or invalid option
            if ( proc.replicates != 'none' )
                warning ("Unknown proc.replicates value; keeping all replicates.")
            replicate.cols <- setdiff ( name.components, c(date) )
            samples.current <-  spectra [,'names' ]
          }
          
          # initialization
          file.out <- paste (prefix.file.out, combo, sep='')
          n <- 0
          part.n <- 1
          mz.list <- read.csv ( paste(data.directory,'/',samples.current[1],sep='') ) [,1]
          mz.list <- mz.list [ mz.list >= low.Da & mz.list <= high.Da ]
          array.size <- min ( length(samples.current), max.samples ) + 1
          data <- array ( dim = c(length(mz.list), array.size) )

          # read in, normalize and interpolate each spectrum to get values at m/z's
          # specified in mz.list
          for (r in samples.current) {
            if (debug) print ( paste ('  .....', r), quote=FALSE )
            n <- n + 1
            if (n == 1) {
              data [,] <- NA
              data [,1] <- prettyNum (mz.list, digits=5)
              col.names <- c ('m.z');
            }
            
            f.row <- spectra [ spectra[,'names']==r, ]
            index <- eq.rows ( spectra, f.row, replicate.cols )
            samples <- spectra [ index, ]

            if ( proc.replicates == 'best' )
              # break ties by picking the first one in the list
              samples <- samples [ samples[,'quality'] == max (samples[,'quality']), ][1,]

            spectrum.new <- rep (0, length(mz.list))
            for ( s in 1:nrow(samples) ) {
              file.name <- paste (data.directory, '/', samples[s,'names'], sep='')
              spectrum <- read.csv (file.name, comment.char='')
              spectrum[,2] <- normalize (spectrum[,2], samples[s,], normalize)
              spectrum.new <- spectrum.new + approx (spectrum[,1], spectrum[,2], mz.list)$y
            }
            spectrum.new <- spectrum.new / nrow(samples)   # average out replicates
                                                           # if proc.replicates!='average', then
                                                           # nrow(samples) will be 1
            data [ , n+1] <- spectrum.new
            col.name <- paste ( lapply (f.row[replicate.cols],toString),
                                sep='-', collapse='-' ) 
            col.names <- c (col.names, col.name)
            
            if (n >= max.samples) {
              n <- 0
              colnames (data) <- col.names
              export ( data, paste (file.out, '-part', part.n, '.gct', sep="") )
              part.n <- part.n + 1
            }
          }

          if (part.n == 1) file.out.final <- paste (file.out, '.gct', sep="")
          else  file.out.final <-  paste (file.out, '-part', part.n, '.gct', sep="")
          if (n > 0) {
            colnames (data) <- col.names
            export (data [,1:(n+1)], file.out.final)
          }
        }
}
