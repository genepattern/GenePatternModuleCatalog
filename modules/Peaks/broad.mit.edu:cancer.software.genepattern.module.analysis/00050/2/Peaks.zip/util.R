
# $Id: util.r 4878 2004-12-20 21:08:30Z jgould $



NAs.count <- function (data) {
  # counts number of NAs in each row
  # returns a vector of length = number of rows in data
  unlist ( lapply (1:dim(data)[1], function (x) { sum (is.na (data[x,])) }) )
}


no.na.cols <- function (data) {
  # return columns with no missing values
  unlist ( lapply (1:dim(data)[2], function (x) { if ( sum(is.na(data[,x])) == 0 ) x }) )
}
  

write.gct <- function (data, file, ...) {
  # write out gct file
  version <- '#1.2'
  size <- dim (data)
  size[2] <- size[2] - 2  # adjust for "Name" & "Description"
  write.table (version, file, quote=FALSE, sep='\t', row.names=FALSE, col.names=FALSE)
  write.table (rbind(size), file, append=TRUE, quote=FALSE, sep='\t',
               row.names=FALSE, col.names=FALSE, ...)
  write.table (data, file, append=TRUE, quote=FALSE, sep='\t', row.names=FALSE, ...)
}


write.cls <- function (cls, file) {
  # write out cls file
  classes <- unique (cls)

  line1 <- c ( length(cls), length(classes), 1 )
  line2 <- paste ( '#',
                   paste (classes, collapse=" ") )

  for ( i in 1:length(classes) )
    cls [ cls==classes[i] ] <- i-1

  write.table (rbind(line1), file, quote=FALSE, row.names=FALSE, col.names=FALSE)
  write.table (line2, file, append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)
  write.table (cls, file, eol=' ', append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)  # single line
  write.table ('', file, append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)            # end above line 
}


read.gct <- function (file, ...) {
  # reads a data file in gct format
  data <- read.table (file, header=TRUE, sep='\t', skip=2,
                      comment.char='', ...)
  invisible (data)
}


read.res <- function (file, ...) {
  # read a data file in res format, and creates a data frame after
  # stripping the A/P call columns
  col.names <- scan (file=file, what=list("string"), nmax=1, sep='\t')[[1]]
  n.cols <- length(col.names)
  if ( n.cols %% 2 == 0 ) {
    # res file with an extra \t at the end of each line
    # (usually from res files created within GeneCluster)
    table <- read.table (file, header=FALSE, sep='\t', skip=3) [, 1:n.cols]
    colnames (table) <- col.names
  } else {
    # res file with no extra \t at the end of each line
    col.names <- c (col.names, "") # scan skips the last empty field for A/P
    table <- read.table (file, header=FALSE, sep='\t', col.names=col.names, skip=3)
  }
    data <- table [, c(1,2,seq(3,ncol(table),2))]

  invisible (data)
}


read.cls <- function (file, ...) {
  # reads a cls file
  cls <- scan (file, skip=2, quiet=TRUE, ...)
  invisible (cls)
}


read.cls.mapped <- function (file, ...) {
  # reads a cls file, and maps the classes to names listed in the file
  stream <- file (file, open='r')
  line1 <- scan (stream, what=list(integer(0)), nmax=1, ...)
  names <- scan (stream, what=list('string'), nmax=1, ...)
  cls <- scan (stream, ...)
  close (stream)

  n.samples <- line1[[1]][1]
  n.classes <- line1[[1]][2]
  for (i in 0:(n.classes-1)) cls [ cls==i ] <- names[[1]][i+2]  # names[[1]] == '#'
  invisible (cls)
}


make.cls <- function (base.in, cls.row, gct.target, base.out, threshold=0,
                      sampleid.col=3, sep='\\.', target.suffix='-genes',
                      rewrite.in=TRUE, in.suffix='-peaks', keeponly.in=NULL) {
  # selects row identified by cls.row in the base.in.gct dataset, and
  # creates a corresponding gct/cls file pair with common samples (between
  # base.in.gct and gct.target);
  # writes out common samples in base.in.gct to base.out-in.suffix.gct
  # with the original base.in.cls appropriately re-written in
  # base.out-in.suffix.cls (if rewrite.in==TRUE, and no keeponly.in specified);
  # also subsets entire data to keep only those classes (in base.in.cls)
  # and corresponsing samples listed in keeponly.in
  
  data <- read.gct ( paste (base.in,'gct',sep='.') )
  cls.file <- paste (base.in, 'cls', sep='.')
  cls <- read.cls (cls.file)
  cls.line2 <- scan (cls.file, what='char', sep=' ', skip=1, nlines=1)
  classes.in <- cls.line2 [2:length(cls.line2)]

  n.samples <- dim(data)[2] - 2
  row.subset <- rep (TRUE, n.samples)
  if (! is.null(keeponly.in) ) {
    # subset condition specified
    if (! any(keeponly.in %in% classes.in) )
      stop ( paste ('Class(es)', paste (unlist(keeponly.in), collapse=','),
                    'not found in', cls.file) )
    row.subset <- rep (FALSE, n.samples)
    for (x in keeponly.in) {
      i <- match (x, classes.in) - 1
      if (is.na(i)) next
      row.subset [ cls==i ] <- TRUE
    }
  }
  row.subset <- c(FALSE, FALSE, row.subset) # exclude 'Name' & 'Description'
  row <- data [ data[,1] == cls.row, row.subset ]
  samples.in <- colnames (row)
  
  cls.row <- ifelse ( row > threshold, 'high', 'low' )

  target <- read.gct (gct.target)
  target.prefix <- target [, 1:2]
  target.data <- target [, 3:dim(target)[2]]
  samples.target <- colnames (target.data)

  common.index <- samples.in %in% samples.target
  common <- samples.in [common.index]
  cls.out <- cls.row [, common ]
  data.out <- cbind ( target.prefix, target.data [,common] )

  write.cls (cls.out, paste(base.out, target.suffix, '.cls', sep=''))
  write.gct (data.out, paste(base.out, target.suffix, '.gct', sep=''))

  if ( rewrite.in && is.null(keeponly.in) ) {
    cls.common <- cls [common.index]
    cls.in <- rep ( NA, length(cls.common) )
    for ( i in 1:length(classes.in) ) 
      cls.in [ cls.common == (i-1) ] <- classes.in[i]
    data.in <- data [, c (colnames(data)[1:2], common) ]

    write.cls (cls.in, paste(base.out, in.suffix, '.cls', sep=''))
    write.gct (data.in, paste(base.out, in.suffix, '.gct', sep=''))
  }
}


select.samples <- function (file.in, file.out, samples,
                            sampleid.col=3, sep='\\.') {
  # retains only samples included in 'samples' and writes out
  # subset to file.out
  data <- read.gct (file.in)
  size <- dim(data)[2]
  d <- data[,3:size]
  d.samples <- t ( data.frame (strsplit (colnames(d),sep)) )[,sampleid.col]
  d.subset <- d [, d.samples %in% samples]

  data.subset <- cbind ( data[,1:2], d.subset )
  write.gct (data.subset, file.out)
}


select.peaks <- function (in.gct, file.out, peaks) {
  # retains only peaks (== rows) listed in 'peaks' and
  # write out subset to file.out
  data <- read.gct (in.gct)
  data.subset <- data [ data[,1] %in% peaks, ]

  write.gct (data.subset, file.out)
}


permute.cls <- function (file, ...) {
  # generates a random permutation of the cls vector in file
  cls <- read.cls (file, ...)
  write.cls (sample (cls), file)
}


read.dataset <- function (file, read.cls=TRUE, name.prefix="MZ.") {
  # reads both gct and cls file, transposes gct file and
  # returns dataset and class vector
  # reading class vector is skipped if read.cls=FALSE
  
  d <- read.gct ( paste(file,'.gct',sep="") )
  d.t <- t ( d[, 3:dim(d)[2]] )
  names <- unlist ( lapply (d[,'Name'],
                            function (x) { paste (name.prefix, toString(x), sep="") }) )
  colnames (d.t) <- names

  if (read.cls) {
    c <- read.cls ( paste(file,'.cls',sep="") )
    c.t <- as.factor (c)
  } else c.t <- NULL

  invisible ( list (data=data.frame(d.t), class.vector=c.t) )
}


is.peak <- function (m.z, mz.values, tolerance) {
  mz.low <- m.z * (1 - tolerance)
  mz.high <- m.z * (1 + tolerance)
  peaks <- mz.values [ mz.values >= mz.low & mz.values <= mz.high ]
  if ( length(peaks)==0 ) peaks <- NA

  c (input=m.z, output=peaks)
}


is.peaks <- function (file.gct, m.z, tolerance=0.00125, names.sep='-') {
  # checks if file.gct has any peaks in the range
  # m.z +/- (tolerance * m.z)
  data <- read.gct (file.gct)
  names <- strsplit (data[,'Name'], names.sep)
  mz.values <- unlist ( lapply (1:length(names),
                                function (i) { as.numeric (names[[i]][1]) }) )

  result <- lapply (m.z, is.peak, mz.values, tolerance)
  result
}


feature.s2n <- function (feature, class.vector, class.estimate='median') {
  # computes signal-to-noise ratio for specified feature using the
  # class.vector based on class.estimate
  if ( length (classes <- unique(class.vector)) != 2 )
    stop ('S2N computation requires binary class vector.')
  
  # in one-vs-all comparisons -- class "other" must be f2 to get markers high in class of interest
  class.1 <- if ( "other" %in% classes ) class.vector != 'other' else class.vector == classes[1]
  f1 <- feature [ class.1 ]
  f2 <- feature [ !class.1 ]
  if ( length(f1) == 1 || length(f2) == 1 )
    stop ('S2N computation needs more than one example of each class.')

  if (class.estimate == "median") s2n <- ( median(f1) - median(f2) ) / ( sd(f1) + sd(f2) )
  else if (class.estimate == "mean") s2n <- ( mean(f1) - mean(f2) ) / ( sd(f1) + sd(f2) )
  else stop ("S2N class.estimate must be mean|median.")

  s2n
}


features.s2n.topN <- function (data, class.vector, n, two.sided=TRUE, ...) {
  # returns the top n features as ranked by S2N
  features <- colnames (data)

  if ( (n.classes <- length(unique(class.vector))) == 2 ) {
    # binary class vector
    s2n <- unlist ( lapply (features,
                            function (x) { feature.s2n (data[,x], class.vector, ...) }) )
    s2n.sorted <- sort (s2n, decreasing=TRUE, index.return=TRUE)

    if (two.sided) {
      len <- length (features)
      n1 <- as.integer(n/2)
      n2 <- n - n1
      selection <- c ( 1:n1, len:(len-n2+1) )
    } else selection <- 1:n

    features.selection <- features [ s2n.sorted$ix[selection] ]
    features.s2n <- s2n.sorted$x[selection]
  } else {
    # multiclass -- use one-vs-all
    cvec.1vAll <- classes.1vAll (class.vector)
    n.1vAll <- as.integer (n/n.classes)
    features.selection <- features.s2n <- NULL
    for (i in 1:n.classes) {
      s2n <- unlist ( lapply (features,
                              function (x) { feature.s2n (data[,x], cvec.1vAll[,i], ...) }) )
      s2n.sorted <- sort (s2n, decreasing=TRUE, index.return=TRUE)
      n1 <- min (n.1vAll, n - (i-1)*n.1vAll)
      features.selection <- c (features.selection, features [ s2n.sorted$ix[1:n1] ])
      features.s2n <- c (features.s2n, s2n.sorted$x[1:n1])
    }
  }

  list (s2n=features.s2n, selection=features.selection)
}


classes.1vAll <- function (class.vector) {
  # converts a multi-class class.vector into multiple one-vs-all class vectors
  class.vector <- unlist ( lapply (class.vector, toString) ) # convert factor -> string
  classes <- unique (class.vector)
  one.vs.all <- NULL
  for ( l in classes ) {
    class.vector.new <- class.vector
    class.vector.new [ class.vector != l ] <- 'other'
    one.vs.all <-
      if ( is.null(one.vs.all) )
        data.frame ( factor(class.vector.new,levels=c(classes,'other')) )
      else data.frame ( one.vs.all, factor(class.vector.new,levels=c(classes,'other')) )
  }

  colnames (one.vs.all) <-
    unlist (lapply (classes, function (x) { paste ('class',toString(x),sep='.') }))
  one.vs.all
}




#library(gregmisc)   # for combinations
run.tests <- function (data, vars, tests, data.file=FALSE, out.file=NULL,
                       class.var='class', classes=NULL, abbr=NULL,
                       pvalue.sig=0.05, selected.only=TRUE) {
  if (data.file) d <- read.csv (data, comment.char='')
  else d <- data

  
  d.c <- NULL
  if ( is.null(classes) ) {
    classes <- levels(d[,class.var])
    n.classes <- nlevels(d[,class.var])
  } else n.classes <- length (classes)

  
  # no abbreviations or wrong set of abbreviations
  # use class names as abbreviation
  if ( is.null(abbr) || length(abbr) != n.classes ) abbr <- classes

  
  for (c in classes) {
    index <- d[,class.var] == c
    if (selected.only) index <- index & d[,'selected']
    d.c <- c (d.c, list (d[index,]))
  }


  table <- NULL
  for (t in tests) 
    for (v in vars) {
      classes.pairs <- combinations (n.classes, 2, 1:n.classes)
      for ( x in 1:dim(classes.pairs)[1] ) {
        pair <- classes.pairs [x,]
        x.1 <- d.c[[pair[1]]][,v]
        x.2 <- d.c[[pair[2]]][,v]
        t.x <- t (x.1, x.2)

        comparison <- paste ( abbr[pair[1]], abbr[pair[2]], sep='-' )
        median.diff <- median (x.1, na.rm=TRUE) - median (x.2, na.rm=TRUE)
        mean.diff <- mean (x.1, na.rm=TRUE) - mean (x.2, na.rm=TRUE)
        t.results <- c (comparison, v, mean.diff, median.diff,
                        t.x$method, t.x$statistic, t.x$p.value)
        table <- rbind (table, t.results)
     }
    }

  colnames (table) <- c ('comparison', 'attribute', 'mean.diff', 'median.diff',
                         'method', 'statistic', 'p.value')
  table
}


  
check.bias <- function (data, vars, tests, data.file=FALSE, out.file=NULL,
                        class.var='class', classes=NULL, pvalue.sig=0.05,
                        selected.only=TRUE, plot=TRUE, plot.stat=mean, 
                        color.by=NULL, pch='+', title.addition=NULL, ...) {

  if (data.file) d <- read.csv (data, comment.char='')
  else d <- data

  
  d.c <- NULL
  if ( is.null(classes) ) {
    classes <- levels(d[,class.var])
    n.classes <- nlevels(d[,class.var])
  } else n.classes <- length (classes)
  
  for (c in classes) {
    index <- d[,class.var] == c
    if (selected.only) index <- index & d[,'selected']
    d.c <- c (d.c, list (d[index,]))
  }

  for (t in tests) {
    table <- NULL
    for (v in vars) {
      classes.pairs <- combinations (n.classes, 2, 1:n.classes)
      p.values <- NULL
      for ( x in 1:dim(classes.pairs)[1] ) {
        pair <- classes.pairs [x,]
        x.1 <- d.c[[pair[1]]][,v]
        x.2 <- d.c[[pair[2]]][,v]
        t.x <- t (x.1, x.2)
        mark <- t.x$p.value <= pvalue.sig
        p.value <- format.pval(t.x$p.value, digits=3, eps=1e-03)
        if (mark) p.value <- paste (p.value, '*', sep='')
        p.values <- c (p.values, p.value)
      }
      table <- cbind (table, p.values)
    }
    colnames (table) <- vars
    rownames (table) <- unlist ( lapply (1:dim(classes.pairs)[1],
                                         function (i) {
                                           paste ( classes[classes.pairs[i,1]],
                                                   classes[classes.pairs[i,2]], sep='.')
                                         }) )
    heading <- paste ("p-values for", t.x$method)
    print ('', quote=FALSE)
    print (heading, quote=FALSE)
    print (table, quote=FALSE)
    print ('', quote=FALSE)
    if ( !is.null(out.file) ) {
      blanks <- rbind ('')
      write.table (blanks, out.file, append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)
      write.table (heading, out.file, append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)
      write.table (table, out.file, append=TRUE, quote=FALSE, col.names=NA, sep=',')
      write.table (blanks, out.file, append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)
    }
  }


  if (plot) {
    d.l <- unlist (lapply (1:length(d.c), function (i) { dim(d.c[[i]])[1] }))
    d.s <- c (0, cumsum (d.l))
    
    fig.cols <- ceiling (sqrt (length(vars)))
    fig.rows <- ceiling (length(vars) / fig.cols)
    par (mfrow=c(fig.rows, fig.cols))
    for (v in vars) {
      d.all <- lapply (1:length(d.c), function (i) { as.vector (d.c[[i]][,v]) })
      plot (unlist(d.all), pch=pch, xlab='Samples', ylab=v, ...)
      title ( paste ('Variation of', v, 'by', class.var, title.addition),
              sub=paste(classes,collapse='  /  ') )
      for (x in 1:n.classes) {
        col <- x %% (n.classes+1)
        range <- (d.s[x]+1):d.s[x+1]
        points (range, d.all[[x]], pch=pch, col=col)

        if ( !is.null(color.by) ) {
          color.by.factor <- as.factor (d[,color.by])
          k <- 0.9
          delta <- k/nlevels(color.by.factor)

          d.by <- cbind ( d.c[[x]][,c(v,color.by)], row=(d.s[x]+1):d.s[x+1] )
          for ( l in levels(color.by.factor) ) {
            # determine color hue (4 basic colors max, even if there are more classes)
            col.by <- col %% 5
            col.h <- if (col.by==1) rgb(1-k,1-k,1-k) else if (col.by==2) rgb(k,0,0)
                     else if (col.by==3) rgb (0,k,0) else rgb (0,0,k)
            points ( d.by [ d.by[,color.by] == l, c('row',v) ], pch=pch, col=col.h )
            k <- k - delta
          }
        }
        # plot stat line after everything so that this is not obscured
        col.l <- col2rgb (col) / 255
        col.l <- col.l / 1.3                # get the color just right!
        if ( sum(col.l) == 0 ) col.l <- c(0.3,0.3,0.3)
        points (range, rep ( plot.stat(d.all[[x]]), d.l[x] ),
                type='l', col = rgb (col.l[1], col.l[2], col.l[3]))
      }
    }
  }
}



mz.histogram <- function (mz.array.file, sample.list, classes=NULL,
                          sample.id.col=5, title.addition=NULL, ...) {
  d <- read.csv (mz.array.file, comment.char='')
  s <- read.csv (sample.list, header=FALSE)
  colnames (s) <- c ('class', 'sample')

  samples <- unlist ( lapply (strsplit (colnames (d), '\\.'),
                              function (x) { x[sample.id.col] }) )
  cls <- as.factor (unlist (lapply (samples,
                                    function (x) { toString (s[ s[,'sample']==x, 'class' ]) })))

  if ( is.null(classes) ) classes <- levels (cls)
  else classes <- as.factor (classes)
  n.classes <- nlevels (classes)

  fig.cols <- ceiling (sqrt (n.classes))
  fig.rows <- ceiling ( n.classes / fig.cols )
  par (mfrow=c(fig.rows, fig.cols))

  mz.mean <- NULL
  for ( i in 1:n.classes ) {
    c <- classes[i]
    # cls and c can have different nlevels; hence cls == c can cause errors
    selection <- toString(c) == unlist (lapply (cls, toString))  
    mz.mean.c <- mean ( d[,selection], na.rm=TRUE )
    samples.c <- unlist ( as.vector (d [,selection]) )
    hist (samples.c, main=paste ('Peak distribution for', c),
          xlab='peak m/z', col=i)
    title ('', sub=title.addition)
    mz.mean <- rbind (mz.mean,
                      cbind (mz.mean.c,
                             rep(toString(c),length(mz.mean.c))))
  }
  
  colnames (mz.mean) <- c ('mz.mean', 'class')
  mz.mean <- data.frame (mz.mean)
  mz.mean [,'mz.mean'] <- unlist (lapply (mz.mean[,'mz.mean'], as.numeric))

  invisible (mz.mean)
}



bias.accuracy.corr <- function (stat.file, error.matrix.file, bias.fns, files=TRUE,
                                group.by=c('chip','eam','energy','fraction'),
                                model.col='model', error.col='error', error.filter=NULL,
                                decompose=TRUE, selected.only=TRUE) {
  if (files) {
    stats <- read.csv (stat.file, comment.char='')
    errors <- read.csv (error.matrix.file)
  } else {
    stats <- stat.file
    errors <- error.matrix.file
  }

  if (selected.only) stats <- stats [ stats[,'selected'], ]

  # convert all group.by columns in stats to string in order to
  # avoid factor level mismatches between errors and stats
  stats.group.by.string <- NULL
  for (v in group.by) 
    stats.group.by.string <- c (stats.group.by.string,
                                list (unlist (lapply (stats[,v], toString))))

  errors.unique <- unique ( errors [, c(group.by,model.col)] )
  errors.bias <- NULL
  for (i in 1:dim(errors.unique)[1]) {
    # for rows in the error matrix with the same group.by values,
    # compute subset of stat matrix with the same conditions
    # and determine bias for the model using bias.fns
    selection <- rep (TRUE, dim(stats)[1])
    for ( j in 1:length(group.by) ) {
      value <- toString ( errors.unique[i,group.by[j]] )
      subset <- rep (FALSE, dim(stats)[1])
      if (decompose) {
        # need to decompose combinations of conditions
        for ( k in 1:nchar(value) ) {
          value.x <- substr (value, k, k)
          subset <- subset | (stats.group.by.string[[j]] == value.x)
        }
      } else {
        # when a "base" condition has a label with multiple chars ...
        subset <- stats.group.by.string[[j]] == value
      }
      selection <- selection & subset
    }
    stats.subset <- stats [selection, ]
    bias.fn <- bias.fns [[ toString (errors.unique[i,model.col]) ]]
    if (! is.null(bias.fn) ) {
      # process only those models for which bias.fns are available
      bias.i <- bias.fn (stats.subset)
      row.i <- cbind ( errors.unique[i,], rbind(bias.i) )
      errors.bias <- rbind (errors.bias, row.i)
    }
  }

  if (! is.null(error.filter) ) {
    # collapse error rows for given group.by values (instead of
    # retaining all rows) using specified error.filter
    conditions <- c (group.by, model.col)
    filter.array <- aggregate (errors[,error.col], errors[,conditions], error.filter)
    colnames (filter.array) <- c (conditions, error.col)
    # extract relevant records from errors table
    errors.min <- merge (filter.array, errors, by=colnames(filter.array))
  } else errors.min <- errors
  
  final.errors <- merge (errors.min, errors.bias, by=c(group.by, model.col))
  invisible (final.errors)
}



two.class.diff <- function (data, class1, class2,
                            class.col='class', target.col='avg.peaks', measure=mean,
                            tests=c(ks.test, wilcox.test), ratio=FALSE) {
  # splits data into class1 and class2, computes measure on each class
  # (for the target.col) and returns abs ( measure(class1) - measure(class2) )
  # [or abs ( measure(class1) - measure(class2) ) / (measure(class1) + measure(class2)) if ratio=T]
  # if class2 == 'complement' then class2 is everything not in class1
  # also runs specfied tests for the two classes;
  # class1 and class2 can be lists of subclasses that constitute the classes

  data.class <- lapply (data[,class.col], toString)

  m1.index <- rep (FALSE, length(data.class))
  for (s1 in class1) m1.index <-  m1.index | data.class == s1
  m1 <- measure ( data [m1.index, target.col] )
  
  if (class2 == 'complement') m2.index <- !m1.index
  else {
    m2.index <- rep (FALSE, length(data.class))
    for (s2 in class2) m2.index <- m2.index | data.class == s2
  }
  m2 <- measure ( data [m2.index, target.col] )

  return.value <- list (measure=abs(m1-m2))
  if (ratio) return.value <- list (measure = abs(m1-m2)/(m1+m2))
  for (fn in tests) {
    t <- fn (data [m1.index, target.col], data [m2.index, target.col])
    return.value <- c (return.value, list (t))
  }

  return.value
}



multi.class.diff <- function (data, classes.list, ...) {
  results <-  lapply (classes.list,
                      function (x) { two.class.diff (data, x, 'complement', ...) })
  return (results)
}




# function for visualizing any matrix
matrix.viz <- function (data, out.file, x.var, y.var, height.var, width.var=NULL,
                        color.var=NULL, color.code.fn=NULL, combine.fn=mean,
                        title=NULL, subtitle=NULL) {
  
  pvalue.to.color <- function (pvalues) {
    # s value in hsv
    color.code <- rep (0.1, length(pvalues))
    color.code [ pvalues <= 0.1 ] <- 0.3
    color.code [ pvalues <= 0.05 ] <- 0.5
    color.code [ pvalues <= 0.01 ] <- 0.7
    color.code [ pvalues <= 0.001 ] <- 0.9
    
    color.code
  }


  # defaults
  default.width <- default.spacing <- 0.1
  default.color <- 0
  default.scale <- 0.9 * default.spacing
  if ( is.null(color.var) ) {
    color.var <- 'color.var'
    data <- cbind ( data, color.var=rep(default.color,dim(data)[1]) )
  }
  if ( is.null(width.var) ) {
    width.var <- 'width.var'
    data <- cbind ( data, width.var=rep(default.width,dim(data)[1]) )
  }
  legend.show <- FALSE
  if ( is.null(color.code.fn) ) {
    # color encodes p-value
    legend.show <- TRUE
    color.code.fn <- pvalue.to.color
  }
  

  result <- NULL
  result.height <- NULL
  result.color <- NULL
  result.width <- NULL


  # compute rectangle characteristics
  for ( y in unique(data[,y.var]) ) {
    d <- data [ data[,y.var]==y, ]
    h <- w <- c <- NULL
    for ( x in unique(data[,x.var]) ) {
      h <- c (h, combine.fn (as.numeric (d [d[,x.var]==x, height.var])))
      w <- c (w, combine.fn (as.numeric (d [d[,x.var]==x, width.var])))
      c <- c (c, combine.fn (as.numeric (d [d[,x.var]==x, color.var])))
    }
    result.height <- rbind (result.height, h)
    result.width <- rbind (result.width, w)
    result.color <- rbind (result.color, color.code.fn (c))
  }
  

  # scale values so that max value is default.scale
  result.height <- default.scale * result.height / max(abs(result.height))
  result.width <- default.scale * result.width / max(abs(result.width))


  # plot results:
  # height of rectangle ~ coefficient estimate (red: -ve, blue: +ve)
  # width of rectangle ~ average accuracy for group
  # color of rectangle ~ intensity proportional to significance
  spacing <- default.spacing
  spacing.half <- spacing / 2
  delta <- spacing/20
  labels.x <- unlist (lapply (unique(data[,x.var]), toString))
  labels.y <- unlist (lapply (unique(data[,y.var]), toString))
  n.x <- length (labels.x)
  n.y <- length (labels.y)


  # use pdf for output since jpeg distorts solid colors
  if (! is.null(out.file) ) pdf (out.file, pointsize=6) else x11()
  plot.new()
  plot.window ( xlim=c(0,n.x*spacing), ylim=c(0,(n.y+legend.show)*spacing) )  # n.y+1 if legend

  y.actual <- NULL
  for (j in 1:n.y) {
    y <- (j-1)*spacing
    if (j > 1) {
      excess <- max (result.height[j-1,] - result.height[j,]) - spacing
      if ( excess > 0 ) y <- y + excess + delta
    }
    y.actual <- c (y.actual, y)
    for ( i in 1:n.x ) {
      x <- (i-1)*0.1
      w <- result.width[j,i]
      h <- result.height[j,i]

      col.s <- abs(result.color[j,i])
      if ( sign(h) == -1 ) col.hsv <- hsv (0, col.s, 1)  # reds
      else col.hsv <- hsv (0.6666, col.s, 1)             # blues
      rect (x, y, x+w, y+h, col=col.hsv)
    }
  }

  # vertical separators
  for ( x in seq(0,n.x*spacing, spacing*2) )
    points ( c(x-delta,x-delta), c(-spacing,y.actual[n.y]+spacing),
             type='l', col=rgb(0.9,0.9,0.9) )

  # horizontal "axes"
  for ( y in y.actual )
    points ( c(-2*delta,n.x*spacing), c(y,y), type='l', col=rgb(0.6,0.6,0.6) )

  axis (1, at=seq(spacing.half, n.x*spacing, spacing), labels=labels.x, tick=FALSE)
  axis (2, at=y.actual, labels=labels.y, tick=FALSE)
  title (title, subtitle)

  # color intensity legend (for p-values)
  # (not shown if color.code.fn is externally defined)
  if (legend.show) {
    neg.001 <- hsv (0, color.code.fn(0.001), 1)
    neg.01 <- hsv (0, color.code.fn(0.01), 1)
    neg.05 <- hsv (0, color.code.fn(0.05), 1)
    pos.001 <- hsv (0.6666, color.code.fn(0.001), 1)
    pos.01 <- hsv (0.6666, color.code.fn(0.01), 1)
    pos.05 <- hsv (0.6666, color.code.fn(0.05), 1)
    text <- c ('p-value <= 0.001', '', 'p-value <= 0.01', '', 'p-value <= 0.05', '')
    colors <- c (pos.001, neg.001, pos.01, neg.01, pos.05, neg.05)
    size <- legend (0, 0, text, fill=colors, ncol=3, plot=FALSE)
    x.legend <- n.x*spacing/2 - size$rect$w/2   # center legend
    legend (x.legend, (n.y+1)*spacing, text, fill=colors, ncol=3, y.intersp=0.75)
  }


  if (! is.null(out.file) ) dev.off()
}



#
# parallel coordinate plot (parallel axis) visualization
#
library (lattice)
pcpviz.topN <- function (file, name.prefix="MZ.", read.cls=TRUE,
                         n=0, select.features=NULL,
                         colors=NULL, colors.rainbow=FALSE,
                         s2n.estimate='median', s2n.two.sided=TRUE, multiclass=FALSE) {
  # reads data from 'file'.gct and class vector from 'file'.cls,
  # S2N features selection is effected to plot the specified number of features
  # using parallel coordinate plots (parallel axis visualization)
  d <- read.dataset (file, read.cls, name.prefix=name.prefix)
  data <- d$data; if ( !is.null(select.features) ) data <- data [,select.features]
  data.viz <- data  # default data to visualize

  if (read.cls) {
    cls <- d$class.vector;
    classes <- unique(cls)
    n.classes <- length (classes)
    if (is.null(colors) || length(colors) != n.classes)
      colors <- 1:n.classes

    if (n > 0) {
      # feature selection needed
      cls.all <- if (n.classes > 2) classes.1vAll(cls) else data.frame (cls)
      if (multiclass) s2n.two.sided <- FALSE
      
      # collect top n features
      f.all <- NULL
      for (c in 1:dim(cls.all)[2]) {
        f.select <- features.s2n.topN (data, cls.all[,c], n,
                                       two.sided=s2n.two.sided,
                                       class.estimate=s2n.estimate) $selection
        f.all <- c (f.all, f.select)
      }
      data.viz <- data [, f.all]
    }
  }


  # plot
  if (colors.rainbow) {
    if (read.cls) {
      data.viz <- cbind (data.viz, class=cls)
      parallel ( ~data.viz, col=rainbow(length(cls)) )
    } else parallel ( ~data.viz, col=rainbow(ncol(data.viz)) )
  } else {
    if (read.cls) {
      cols.viz <- unlist (lapply ( as.numeric(cls), function (i) {colors [i]} ))
      parallel ( ~data.viz, col=cols.viz )
    } else {
      if (! is.null(colors) ) parallel ( ~data.viz, col=colors )
      else parallel ( ~data.viz )
    }
  }
}
  




# spectra comparison
spectra.compare <- function (file1, file2, dir, low.Da, high.Da) {

  normalize.filtered.intensity <- function (s1, s2) {
    # intensity normalization to the mean intensity of s1 and s2
    # both s1 and s2 must have the same s.eam and s.energy

    filter.noise.and.matrix <- function (s) {
      # compute noise and noise envelope
      noise1.all <- noise (s[,2])
      noise1 <- noise1.all[,2]
      # subtract noise envelope
      spec1 <- abs (s[,2]) - noise1
      spec1[spec1 < 0] <- 0
      s <- cbind (s[,1], spec1)

      s [ s[,1]>=low.Da & s[,1]<=high.Da, ]
    }


    s.1 <- filter.noise.and.matrix (s1)
    s.2 <- filter.noise.and.matrix (s2)

    i.1 <- mean (s.1[,2])
    i.2 <- mean (s.2[,2])

    i.mean <- mean ( c(i.1, i.2) )
    s.1[,2] <- s.1[,2] * (i.mean/i.1)
    s.2[,2] <- s.2[,2] * (i.mean/i.2)

    invisible ( list (s1=s.1, s2=s.2) )
  }
  

  s1 <- read.csv ( paste (dir,file1,sep='/') )
  s2 <- read.csv ( paste (dir,file2,sep='/') )

  s <- normalize.filtered.intensity (s1, s2)
  if ( nrow(s$s1) != nrow(s$s2) ) {
    # sometimes the two spectra have different number of points
    # if this happens, chop off extra points at end of larger spectra
    # (may not always be correct)
    warning ( paste ('Spectra length check:', file1, 'vs.', file2, '\n'), quote=FALSE )
    n <- min ( nrow(s$s1), nrow(s$s2) )
  } else n <- nrow(s$s1)
  correlation <- max ( ccf (s$s1[1:n,2], s$s2[1:n,2], plot=FALSE)$acf )

  return (correlation)
}




# SDF (GenePattern) format file processing

read.sdf <- function (file) {
  # reads SDF files
  # most of the header information is discarded;
  # only the column names are slavaged

  
  clean.up.names <- function (names) {
    # clean up names
    names [ names=='#' ] <- "Row"
    names [ names=="Perm 1%" ] <- "Perm.1"
    names [ names=="Perm 5%" ] <- "Perm.5"
    names [ names=="Perm (user)" ] <- "Perm.user"

    return (names)
  }

  
  con <- file (file, open="r")
  # header lines
  line1 <- scan (con, what=list('string'), nmax=1)
  if ( line1[[1]][1] != 'SDF' ) {
    close (con)
    stop ( paste ("Invalid SDF format:",file) )
  }
  line2 <- scan (con, what=list('string',integer(0)), nmax=1)
  header.lines <- line2[[2]][1]
  # column names
  line.num <- 2
  col.names <- NULL
  repeat {
    line.num <- line.num + 1
    if (line.num > header.lines+2) break
    line <- scan (con, what=list('string'), nmax=1, sep='\t')[[1]]
    if ( line[1] == "COLUMN_NAMES:" ) {
      line <- clean.up.names (line)
      col.names <- line [2:length(line)]
    }
  }
  if ( is.null(col.names) ) {
    close (con)
    stop ( paste ("Can't find COLUMN_NAMES:",file) )
  }

  # read table
  table <- read.table (con, header=FALSE, sep='\t', row.names=1, col.names=col.names, as.is=TRUE)
  close (con)

  return (table)
}




# feature prioritization and ranking
      
features.evaluate <- function (condition.list, classification, classes.list,
                               data.dir, empeaks.file, stats.file, name.sep='-',
                               sig.pvalue=0.01, n.perm=100, all.feat=FALSE,
                               amplitude.postnorm=FALSE, norm.type='tan', proc.replicate='best') {
  # feature evaluation for a given condition and classification, on UNSTACKED data
  # (stacked data is NOT supported);
  # for each feature in the dataset, the following are determined:
  #  1. (Score) S2N 
  #  2. (Importance) decision tree-based variable importance 
  #  3. (Stability) 1 - [ peak location variance / peak location ]
  #  4. (Unbiasedness) 1 - bias (where, bias = (m1 - m2) / (m1 + m2),
  #                                             mx=mean of avg. peaks for class x)
  #  5. (Amplitute) mean absolute peak amplitude in class for which peak is upregulated
  

  # preliminaries
  if (! check.condition.list(condition.list) )
    stop ( paste ("condition list must have (chip,eam,energy,fraction):", condition.list) )
  condition <- paste (condition.list, collapse='x')
  prefix <- paste (data.dir, '/', condition, name.sep, classification, sep='')
  gct <- paste (prefix, '.gct', sep='')
  cls <- paste (prefix, '.cls', sep='')
  out <- paste ('temp-output-', Sys.getpid(), sep='')
  gct.header <- scan (gct, what=list('character',integer(0),integer(0)), nmax=1)
  n.feat <- gct.header[[2]]
  n.samples <- gct.header[[3]]

  
  # S2N ratio for markers
  java.dir <- Sys.getenv ('PROTEOMICS_JAVABASE')
  if ( java.dir == "" ) stop ('PROTEOMICS_JAVABASE not set in environment.')
  fsel.jar <- paste (java.dir, 'RunMarkerSelection.jar', sep='/')
  cmd <- paste ("java -jar", fsel.jar, 
                "-t", gct, "-c", cls, "-o", out, "-N", trunc (n.feat/2),
                "-S -d -p", "-P", n.perm, "-l", sig.pvalue)
  system (cmd)
  s2n.table <- read.sdf (out)
  s2n.table <- s2n.table [ s2n.table[,'Score'] > s2n.table[,'Perm.user'], c('Class','Score','Feature')]
  file.remove (out)
  if ( nrow(s2n.table) == 0 ) {
    warning ( paste ("No significant S2N features: ", condition, "-", classification, sep='') )
    return (NULL)
  } 
  
  # decision tree variable importance
  t <- tree.loo (prefix, show.tree=FALSE, loo.cv=FALSE, minsplit=trunc(n.samples/10),
                 maxsurrogate=n.feat)
  t.vars <- as.numeric ( substring (rownames (t$variable.importance), 5) )
  t.table <- cbind (Feature=t.vars, Importance=t$variable.importance[,'var.imp'])

  feat.table <- merge (s2n.table, t.table, by='Feature', all=all.feat)
  feat.table [ is.na(feat.table[,'Importance']), 'Importance' ] <- 0  # if any NA's in Importance

  
  # peak location variance
  var.table <- read.csv (empeaks.file)
  var.table <- cbind (Feature = prettyNum (var.table[,'mean'],digits=5), var.table,
                      Stability = 1 - var.table[,'var'] / var.table[,'mean'])
  feat.table <- merge (feat.table, var.table[,c('Feature','Stability')], by='Feature')

  
  # bias
  stats <- read.csv (stats.file, comment.char='')
  stats.cond <- stats [ stats[,'chip'] == condition.list$chip &
                        stats[,'eam'] == condition.list$eam &
                        stats[,'energy'] == condition.list$energy &
                        stats[,'fraction'] == condition.list$fraction, ]
  if ( length(classes.list)==2 ) {
    # binary
    bias <- two.class.diff (stats.cond, classes.list[[1]], classes.list[[2]], ratio=TRUE) $measure
  } else {
    # multi class
    b <- multi.class.diff (stats.cond, classes.list, ratio=TRUE)
    b.measures <- unlist ( lapply (1:length(b), function (i) { b[[i]]$measure }) )
    bias <- mean (b.measures)
  }
  feat.table <- cbind ( feat.table, Unbiasedness = rep (1-bias, nrow(feat.table)) )


  # absolute amplitude
  gct.table <- read.gct (gct)
  cls.names <- read.cls.mapped (cls)
  if (!amplitude.postnorm)
    # compute pre-normalization amplitudes
    gct.table <- denormalize (gct.table, stats, condition.list, norm.type=norm.type,
                              proc.replicate=proc.replicate)
  # average amplitude (in upregulated class) for each peak
  amp <- unlist ( lapply (1:nrow(feat.table),
                          function (i) {
                            mean ( unlist (gct.table [ gct.table[,'Name'] == feat.table[i,'Feature'],
                                                       c (FALSE,FALSE,cls.names == feat.table[i,'Class']) ] ))
                          }) )
  feat.table <- cbind (feat.table, Amplitude=amp)

  
  # assemble final table with relevant info
  n <- nrow(feat.table)
  return ( cbind (chip=rep(condition.list$chip,n),
                  eam=rep(condition.list$eam,n),
                  energy=rep(condition.list$energy,n),
                  fraction=rep(condition.list$fraction,n),
                  classification=classification,
                  feat.table) )
}



# feature overlap in two sets of features

overlap <- function (v1, v2, mz.var, exact) {
  # determine variables in v1 that are present in v2;
  # ensure each var in v2 can account for atmost one match, i.e.,
  # when a var matches, remove it from the list so it is not matched again

  result <- NULL
  for ( i in 1:length(v1) ) {
    diff <- abs (v2 - v1[i]) / v1[i]
    diff.min <- min (diff)
    keep <- diff != diff.min
    check <- if (exact) diff.min == 0 else diff.min <= mz.var
    if (check) v2 <- v2[keep]
    result <- c (result, check)
  }
  result
}



overlap.tree <- function (file.base1, file.base2, mz.var, exact=FALSE, ...) {
  # determine overlapping feature set for two tree models
  # will work for basic conditions only (no stacking)
  
  t1 <- tree.loo (file.base1, show.tree=FALSE, loo.cv=FALSE, ...)
  t2 <- tree.loo (file.base2, show.tree=FALSE, loo.cv=FALSE, ...)

  # in variable importance list, remove d.t. and convert m/z to numeric
  # also pick the same number of vars in both lists
  vars1 <- as.numeric ( substring (rownames (t1$variable.importance), 5) )
  vars2 <- as.numeric ( substring (rownames (t2$variable.importance), 5) )
  
  matches1 <- overlap (vars1, vars2, mz.var, exact)
  matches2 <- overlap (vars2, vars1, mz.var, exact)
  overlap.n <- sum (matches1)

  return (overlap1 = cbind (features=vars1, common=matches1),
          overlap2 = cbind (features=vars2, common=matches2))
}



overlap.s2n <- function (file.base1, file.base2, mz.var, exact=FALSE,
                         n=10, p.iterations=100, ...) {
  # determine overlapping feature set for two k-NN models (s2n-based)
  # will work for basic conditions only (no stacking)
  
  d1 <- read.dataset (file.base1)
  d2 <- read.dataset (file.base2)

  # get list of features, remove MZ. and convert m/z to numeric
  vars1 <- as.numeric ( substring (features.s2n.topN (d1$data, d1$class.vector, n, ...)$selection, 4) )
  vars2 <- as.numeric ( substring (features.s2n.topN (d2$data, d2$class.vector, n, ...)$selection, 4) )

  matches1 <- overlap (vars1, vars2, mz.var, exact)
  matches2 <- overlap (vars2, vars1, mz.var, exact)
  overlap.n <- sum (matches1)

  # compute p-value for overlap
  overlap.random <- NULL
  for (i in 1:p.iterations) {
    v1 <- as.numeric ( substring (features.s2n.topN (d1$data, sample(d1$class.vector),
                                                     n, ...)$selection, 4) )
    v2 <- as.numeric ( substring (features.s2n.topN (d2$data, sample(d2$class.vector),
                                                     n, ...)$selection, 4) )
    matches <- overlap (v1, v2, mz.var, exact)
    overlap.random <- c (overlap.random, sum(matches))
  }
  p.value <- sum (overlap.random >= overlap.n) / p.iterations
  
  return (overlap1 = cbind (features=vars1, common=matches1),
          overlap2 = cbind (features=vars2, common=matches2),
          p.value=p.value, overlap.random=overlap.random)
}




# extracting results from .t and .p output from k-NN/WV runs
# using RunGeneCluster.jar

read.summary <- function (file) {
  # reads summary from random train-test splits or class vector permutation runs
  d <- read.table (file)
  d <- d [ , 8:dim(d)[2] ]  # ignore first 7 columns -- just get the histogram
  # undo histogram to get actual list of errors and return it
  data <- unlist (lapply (1:dim(d)[2], function (i) { rep (d[1,i], d[2,i]) }))
  invisible (data)
}


read.summary.roc <- function (file) {
  # reads summary from roc files for random train-test splits or class vector permutation runs
  roc.data <- read.table (file)
  roc.data <- as.vector (unlist (as.vector (roc.data [2, 4:dim(roc.data)[2]])))  # extract ROC errors
  invisible (roc.data)
}
  
  
extract.results <- function (outfile, features, n.samples, n.train, n.test, best=FALSE) {
  # extracts error, error variance from train-test split data (<outfile.t.*>)
  # determines random permutation p-values from permutation results (<outfile.p.*>)
  
  results <- NULL
  for (f in features) {
    tt.file <- paste (outfile, '.t.', f, '.', n.train, sep='')
    tt.roc.file <- paste (tt.file, '.roc', sep='')
    p.file <- paste (outfile, '.p.', f, sep='')

    # if any of the files do not exist for f, skip this iteration
    if ( !file.exists(tt.file) || !file.exists(tt.roc.file) || !file.exists(p.file) ) next
    
    tt.data <- read.summary (tt.file) / n.test
    p.data <- read.summary (p.file) / n.samples
    roc.data <- read.table (tt.roc.file)
    roc.data <- as.vector (unlist (as.vector (roc.data [2, 4:dim(roc.data)[2]])))  # extract ROC errors

    # errors based on number of misclassified samples
    median.stats <- boxplot (tt.data, range=0, plot=FALSE)
    median <- median.stats$stat[3]
    min <- median.stats$stat[1]
    max <- median.stats$stat[5]
    median.ci.lower <- median.stats$conf[1]
    median.ci.upper <- median.stats$conf[2]
    
    mean.stats <- ci (tt.data)
    mean <- mean.stats[[1]]
    mean.ci.lower <- mean.stats[[2]]
    mean.ci.upper <- mean.stats[[3]]

    # ROC ("real") error -- based on misclassification by class
    roc.median.stats <- boxplot (roc.data, range=0, plot=FALSE)
    roc.median <- roc.median.stats$stat[3]
    roc.min <- roc.median.stats$stat[1]
    roc.max <- roc.median.stats$stat[5]
    roc.median.ci.lower <- roc.median.stats$conf[1]
    roc.median.ci.upper <- roc.median.stats$conf[2]
    
    roc.mean.stats <- ci (roc.data)
    roc.mean <- roc.mean.stats[[1]]
    roc.mean.ci.lower <- roc.mean.stats[[2]]
    roc.mean.ci.upper <- roc.mean.stats[[3]]

    pvalue.error.mean <- mean (p.data)
    pvalue.mean <- sum (p.data < mean) / length (p.data)
    pvalue.median <- sum (p.data < median) / length (p.data)

    new.row <- c (n.features=f, min=min, max=max, 
                  median.ci.lower=median.ci.lower, median=median, median.ci.upper=median.ci.upper,
                  mean.ci.lower=mean.ci.lower, mean=mean, mean.ci.upper=mean.ci.upper,
                  roc.min=roc.min, roc.max=roc.max,
                  roc.median.ci.lower=roc.median.ci.lower,
                  roc.median=roc.median, roc.median.ci.upper=roc.median.ci.upper,
                  roc.mean.ci.lower=roc.mean.ci.lower,
                  roc.mean=roc.mean, roc.mean.ci.upper=roc.mean.ci.upper,
                  pvalue.mean=pvalue.mean, pvalue.median=pvalue.median,
                  pvalue.error.mean=pvalue.error.mean)
    results <- rbind (results, new.row)
  }

  if (best) {
    mean.error <- as.numeric(results[, 'mean'])
    best.rows <- rbind ( results [ mean.error == min(mean.error), ] )
    results <- best.rows [1, ]   # keep only the first (with fewer features)
  }

  invisible (results)
}




# miscellaneous

check.condition.list <- function (l) {
  # checks if chip, eam, energy and fraction are present in the list l
  if ( is.null (l$chip) || is.null (l$eam) || is.null (l$energy) || is.null (l$fraction) )
    return (FALSE)
  else return (TRUE)
}


denormalize <- function (data, stats, condition.list, norm.type='tan', proc.replicate='best',
                         sampleid.col=3, sep='\\.') {
  # undo normalization for given (unstacked) data (from read.gct),
  # using the norm factors in stats (respective stats table for data),
  # based on conditions in condition.list;
  # stacked data NOT supported
  if (! norm.type %in% normalizations)
    stop ( paste ("Unknown normalization scheme:", norm.type) )
  if (norm.type=='none') return (data)
  if (! check.condition.list(condition.list) )
    stop ( paste ("condition list must have (chip,eam,energy,fraction):", condition.list) )

  stats.cond <- stats [ stats[,'chip'] == condition.list$chip &
                        stats[,'eam'] == condition.list$eam &
                        stats[,'energy'] == condition.list$energy &
                        stats[,'fraction'] == condition.list$fraction, ]

  first.2.cols <- data [,1:2]
  table <- data[,3:ncol(data)]

  samples <- t ( data.frame (strsplit (colnames(table),sep)) ) [, sampleid.col]
  norm.factors <- unlist (lapply (samples,
                                  function (s) {
                                    rows <- stats.cond [ stats.cond[,'sample']==s, ]
                                    if (proc.replicate=='best')
                                      rows [ rows[,'quality'] == max (rows[,'quality']), 'norm.factor'][1]
                                    else mean (rows [,'norm.factor'])
                                  }))
  if (norm.type=='tin' || norm.type=='tan') 
    for (i in 1:ncol(table)) table [,i] <- table[,i] / norm.factors[i]
  else if (norm.type=='01') {
    min.values <- unlist (lapply (samples,
                                  function (s) {
                                    rows <- stats.cond [ stats.cond[,'sample']==s, ]
                                    if (proc.replicate=='best')
                                      rows [ rows[,'quality'] == max (rows[,'quality']), 'min'][1]
                                    else mean (rows [,'min'])
                                  }))
    for (i in 1:ncol(table)) table [,i] <- (table[,i] / norm.factors[i]) + min.values[i]
  } else stop ("Unknown normalization scheme escaped error check!")
  
  data.denorm <- cbind (first.2.cols, table)
  return (data.denorm)
}



confusion.matrix <- function (actual, predicted) {
  values.a <- sort (unique (actual))
  values.p <- sort (unique (predicted))

  if ( any (values.a != values.p) || length (values.a) != 2 )
    stop ("Can't compute confusion matrix for given data.")

  c.m <- matrix (nrow=2, ncol=2, dimnames = list (actual=values.a, predicted=values.p))

  c.m[ values.a[1], values.p[1] ] <- sum (actual==values.a[1] & predicted==values.p[1])
  c.m[ values.a[2], values.p[2] ] <- sum (actual==values.a[2] & predicted==values.p[2])
  c.m[ values.a[1], values.p[2] ] <- sum (actual==values.a[1] & predicted==values.p[2])
  c.m[ values.a[2], values.p[1] ] <- sum (actual==values.a[2] & predicted==values.p[1])

  return (c.m)
}
