### Name: getGEOfile
### Title: Download a file from GEO soft file to the local machine
### Aliases: getGEOfile
### Keywords: IO

### ** Examples

  myfile <- getGEOfile('GDS2')



