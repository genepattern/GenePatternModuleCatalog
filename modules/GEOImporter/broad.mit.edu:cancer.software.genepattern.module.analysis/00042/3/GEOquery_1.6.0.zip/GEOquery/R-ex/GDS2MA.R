### Name: Converting
### Title: Convert a GDS datastructure to a BioConductor datastructure
### Aliases: GDS2MA GDS2eSet
### Keywords: IO

### ** Examples


## Not run: gds505 <- getGEO('GDS505')
## Not run: MA <- GDS2MA(gds505)
## Not run: eset <- GDS2eSet(gds505)




