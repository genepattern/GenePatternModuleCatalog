### Name: getGEO
### Title: Get a GEO object from NCBI or file
### Aliases: getGEO
### Keywords: IO

### ** Examples

gds <- getGEO("GDS2")
gds



