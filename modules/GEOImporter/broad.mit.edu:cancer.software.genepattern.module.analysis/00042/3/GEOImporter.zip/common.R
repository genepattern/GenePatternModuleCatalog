# The Broad Institute
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2003-2006) by the
# Broad Institute/Massachusetts Institute of Technology. All rights are
# reserved.

# This software is supplied without any warranty or guaranteed support
# whatsoever. Neither the Broad Institute nor MIT can be responsible for its
# use, misuse, or functionality.
 
DEBUG <<- FALSE

info <- function(s) {
	if(DEBUG) {
		cat(paste(s, "\n", sep=''))
		#warning(paste(s, "\n", sep=''))
	}
}

# extension e.g. '.gct'
check.extension <- function(file.name, extension) {
	ext <- regexpr(paste(extension,"$",sep=""), tolower(file.name))
	if(ext[[1]] == -1) {
		file.name <- paste(file.name, extension, sep="") 
	}
	return(file.name)
}

read.dataset <- function(file) {
	result <- regexpr(paste(".gct","$",sep=""), tolower(file))
	if(result[[1]] != -1)
		return(read.gct(file))
	result <- regexpr(paste(".res","$",sep=""), tolower(file))
	if(result[[1]] != -1)
		return(read.res(file))
	
	stop("Input is not a res or gct file.")	
}

read.gct <- function(file) {
	if (is.character(file)) 
        if (file == "") 
            file <- stdin()
        else {
            file <- file(file, "r")
            on.exit(close(file))
        }
	if (!inherits(file, "connection")) 
        stop("argument `file' must be a character string or connection")
		  
   # line 1 version
	version <- readLines(file, n=1) 
	
	# line 2 dimensions
	dimensions <- scan(file, what=list("integer", "integer"), nmax=1, quiet=TRUE)   
	rows <- dimensions[[1]]
	columns <- dimensions[[2]]
	# line 3 Name\tDescription\tSample names...
	column.names <- read.table(file, header=FALSE, nrows=1, sep="\t", fill=FALSE) 
	column.names <-column.names[3:length(column.names)]

	
	if(length(column.names)!=columns) {
		stop(paste("Number of sample names", length(column.names), "not equal to the number of columns", columns, "."))	
	}
	
	colClasses <- c(rep(c("character"), 2), rep(c("double"), columns))
	
	x <- read.table(file, header=FALSE, quote="", row.names=NULL, comment.char="", sep="\t", colClasses=colClasses, fill=FALSE)
	row.descriptions <- as.character(x[,2]) 
	data <- as.matrix(x[seq(from=3, to=dim(x)[2], by=1)])
	
	column.names <- column.names[!is.na(column.names)]
	names(data) <- column.names
	
	row.names(data) <- x[,1]
	return(list(row.descriptions=row.descriptions, data=data))
}

read.res <- function(filename)
{
  # read line 1: sample names
  headings <- read.table( filename, header=FALSE, nrows=1, sep="\t", fill=FALSE)
  # delete the NA entries for the tab-tab columns
  headings <- headings[!is.na(headings)]
  colNames <- headings[3:length(headings)]
   
  # read line 2: sample descriptions
  descriptions <- scan(filename, skip=1, nlines=1, sep="\t", fill=F, blank.lines.skip=F, quiet=T, what="character")
  # delete the NA entries for the tab-tab columns
  descriptions <- descriptions[!is.na(descriptions)]
  if(length(descriptions) > 0) {
  	descriptions <- descriptions[3:length(descriptions)]
  }
  # handle optionally missing number of lines (not used, but need to decide whether to ignore before actual data)  
  numLines <- as.list(read.table(filename, header=FALSE, skip=2, nrows=1, sep="\t", fill=FALSE))
  numLines <- numLines[!is.na(numLines)] # remove NA entries
  skip <- (3 - ifelse(length(numLines) == 1, 0, 1)) # skip 3 lines if line number is present, 2 otherwise

  columns <- length(headings) - 2 # substract 2 for gene description and name 
  colClasses <- c(c("character", "character"), rep(c("double", "character"), columns))
 
  
  x <- .my.read.table(filename, header=FALSE, sep="\t", comment.char="", skip=skip, colClasses=colClasses, row.names=NULL, quote=NULL, fill=FALSE)
  
  data <- as.matrix(x[c(seq(from=3,length=(dim(x)[2]-3)/2, by=2))])
  calls <- as.matrix(x[c(seq(from=4,length=(dim(x)[2]-3)/2, by=2))])
  
  row.names <- x[,2]
  row.names(data) <- row.names
  row.names(calls) <- row.names
  row.descriptions <- as.character(x[, 1])
  names(data) <- colNames
  names(calls) <- colNames
  return(list(row.descriptions=row.descriptions, column.descriptions=descriptions, data=data, calls=calls))
}

# like read.table, but doesn't check to make sure all rows have same number of columns
.my.read.table <- function (file, header = FALSE, sep = "", quote = "\"'", dec = ".", row.names, col.names, as.is = FALSE, na.strings = "NA", colClasses, nrows = -1, skip = 0, check.names = TRUE, fill = !blank.lines.skip, strip.white = FALSE, blank.lines.skip = TRUE, comment.char = "") 
{
	if (is.character(file)) {
		file <- file(file, "r")
		on.exit(close(file))
	}
	if (!inherits(file, "connection")) 
		stop("argument `file' must be a character string or connection")
	if (!isOpen(file)) {
		open(file, "r")
		on.exit(close(file))
	}
	if (skip > 0) 
		readLines(file, skip)
		
	first <- readLines(file, n=1) 
	pushBack(first, file)
	temp <- strsplit(first, "\t") 
	cols <- as.integer(length(temp[[1]])) # number of columns
	 
	if (missing(col.names)) 
        col.names <- paste("V", 1:cols, sep = "")
	
	what <- rep(list(""), cols)
	names(what) <- col.names
	colClasses[colClasses %in% c("real", "double")] <- "numeric"
	known <- colClasses %in% c("logical", "integer", "numeric", "complex", "character")
	what[known] <- sapply(colClasses[known], do.call, list(0))
    
	data <- scan(file = file, what = what, sep = sep, quote = quote, dec = dec, nmax = nrows, skip = 0, na.strings = na.strings, quiet = TRUE, fill = fill, strip.white = strip.white, blank.lines.skip = blank.lines.skip, multi.line = FALSE, comment.char = comment.char)
	nlines <- length(data[[1]])
	if (cols != length(data)) {
		warning(paste("cols =", cols, " != length(data) =", length(data)))
		cols <- length(data)
	}
	if (is.logical(as.is)) {
        as.is <- rep(as.is, length = cols)
	}
	else if (is.numeric(as.is)) {
	  if (any(as.is < 1 | as.is > cols)) 
			stop("invalid numeric as.is expression")
	  i <- rep(FALSE, cols)
	  i[as.is] <- TRUE
	  as.is <- i
	}
	else if (is.character(as.is)) {
	  i <- match(as.is, col.names, 0)
	  if (any(i <= 0)) 
			warning("not all columns named in as.is exist")
	  i <- i[i > 0]
	  as.is <- rep(FALSE, cols)
	  as.is[i] <- TRUE
	}
	else if (length(as.is) != cols) 
		stop(paste("as.is has the wrong length", length(as.is), 
			"!= cols =", cols))
	if (missing(row.names)) {
		if (rlabp) {
			row.names <- data[[1]]
			data <- data[-1]
	  }
	  else row.names <- as.character(seq(len = nlines))
	}
	else if (is.null(row.names)) {
		row.names <- as.character(seq(len = nlines))
	}
	else if (is.character(row.names)) {
		if (length(row.names) == 1) {
			rowvar <- (1:cols)[match(col.names, row.names, 0) == 
				 1]
			row.names <- data[[rowvar]]
			data <- data[-rowvar]
	  }
	}
	else if (is.numeric(row.names) && length(row.names) == 1) {
	  rlabp <- row.names
	  row.names <- data[[rlabp]]
	  data <- data[-rlabp]
	}
	else stop("invalid row.names specification")
	class(data) <- "data.frame"
	row.names(data) <- row.names
	data
}

write.res <-
#
# write a res structure as a file
#
function(res, filename, check.file.extension=TRUE)
{
	if(check.file.extension) {
		filename <- check.extension(filename, ".res")
	}
	f <- file(filename, "w")
	on.exit(close(f))
	# write the labels
	cat("Description\tAccession\t", file=f, append=TRUE)
	cat(colnames(res$data), sep="\t\t", file=f, append=TRUE)
	cat("\n", file=f, append=TRUE)
	
	# write the descriptions
	if(!is.null(res$column.descriptions)) {
		cat("\t", file=f, append=TRUE)
		cat(res$column.descriptions, sep="\t\t", file=f, append=TRUE)
	} 
	cat("\n", file=f, append=TRUE)
	
	# write the size
	cat(NROW(res$data), "\n", sep="", file=f, append=TRUE)
	
	# write the data
	# 1st combine matrices
	dim <- dim(res$data)
	dim[2] <- dim[2]*2
	
	m <- matrix(nrow=dim[1], ncol=dim[2]+2)
	
	if(!is.null(res$row.descriptions)) {
		m[,1] <- res$row.descriptions
	} else {
		m[, 1] <- ''
	}
	
	m[,2] <- row.names(res$data)
	
	index <- 3
	for(i in 1:dim(res$data)[2]) {
		m[,index] <- res$data[,i]
		index <- index + 2
	}
	index <- 4
	
	for(i in 1:dim(res$calls)[2]) {
		m[,index] <- as.character(res$calls[,i])
		index <- index + 2
	}
	write.table(m, file=f, col.names=FALSE, row.names=FALSE, append=TRUE, quote=FALSE, sep="\t", eol="\n")
	return(filename)
}

read.cls <- function(file) {
	# returns a list containing the following components: 
	# labels the factor of class labels
	# names the names of the class labels if present
	
	if (is.character(file)) 
        if (file == "") 
            file <- stdin()
        else {
            file <- file(file, "r")
            on.exit(close(file))
        }
    if (!inherits(file, "connection")) 
        stop("argument `file' must be a character string or connection")
   
	line1 <- scan(file, nlines=1, what="character", quiet=TRUE)
	
	numberOfDataPoints <- as.integer(line1[1])
	numberOfClasses <- as.integer(line1[2])
	
	line2 <- scan(file, nlines=1, what="character", quiet=TRUE)
	
	classNames <- NULL
	if(line2[1] =='#') { # class names are given
		classNames <- as.vector(line2[2:length(line2)])
		line3 <- scan(file, what="character", nlines=1, quiet=TRUE)
	} else {
		line3 <- line2
	}
	
	if(is.null(classNames)) {
		labels <- as.factor(line3)
		classNames <- levels(labels)
	} else {
		labels <- factor(line3, labels=classNames)
	}
	if(numberOfDataPoints!=length(labels)) {
		stop("Incorrect number of data points") 	
	}
	r <- list(labels=labels,names=classNames)
	r
}


write.cls <-
#
# write a CLS result to a file.
function(cls, filename, check.file.extension=TRUE)
{
	if(check.file.extension) {
		filename <- check.extension(filename, ".cls")
	}
	file <- file(filename, "w")
	on.exit(close(file))
 
	cat(file=file, length(cls$labels), length(levels(cls$labels)), "1\n")

	if(length(cls$names) > 0) {
		cat(file=file, "# ")
		for(i in 1:(length(cls$names) - 1)) {
			cat(file=file, cls$names[i])
			cat(file=file, " ")
		}
		cat(file=file, cls$names[length(cls$names)])
		cat(file=file, "\n")
	}
	for(i in 1:(length(cls$labels)-1)) {
		cat(file=file, cls$labels[[i]]-1)
		cat(file=file, " ")
	}
	cat(file=file, cls$labels[[length(cls$labels)]]-1)
	return(filename) 
}

write.gct <-
#
# save a GCT result to a file, ensuring the filename has the extension .gct
#
function(gct, filename, check.file.extension=TRUE)
{
	if(check.file.extension) {
		filename <- check.extension(filename, ".gct") 
	}
	f <- file(filename, "w")
	on.exit(close(f))
	

	cat("#1.2", "\n", file=f, append=TRUE, sep="")
	cat(dim(gct$data)[1], "\t", dim(gct$data)[2], "\n", file=f, append=TRUE, sep="")
	cat("Name", "\t", file=f, append=TRUE, sep="")
	cat("Description", file=f, append=TRUE, sep="")
	names <- colnames(gct$data)
	cat("\t", names[1], file=f, append=TRUE, sep="")

	for(j in 2:length(names)) {
		cat("\t", names[j], file=f, append=TRUE, sep="")
	}

	cat("\n", file=f, append=TRUE, sep="")
	m <- matrix(nrow = dim(gct$data)[1], ncol = 2)

	m[, 1] <- row.names(gct$data)		

	if(!is.null(gct$row.descriptions)) {
		m[, 2] <- gct$row.descriptions
	} else {
		m[, 2] <- ''
	}
	m <- cbind(m, gct$data)
	
	write.table(m, file=f, append=TRUE, quote=FALSE, sep="\t", eol="\n", col.names=FALSE, row.names=FALSE)
	return(filename)
}

is.package.installed <- function(libdir, pkg) {
	f <- paste(libdir, pkg, sep='')
	return(file.exists(f) && file.info(f)[["isdir"]])
}


install.package <- function(dir, windows, mac, other) {
	isWindows <- Sys.info()[["sysname"]]=="Windows"
	isMac <- Sys.info()[["sysname"]]=="Darwin" 
	if(isWindows) {
		f <- paste(dir, windows, sep="")
		.install.windows(f)
	} else if(isMac) {
		f <- paste(dir, mac, sep="")
      .install.unix(f)
	} else { # install from source
		f <- paste(dir, other, sep="")
		.install.unix(f)
	}	
}

.install.windows <- function(pkg) {
	install.packages(pkg, .libPaths()[1], CRAN=NULL, installWithVers=FALSE)
}

.install.unix <- function(pkg) {
    lib <- .libPaths()[1]
   # cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL --with-package-versions")
	 cmd <- paste(file.path(R.home(), "bin", "R"), "CMD INSTALL")
    cmd <- paste(cmd, "-l", lib)
    cmd <- paste(cmd, " '", pkg, "'", sep = "")
    status <- system(cmd)
    if (status != 0) 
    	cat("\tpackage installation failed\n")
}

trim <- function(s) {
	sub(' +$', '', s, extended = TRUE) 
}

setLibPath <- function(libdir) {
	libPath <- libdir
	if(!file.exists(libdir)) {
		# remove trailing /
		libPath <- substr(libdir, 0, nchar(libdir)-1)
	}
	.libPaths(libPath)
}

yes.no.to.boolean <- function(s) {
	if(s=="yes") {
		return(TRUE)	
	}
	return(FALSE)
}

exit <- function(s) {
	stop(s, call. = FALSE)
}

isWindows <- function() {
	Sys.info()[["sysname"]]=="Windows"
}

unzip <- function(zip.filename, dest) {
	if(is.null(dest)) {
		dest = getwd()
	}
	if(isWindows()) {
		zip.unpack(zip.filename, dest=dest)
	} else {
      unzip <- getOption("unzip")
      system(paste(unzip, "-q", zip.filename, "-d", dest))
	}
}

get.arg <- function(key, args, default.value='') {
	if(is.null(args[key])) {
		return(default.value)
	}
	return(args[key])
}

parse.command.line <- function(args) {
	result <- list()
	for(i in 1:length(args)) {
		flag <- substring(args[[i]], 0, 2)
		value <- substring(args[[i]], 3, nchar(args[[i]]))
		if(flag=='') {
			next
		}	
		result[flag] <- value
	}
}



