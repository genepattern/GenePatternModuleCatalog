getGEO <- function (GEO = NULL, filename = NULL, destdir = tempdir(), GSElimits = NULL) 
{
    filename <- filename
    if (!is.null(GSElimits)) {
        if (length(GSElimits) != 2) {
            stop("GSElimits should be an integer vector of length 2, like (1,10) to include GSMs 1 through 10")
        }
    }
    if (is.null(GEO) & is.null(filename)) {
        stop("You must supply either a filename of a GEO file or a GEO accession")
    }
    if (is.null(filename)) {
        GEO <- toupper(GEO)
        filename <- getGEOfile(GEO, destdir = destdir)
    }
    if (length(grep("\\.gz$", filename, perl = TRUE)) > 0) {
        con <- gzfile(filename, "r")
    }
    else {
        con <- file(filename, "r")
    }
    ret <- parseGEO(con, GSElimits)
    close(con)
    return(ret)
}

getGEOfile <- function (GEO, destdir = tempdir(), amount = c("full", "brief", 
     "quick", "data")) 
{
    amount <- match.arg(amount)
    geotype <- toupper(substr(GEO, 1, 3))
    mode <- "wb"
    if (geotype == "GDS") {
        gdsurl <- "ftp://ftp.ncbi.nih.gov/pub/geo/data/gds/soft_gz/"
        myurl <- paste(gdsurl, GEO, ".soft.gz", sep = "")
        destfile <- file.path(destdir, paste(GEO, ".soft.gz", 
            sep = ""))
    }
    if (geotype == "GSE" & amount == "full") {
        gseurl <- "ftp://ftp.ncbi.nih.gov/pub/geo/data/geo/by_series/"
        myurl <- paste(gseurl, GEO, "/", GEO, "_family.soft.gz", 
            sep = "")
        destfile <- file.path(destdir, paste(GEO, ".soft.gz", 
            sep = ""))
    }
    if (geotype == "GSE" & amount != "full" & amount != "table") {
        gseurl <- "http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi"
        myurl <- paste(gseurl, "?targ=self&acc=", GEO, "&form=text&view=", 
            amount, sep = "")
        destfile <- file.path(destdir, paste(GEO, ".soft", sep = ""))
        mode <- "w"
    }
    if (geotype == "GPL") {
        gseurl <- "http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi"
        myurl <- paste(gseurl, "?targ=self&acc=", GEO, "&form=text&view=", 
            amount, sep = "")
        destfile <- file.path(destdir, paste(GEO, ".soft", sep = ""))
        mode <- "w"
    }
    if (geotype == "GSM") {
        gseurl <- "http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi"
        myurl <- paste(gseurl, "?targ=self&acc=", GEO, "&form=text&view=", 
            amount, sep = "")
        destfile <- file.path(destdir, paste(GEO, ".soft", sep = ""))
        mode <- "w"
    }
    download.file(myurl, destfile, mode = mode, quiet=TRUE)
   # writeLines("File stored at: ")
    writeLines(destfile)
    invisible(destfile)
}


# GSExxx, Series
GseToGct <- function(geo.query=NULL, data.column.name='VALUE', 
					gct.output.filename=NULL, description.column=2) {
	gse <- geo.query
	# ABS_CALL
	probesets <- Table(GPLList(gse)[[1]])$ID
	data.matrix <- do.call("cbind", lapply(GSMList(gse), function(x) {
	tab <- Table(x)
		mymatch <- match(probesets, tab$ID_REF)
		return(tab[,data.column.name][mymatch])
	}))
	row.names(data.matrix) <- probesets
	desc <- NULL
	if(!is.null(description.column)) {
		desc <- get.ids.from.gpl(gse, description.column)
	}
	gct <- list(data=data.matrix, row.descriptions=desc)
	write.gct(gct, gct.output.filename)
}

# GDSxxx, Dataset, e.g. GDS1
GdsToGct <- function(geo.query=NULL, gct.output.filename, description.column=2) {
	gds <- geo.query
	eset <- GDS2eSet(gds, do.log2 = FALSE)
	desc <- NULL
	if(!is.null(description.column)) {
		desc <- get.ids.from.gpl(gds, description.column)
	}
	gct <- list(data=eset@exprs, row.descriptions=desc)
	write.gct(gct, gct.output.filename)
}

# GPLXX
get.ids.from.gpl <- function(geo, column) {
	gpl.id <- Meta(geo)$platform
	gcp <- try(
		gpl <- getGEO(GEO=gpl.id)
	)
	if(class(gpl)=="try-error") {
		return(NULL)
	}
	ret <- try (
		as.character(Table(gpl)[,column])
	)
	if(class(ret)=="try-error") {
		return(NULL)
	}	
   ret
}

install.required.packages <- function(libdir) {
	if(!is.package.installed(libdir, "GEOquery")) {
		install.package(libdir, "GEOquery_1.6.0.zip", "GEOquery_1.6.0.tar.gz", 
			"GEOquery_1.6.0.tar.gz")
	}
	
	if(!is.package.installed(libdir, "Biobase")) {
		install.package(libdir, "Biobase_1.5.0.zip", "Biobase_1.5.0.tgz", 
			"Biobase_1.5.0.tar.gz")
	}
}

run <- function(libdir, ...) {
	options("warn"=-1)
	source(paste(libdir, "common.R", sep=''))
	setLibPath(libdir)
	install.required.packages(libdir)
	
	library(GEOquery)
	args <- list(...)
	geo.id <- NULL
	filename <- NULL
	data.column.name <- 'VALUE'
	gct.output.filename <- NULL
	description.column <- 2
	options(internet.info="3")
	for(i in 1:length(args)) {
		flag <- substring(args[[i]], 0, 2)
		value <- trim(substring(args[[i]], 3, nchar(args[[i]])))
		if(value=='') {
			next
		}
		if(flag=='-g') {
			geo.id <- value
		} else if(flag=='-f') {
			filename <- value
		} else if(flag=='-d') {
			data.column.name <- value
		} else if(flag=='-o') {
			gct.output.filename <- value
		} 
	}
	
	if(is.null(geo.id) && is.null(filename)) {
		exit("Either a GEO accession or a GEO SOFT file must be specified.")
	}
	geo.query <- getGEO(GEO=geo.id, filename=filename)
	
	if (class(geo.query) == "GSE") {
		GseToGct(geo.query=geo.query, data.column.name=data.column.name, 
			gct.output.filename=gct.output.filename, 
			description.column=description.column)
	} else if (class(geo.query) == "GDS") {
		GdsToGct(geo.query=geo.query, gct.output.filename=gct.output.filename, 
			description.column=description.column)
	} else {
		exit("Can only retrieve data for GEO Datasets and GEO Series")
	}
}




