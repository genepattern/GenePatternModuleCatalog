setup <- function(libdir) {
	source(paste(libdir, "common.R", sep=''))
	setLibPath(libdir)
	install.required.packages(libdir)
   library(rpart, verbose=FALSE)
}

trim <- function(s) {
	sub(' +$', '', s, extended = TRUE)
}

cartCmdLine <- function(...) {
	suppressMessages(.cartCmdLine(...))
}

.cartCmdLine <- function(...) {
	train.data.file <- ''
	train.cls.file <- ''
	test.data.file <- ''
	test.cls.file <- ''
	pred.results.file.name <- ''
	pdf.file.name <- ''
	model.file.name <- ''
	libdir <- ''
	saved.model.file <- ''

	args <- list(...)
	for(i in 1:length(args)) {
		flag <- substring(args[[i]], 0, 2)
		value <- substring(args[[i]], 3, nchar(args[[i]]))
		if(value=='') {
			next
		}

		if(flag=='-t') {
			train.data.file <- value
		} else if(flag=='-c') {
			train.cls.file <- value
		}  else if(flag=='-e') {
			test.data.file <- value
		}  else if(flag=='-f') {
			test.cls.file <- value
		}  else if(flag=='-r') {
			pred.results.file.name <- value
		} else if(flag=='-p') {
			pdf.file.name <- value
		} else if(flag=='-m') {
			model.file.name <- value
		} else if(flag=='-l') {
			libdir <- value
		} else if(flag=='-s') {
			saved.model.file <- value
		} else {
			stop("Unknown option")
		}
	}
	return(cart(train.data.file, train.cls.file, saved.model.file,
                  test.data.file,test.cls.file, pred.results.file.name,
                  pdf.file.name, model.file.name, libdir))
}

cart <- function(train.data.file, train.cls.file, saved.model.file,
                  test.data.file,test.cls.file, pred.results.file.name,
                  pdf.file.name, model.file.name, libdir) {
   test <- TRUE
   if(test.cls.file=='' || test.data.file=='') {
      test <- FALSE
   }
   if(train.data.file!='' && saved.model.file!='') {
      cat("Both training data and a saved model given - using saved model.\n")
   }

   if(saved.model.file=='' && (train.data.file=='' || train.cls.file=='')) {
      stop("Either a saved CART model or training data must be provided.\n", call.=FALSE)
   }

	setup(libdir)

   if(saved.model.file=='') {
      data <- read.dataset(train.data.file)$data
      cls.obj <- read.cls(train.cls.file)
      cls <- cls.obj$labels
      class.names <- cls.obj$names

      if(length(cls)!=NCOL(data)) {
         stop("Number of samples in test cls file does not match the number of samples in training data\n", call.=FALSE)
      }
      t.data <- t(data)
      t.data <- as.matrix(t.data)
      m <- rpart (cls  ~ t.data, list (t.data,cls))
      save(cls, t.data, file=model.file.name) # save the model
   } else {
   	if(!test) {
      	 stop("Test data must be provided when a saved model is used.\n", call.=FALSE)
      }
      load(saved.model.file)
      m <- rpart (cls  ~ t.data, list (t.data,cls))

   }

   if(test) {
      t.data <- read.dataset(test.data.file)$data
      t.data <- t(t.data)

      p <- predict (m, list(t.data), type='class')
      result <- regexpr(paste(".pdf","$",sep=""), tolower(pdf.file.name))
      if(result[[1]] == -1) { # append .pdf file extension if it doesn't exist
         pdf.file.name <- paste(pdf.file.name, ".pdf", sep="")
      }

		test.cls.obj <- read.cls(test.cls.file)
      test.cls <- test.cls.obj$labels
      if(!exists("class.names")) {
   		class.names <- test.cls.obj$names
   	}

      num.errors <- sum(p!=test.cls)
      write.pred.results(p,  num.errors, t.data, test.cls, class.names, length(m$index), pred.results.file.name)
		pdf(pdf.file.name, width=8.5, height=11)
    	plot(m)
    	text(m, use.n = TRUE)
    	dev.off()
   }
   return('')
}

runCartCV <- function(data.file, cls.file, pred.results.file.name, libdir) {
	setup(libdir)

	data <- read.dataset(data.file)$data
	cls.obj <- read.cls(cls.file)
   cls <- cls.obj$labels
   class.names <- cls.obj$names

	if(length(cls)!=NCOL(data)) {
		stop("number of samples in cls file does not match the number of samples in data file", call.=FALSE)
	}
	t.data <- t(data)
	t.data <- as.matrix(t.data)
    cart.cv(t.data, cls, class.names, pred.results.file.name)
}

# data transposed dataset
# cls factor
cart.cv <- function(t.data, cls, class.names, pred.results.file.name) {
    cv.fold <- NROW(t.data)

     # random.samples <- sample(1:dim(t.data)[1])
    #  subsets <- split (random.samples, 1:cv.fold)
      cv.errors <- 0
      result.pred <- matrix (nrow=dim(t.data)[1], ncol=4,
                           dimnames = list (NULL, c('Actual','Predicted','Confidence', 'Correct?')))

   #  feature2count <- list()

	info("cv")
	num.errors <- 0
    for (i in 1:cv.fold) {
        rows <- setdiff (1:dim(t.data)[1], i)
        data <- t.data [rows,] # training data (leave out sample i)
        train.cls <- cls [rows]
        info(train.cls)
        info(paste("levels", levels(train.cls)))
		m <- rpart (train.cls  ~ data, list (data,train.cls))

        data <- rbind (t.data[i,])

        p <- predict (m, list(data), type='class')

    #   p <- predict (m, predict.data.envelope(data), type='class')  # predict on test data

        result.pred [i,'Actual'] <- class.names[cls[i]]
        result.pred [i,'Predicted'] <- class.names[p]

        if (p == cls[i]) {
           result.pred[i,'Correct?'] <- "true"
        } else {
           result.pred[i,'Correct?'] <- "false"
           num.errors <- num.errors + 1
        }
    }
   	info(result.pred)
	write.pred.results(result.pred, num.errors, t.data, cls, class.names, length(m$index), pred.results.file.name)
}

# p factor of predicted classes (from train/test) or matrix of results (from cv)
# t.data transposed train data
# cls a factor of the training class assignments
# class.names a vector of class names for the cls factor. class.names[cls[i]] gives the name for the ith assignment
# num.features features used for prediction or '' if unknown

write.pred.results <- function(p, num.errors, t.data, cls, class.names, num.features, pred.results.file.name) {
   result <- regexpr(paste(".odf","$",sep=""), tolower(pred.results.file.name))
	if(result[[1]] == -1) { # append .odf file extension if it doesn't exist
		pred.results.file.name <- paste(pred.results.file.name, ".odf", sep="")
	}
	num.rows <- NROW(t.data)

	output.file <- file(pred.results.file.name, "w")
	on.exit(close(output.file))
	cat("ODF 1.0", "\n", file=output.file, append=TRUE)


	if(num.features!='') {
	   cat("HeaderLines=8", "\n", file=output.file, append=TRUE)
    } else {
        cat("HeaderLines=7", "\n", file=output.file, append=TRUE)
    }

	cat("COLUMN_NAMES:	Samples	True Class	Predicted Class	Confidence	Correct?", "\n", file=output.file, append=TRUE)
	cat("COLUMN_TYPES:	String	String	String	float	boolean", "\n", file=output.file, append=TRUE)
	cat("Model=Prediction Results", "\n", file=output.file, append=TRUE)
	cat("PredictorModel= Classification And Regression Tree", "\n", file=output.file, append=TRUE)
	if(num.features!='') {
	   cat("NumFeatures=", num.features, "\n", file=output.file, sep='', append=TRUE)
	}
	cat("NumCorrect=",file=output.file, append=TRUE)
	cat(num.rows-num.errors, "\n", file=output.file, append=TRUE)
	cat("NumErrors=", num.errors, "\n", sep='', file=output.file, append=TRUE)
	cat("DataLines=", num.rows, "\n", sep='', file=output.file, append=TRUE)

	for(i in 1:num.rows) {
		row.name <- row.names(t.data)[i]
		cat(row.name, file=output.file, append=TRUE)
		cat("\t", file=output.file, append=TRUE)

		if(class(p)=="matrix") {
			cat(p[i,'Actual'], file=output.file, append=TRUE)
			cat("\t", file=output.file, append=TRUE)

        	cat(p[i,'Predicted'], file=output.file, append=TRUE)
        	cat("\t", file=output.file, append=TRUE)

        	cat("1", file=output.file, append=TRUE) #  confidence
			cat("\t", file=output.file, append=TRUE)

			cat(p[i,'Correct?'], file=output.file, append=TRUE)
			cat("\n", file=output.file, append=TRUE)

		} else {

			cat(class.names[cls[i][[1]]], file=output.file, append=TRUE) # true class
			cat("\t", file=output.file, append=TRUE)

			cat(class.names[p[i][[1]]], file=output.file, append=TRUE) # predicted class
			cat("\t", file=output.file, append=TRUE)
			cat("1", file=output.file, append=TRUE) #  confidence
			cat("\t", file=output.file, append=TRUE)
			if(cls[i]==p[i]) { # prediction correct?
				cat("true", file=output.file, append=TRUE);
			} else {
				cat("false", file=output.file, append=TRUE);
			}
			cat("\n", file=output.file, append=TRUE)
		}
	}


}

tree.varimp <- function (fit, data, cls) {
  # determines variable importance and ranks attributes in 'data' based on
  # the decision tree in 'fit';
  # use surrogate splits for variable ranking as described in Sec. 5.3.4
  # (pp. 146) in the CART book


  subset.node <- function (i) {
    # determines the data subset for the node i in the splits table
    var <- rownames (splits)[i]
    index <- splits[i,'index']
    L.or.R <- splits[i,'ncat']
    subset.this <- data[,var] < index
    if (L.or.R != -1) subset.this <- !subset.this
    return (subset.this)
  }


  subset.subtree <- function (i) {
    # determine the data subset at the tree node represented by the
    # i-th row in frame
    if (i==1) {
      subset.i <- rep(TRUE,dim(data)[1])
      return (subset.i)
    } else {
      node.n <- as.numeric (rownames(frame)[i])
      parent <- match ( trunc(node.n/2), rownames(frame) )
      subset.temp <- subset.node (frame$index[parent])
      if ( trunc(node.n/2) == node.n/2 ) subset.this <- subset.temp  # left split
      else subset.this <- !subset.temp                               # right split
      subset.i <- subset.subtree(parent) & subset.this
      return (subset.i)
    }
  }


  impurity <- function (cls) {
    # computes the impurity i(t) of the node represented by the
    # class vector cls
    # (pp. 27) in the CART book
    N.jt <- unlist ( lapply (levels(cls), function (l) { sum (cls==l) }) )   # Nj(t), pg. 28
    p.jt <- aprior * N.jt / N.j           # p(j,t)
    p.t <- sum (p.jt)                     # p(t) = SUM_j p(j,t)
    p.j.t <- p.jt / p.t                   # p(j|t) = p(j,t) / p(t)
    i.t <- ifelse ( split.type==1, sum (1 - p.j.t^2),
                                   sum (-p.j.t * log(p.j.t), na.rm=TRUE) )
    return (i.t, p.t)
  }


  # preliminary parameters for proper variable importance computation
  prior <- fit$parms$prior
  loss <- fit$parms$loss
  split.type <- fit$parms$split
  nclass <- length (prior)
  # altered priors for dealing with losses (CART, pg. 114)
  # based on CART book, j = actual class, i = predicted class
  # loss matrix: actual in column (j = col index), pred in row (i = row index)
  aprior <- rep (NA, nclass)
  for (j in 1:nclass) aprior[j] <- prior[j] * sum (loss[,j])
  aprior <- aprior / sum(aprior)

  # counts (at root node)
  N.j <- unlist ( lapply (levels(cls), function (l) { sum (cls==l) }) )  # Nj

  # start processing surrogate splits
  splits <- fit$splits
  splits <- cbind ( splits, importance=rep(0,dim(splits)[1]) )

  frame <- fit$frame
  nc <- frame[, c('ncompete', 'nsurrogate')]
  frame$index <- 1 + c(0, cumsum((frame$var != "<leaf>") +
                                 nc[[1]] + nc[[2]]))[-(nrow(frame)+1)]
  frame$index[frame$var == "<leaf>"] <- 0

  var.imp <- NULL
  for ( i in 1:dim(frame)[1] ) {
    if ( frame$index[i] == 0 ) next   # skip leaf nodes
    parent <- trunc ( as.numeric(rownames(frame)[i]) / 2)
    subset.t <- subset.subtree (i)
    cls.t <- cls [ subset.t ]
    imp <- impurity(cls.t)
    i.t <- imp$i.t
    p.t <- imp$p.t

    this <- frame$index[i]
    ncompete <- frame$ncompete[i]
    nsurrogate <- frame$nsurrogate[i]
    if (nsurrogate > 0) {
      # if any surrogates exist ...
      surrogates <- c (this, this+(ncompete)+(1:nsurrogate))
      for (s in surrogates) {
        subset.this <- subset.node(s)
        cls.tL <- cls [ subset.t & subset.this ]
        i.tL <- impurity(cls.tL)$i.t
        p.L <- length(cls.tL) / length(cls.t)
        cls.tR <- cls [ subset.t & !subset.this ]
        i.tR <- impurity(cls.tR)$i.t
        p.R <- length(cls.tR) / length(cls.t)
        splits [s, 'importance'] <- (i.t - p.L * i.tL - p.R * i.tR) * p.t
        var.imp <- rbind ( var.imp, c (rownames(splits)[s], splits[s,'importance']) )
      }
    }
  }

  var.imp.final <- data.frame ( var.imp = cbind (sort ( by(as.numeric(var.imp[,2]),
                                                        var.imp[,1], sum), decreasing=TRUE )) )
  return (var.imp.final, splits)
}


DEBUG <<- FALSE


install.required.packages <- function(libdir) {
	if(!is.package.installed(libdir, "rpart")) {
		info("installing rpart")
		install.package(libdir, "rpart_3.1-36.zip", "rpart_3.1-36.tgz", "rpart_3.1-36.tar.gz")
	}
}

