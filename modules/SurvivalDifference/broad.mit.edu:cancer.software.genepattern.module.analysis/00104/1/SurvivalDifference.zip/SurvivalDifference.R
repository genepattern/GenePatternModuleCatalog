message <- function (..., domain = NULL, appendLF = TRUE) {

}

#################################################################
# SurvivalDifference.R (ver.1.0)        Apr.29, 2007
#
#     Survival difference test based on .cls file
#     Yujin Hoshida (Broad Institute)
#################################################################

### SurvivalDifference (Main) ###

SurvivalDifference <- function(
  input.surv.data.filename,
  input.cls.filename,

  time.field="time",
  censor.field="status",
  cls.field="NA",

  test.type=0,   #0: log-rank or Mantel-Haenszel test
                 #1: Peto & Peto modification of the Gehan-Wilcoxon test
  subgroup="NA",

  outputSurvDiff.file="SurvivalDifferenceTest.txt"
  )
{

  # Redefine numeric inputs for GP

  test.type<-as.numeric(test.type)

  # read input files

   result <- regexpr(paste(".txt","$",sep=""), tolower(input.surv.data.filename))
  if(result[[1]] == -1)
    stop("Invalid survival input file: ", input.surv.data.filename)
   
  surv.data<-read.delim(input.surv.data.filename,header=T)
  
  if(input.cls.filename != '-c')
  {
    input.cls.filename <- substring(input.cls.filename, 3, nchar(input.cls.filename))
    result <- regexpr(paste(".cls","$",sep=""), tolower(input.cls.filename))
    if(result[[1]] == -1)
        stop("Invalid class file: ", input.cls.filename)  

    cls<-as.vector(t(read.delim(input.cls.filename,header=F,sep=" ",skip=2)))
    cls.label <- as.vector(rownames(table(cls)))
  }
  else if (cls.field != "-f" && cls.field != "NA")
  {
    if(cls.field =="")
        stop("You must provide either a cls file or a cls field parameter")

    cls.field <- substring(cls.field, 3, nchar(cls.field))
    eval(parse(text=paste("cls <- as.vector(surv.data$",cls.field,")",sep="")))

    if(is.null(cls))
        stop(paste("Invalid cls field: ", cls.field))

    cls.label <- as.vector(rownames(table(cls)))
  }
  else
    stop("You must provide either a cls file or a cls field parameter")

  num.cls<-length(table(cls))

  if(length(surv.data[,1])!=length(cls)){
    stop("### Survival data and class file don't match! ###")
  }

  surv.data <- cbind(surv.data,cls)

  eval(parse(text=paste("time <- surv.data$",time.field,sep="")))
  eval(parse(text=paste("status <- surv.data$",censor.field,sep="")))
  time <- as.numeric(time)
  status <- as.numeric(status)
  if (length(time)!=length(status)){
    stop("### Check naes for survival time & censor! ###")
  }

  # load "survival" package

  require(splines,quietly=T)
  require(survival,quietly=T)

  ## Survival difference test

  if (subgroup!="NA" && subgroup != "-gr"){

    subgroup <- substring(subgroup, 4, nchar(subgroup))

    subgroup<-unlist(strsplit(subgroup,", "))

    num.subgroup<-length(subgroup)

    combined.cls <- vector(length=0,mode="character")
    combined.time <- vector(length=0,mode="numeric")
    combined.status <- vector(length=0,mode="numeric")

    for (i in 1:num.subgroup){
      each.cls<-cls[which(cls==subgroup[i])]
      each.time <- time[which(cls==subgroup[i])]
      each.status <- status[which(cls==subgroup[i])]

      combined.cls<-c(combined.cls,each.cls)
      combined.time<-c(combined.time,each.time)
      combined.status<-c(combined.status,each.status)
    }

    combined.set <- as.data.frame(cbind(combined.cls,combined.time,combined.status))
    survdiff.out <- survdiff(Surv(as.numeric(combined.time),as.numeric(combined.status))~combined.cls,combined.set,rho=test.type)
  }
  else{
    survdiff.out<-survdiff(Surv(time,status)~cls, data=surv.data,rho=test.type)
  }

  # output
  
  if (test.type==0){
    title<-"#  log-rank (Cox-Mantel-Haenzel) test"
  }
  if (test.type==1){
    title<-"#  Peto & Peto modification of the Gehan-Wilcoxon test"
  }

  outputSurvDiff.file <-  paste(outputSurvDiff.file, "_SurvivalDifferenceTest.txt", sep="")


  write.table(title,outputSurvDiff.file,quote=F,sep="\t",row.names=F,col.names=F)
  write.table("",outputSurvDiff.file,quote=F,sep="\t",row.names=F,col.names=F,append=T)
  write.table(capture.output(survdiff.out),outputSurvDiff.file,quote=F,sep="\t",row.names=F,col.names=F,append=T)

} # end of main
