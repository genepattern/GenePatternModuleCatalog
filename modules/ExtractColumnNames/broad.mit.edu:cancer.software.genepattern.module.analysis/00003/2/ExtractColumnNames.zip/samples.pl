#!usr/bin/perl

#$input = "../GCM/data/GCM_Total.res";

if (@ARGV == 2){
	$input = @ARGV[0];
	$output = @ARGV[1];
	}
else {
	die "Not all arguments supplied!\n";
	}

unless ($input =~ /.res/){
	die "Input isn't a .res file!\n";
	}

$count = 0;

open (IN, $input) || die "Can't open input file\n";
$output = ">" . "$output";
if(!($output =~ /.txt/)) {
	$output = $output .".txt";	
}
open (OUT, $output) || die "Can't make output file\n";
while (<IN>) {
	if (/^Description\tAccession/){
		chomp;
                @line = split (/\t/);
                ($header, $header, @description) = @line;
		last;
		}
	else {
		die "Not a .res file!\n";
		}
        }
close (IN) || die "Can't close input file!";

foreach (@description){
        if ($_){
                $count++;
                print OUT "$count\t$_\n";
	        }
	}

close (OUT) || die "Can't close output file!\n";
