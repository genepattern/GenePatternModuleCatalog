#!/usr/bin/perl

#$grp = "../GCM/target_lists/D1_21.grp";

if (@ARGV == 3){
        $input = @ARGV[0];
        $grp = @ARGV[1];
        $output = @ARGV[2];
        }
else {
        die "Not all arguments supplied!\n";
        }

unless ($input =~ /.pol$/){
        die "Input isn't a .pol file!\n";
        }


if ($grp =~ /.tag$/){
        open (TARGETS, $grp) || die "Can't open .tag file!\n";
        while (<TARGETS>){
		($acc) = split (/\t/);
                push (@targets, $acc);
        }
		  close (TARGETS) || die "Can't close .tag file!\n";
} else { # if ($grp =~ /.grp$/){
	open (TARGETS, $grp) || die "Can't open .grp file!\n";
	while (<TARGETS>){
		chomp;
        	push (@targets, $_);
	}
	close (TARGETS) || die "Can't close .grp file!\n";
}

	
$numberoftargets = @targets;

open (POL, $input) || die "Can't open input .pol file!\n";
while (<POL>){
	chomp;
	$countGCM++;
        @line = split (/\t/);
        ($rank, $acc, $desc, $score) = @line;
	push (@pol, $acc);
	$NAME{$acc} = substr($desc, 0, 60);
        }
close (POL) || die;

KS_analysis();


####subroutines####

format STDOUT = 
@<<<<<	@<<<<<<<<<<<<<<<<<<<	@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<	@<<<<<<<<<
$count,$nn,$NAME{$nn},$runningsum
.

sub KS_analysis{

$runningsum = 0;
$maxtarget = 0;
$mintarget = 0;

print "\n$countGCM genes in the ordered list\n";
print "$numberoftargets genes in the query gene-set\n";

$in = ($countGCM)-$numberoftargets;
$out = -$numberoftargets;

print "\npositive score is $in\n";
print "negative score is $out\n\n";

print "rank\tKS\taccession\tdescription\n";
print "------------------------------------------------------------------------------------\n";

if (!($output =~ /(.*)\.pol/)) {
	$output .= ".pol";
}

open (OUTPUT, ">$output") || die "Can't open output file!\n";
foreach $nn (@pol) {
	$count++;
        foreach $test (@targets){
                if ($nn eq $test){
			$number++;
			$runningsum += $in;
			$maxtarget = $runningsum if ($runningsum > $maxtarget);
			print "$count\t$runningsum\t$nn\t$NAME{$nn}\n";
			print OUTPUT "$number\t$nn\t$NAME{$nn}\t$count\n";
			$runningsum += $numberoftargets;
                }  
        }
	$runningsum += $out;
        $mintarget = $runningsum if ($runningsum < $mintarget);
}

close (OUTPUT) || die "Can't close output file!\n";

print "\nrunning sum at the end is $runningsum\n";
        
print "\nKS score is $maxtarget ($mintarget)\n\n";

}

