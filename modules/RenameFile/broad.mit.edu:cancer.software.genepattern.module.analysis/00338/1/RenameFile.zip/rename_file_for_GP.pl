use strict;
use warnings;

use File::Copy qw(cp);
use File::Spec;
use Getopt::Long;
use File::Basename;

my $inputFile = "";
my $outputFilename = "";
my $screenFilename = "yes";
my $forceCopy = "no";
my $result = GetOptions ("inputFile:s"            => \$inputFile,
                         "outputFilename:s"       => \$outputFilename,
                         "screenFilename:s"       => \$screenFilename,
                         "forceCopy:s"            => \$forceCopy
                         );

# Disallow operating on directories.  We don't want to deal with the question of recursively descending the
# tree: should the child files/dirs be copied as well?  Should they just be links or always be copies?  No,
# not dealing with this for now.  Can revisit later, but I suspect that there will be an improvement in GP
# before this is a real issue.
my $fullPath = File::Spec->canonpath($inputFile);
wr_die("RenameFile does not work on directories") if (-d $fullPath);

# Screen out potentially problematic characters like whitespace and shell metacharacters: -*?`'"\/><$&#:;()%^~[]!+@,
# Peter points out that some modules in the past have treated '-' as a flag indicator. 
if ($screenFilename eq "yes") {
   $outputFilename =~ s/[-*?`\'\"\/><\$&#:;()%^~[\]!+\,@\s]/_/g;
   print "After screening, filename will be '$outputFilename'.\n"
}

my $linkCreated = 0;
if ($forceCopy ne "yes") {
   $linkCreated = link "$inputFile","$outputFilename";
   print "Unable to create a hard link; trying file copy instead.\n" unless $linkCreated;
}

if (($forceCopy eq "yes") || !$linkCreated) {
   cp("$inputFile","$outputFilename") or wr_die("Copy failed: $!");
}

# More user-friendly errors than Perl's 'die' for use in the context of a wrapper script.
sub wr_die {
    print STDERR @_, "\n\n";
    exit(1);
}