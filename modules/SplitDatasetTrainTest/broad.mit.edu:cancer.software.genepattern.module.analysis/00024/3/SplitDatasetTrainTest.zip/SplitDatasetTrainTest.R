########################################################################
#                              MISCELLANEA                             #
# developed by Stefano Monti and modified by Marc-Danie Nazaire
########################################################################
setup <- function(libdir) {
	source(paste(libdir, "common.R", sep=''))
	setLibPath(libdir)
}

my.nlevels <- function( x )
{
  return( length(my.levels(x)) )
}

my.levels <- function( x, sort=T )
{
  #if ( !is.numeric(x) ) stop( "x must be numeric" )
  return( if (sort) sort(unique(as.vector(x))) else unique(as.vector(x)) )
}

setClass("resdata",
         representation(signal="matrix",
                        calls="matrix",
                        description="character",
                        scale="character"))

setClass("gctdata",
         representation(signal="matrix",
                        description="character"))

xval.select <- function( sample.size, nfolds, cls=NULL )
{
  # returns a sample.size-length vector of fold assignments (labels
  # btw 1 and nfolds). If cls is non-NULL, it carries out stratified
  # cross-validation
  #
  if ( nfolds<2 )
    stop( "nfolds should be at least 2" )
  if ( nfolds>sample.size )
    stop( "nfolds cannot be greater than sample size" )
  if ( nfolds<sample.size & sample.size%/%nfolds<2 )
    warning( "only one fold w/ multiple samples" )

  if ( nfolds==sample.size )
    return( 1:sample.size )

  if ( is.null(cls) )
  {
    fsize <- sample.size%/%nfolds
    rsize <- sample.size%%nfolds
    folds <- sample( c(rep(1:nfolds,fsize), if(rsize>0) sample(nfolds,rsize)) )
    return(folds)
  }
  else
  {
    if ( sample.size!=length(cls) )
      stop( "cls must be same length as sample size" )

    nstrata <- length( strata <- as.vector(sort(unique(cls))) )

    folds <- rep( NA, sample.size )
    for ( s in 1:nstrata )
    {
      idx <- cls==strata[s]
      if (sum(idx)==1) {
        folds[idx] <- sample(nfolds,1)
        next
      }
      folds[(1:sample.size)[idx]] <- xval.select( sum(idx), nfolds )
    }
    return(folds)
  }
}

read.res.wrapper <- function(filename, verbose = F)
{
    VERBOSE( verbose, "Reading file '", filename, "'\n", sep="" )
    result <- read.res(filename)
    
    VERBOSE( verbose, "Done reading.",  nrow(result$data), "genes x", ncol(result$data), "experiments.\n", sep=" " )
    
    return ( new( "resdata",
                 signal = result$data,
                 calls = result$calls,
                 description = result$row.descriptions,
                 scale = result$column.descriptions))
}

dim.resdata <- function( x )
{
  if ( class(x)!="resdata" )
    stop( "object does not belong to resdata class" )
  dim(x@signal)
}

write.res.wrapper <- function(res, filename=NULL, verbose = F)
{
    if ( class(res)!="resdata" )
        stop( "object does not belong to resdata class" )

    result <- list(data = res@signal,
                      calls = res@calls,
                      row.descriptions= res@description,
                      column.descriptions = res@scale)
    
    write.res(result, filename)
}

signal <- function( x )
{
  x@signal
}

genenames <- function( x )
{
  if (class(x)!="resdata" && class(x)!="gctdata") stop( "'resdata|gctdata' object expected" )
  rownames(x@signal)
}

exptnames <- function( x )
{
  if (class(x)!="resdata" && class(x)!="gctdata") stop( "'resdata|gctdata' object expected" )
  colnames(x@signal)
}

subset.resdata <- function( x, exptnames=NULL, genenames=NULL, ignore=F )
{
  if (class(x)!="resdata") stop( "'resdata' object expected" )
  if ( is.null(exptnames) && is.null(genenames) )
    stop( "either exptnames or genenames must be provided" )

  g.idx <- 1:nrow(x)
  e.idx <- 1:ncol(x)

  # sample subsetting
  #
  if ( !is.null(exptnames) )
  {
    e.idx <- match( exptnames, colnames(x@signal) )
    if ( !ignore && any(is.na(e.idx)) )
      stop( "subsetting on non-existing columns" )
    else
      e.idx <- e.idx[!is.na(e.idx)]
    if ( length(e.idx)==0 )
      stop( "empty subset to select" )
  }
  # gene subsetting
  #
  if ( !is.null(genenames) )
  {
    g.idx <- match( genenames, rownames(x@signal) )
    if ( !ignore && any(is.na(g.idx)) )
      stop( "subsetting on non-existing rows" )
    else
      g.idx <- g.idx[!is.na(g.idx)]
    if ( length(g.idx)==0 )
      stop( "empty subset to select" )
  }
  return( new("resdata",
              signal=x@signal[g.idx,e.idx,drop=F],
              calls=x@calls[g.idx,e.idx,drop=F],
              description=x@description[g.idx],
              scale=x@scale[e.idx]) )
}

merge.resdata <- function( X, Y )
{
  if (class(X)!="resdata") stop("resdata expected for X")
  if (class(Y)!="resdata") stop("resdata expected for Y")
  if ( length(expts <- intersect(exptnames(X),exptnames(Y)))>0 )
    stop("non unique experiment names: ", paste( expts, collapse=", " ), sep="")
  genes <- match(genenames(X),genenames(Y))
  if (any(is.na(genes)))   stop( "X and Y don't have the same genes" )

  new("resdata",
      signal=cbind(X@signal,Y@signal[genes,]),
      calls =cbind(X@calls,Y@calls[genes,]),
      description=X@description,
      scale=c(X@scale,Y@scale) )
}

read.gct.wrapper <- function(filename, verbose = F)
{
    VERBOSE( verbose, "Reading file", filename, "'\n", sep=" " )
    result <- read.gct(filename)

   VERBOSE( verbose, "Done reading.",  nrow(result$data), "genes x", ncol(result$data), "experiments.\n", sep=" " )

    return ( new( "gctdata",
                 signal = result$data,
                 description = result$row.descriptions))
}

dim.gctdata <- function( x )
{
  if ( class(x)!="gctdata" )
    stop( "object does not belong to gctdata class" )
  dim(x@signal)
}

write.gct.wrapper <- function(gct, filename, verbose = F)
{
    if ( class(gct)!="gctdata" )
        stop( "object does not belong to gctdata class" )

    result <- list(data = gct@signal,
                      row.descriptions= gct@description)

    write.gct(result, filename)
}

subset.gctdata <- function( x, exptnames=NULL, genenames=NULL, ignore=F )
{
  if (class(x)!="gctdata") stop( "'gctdata' object expected" )
  if ( is.null(exptnames) && is.null(genenames) )
    stop( "either exptnames or genenames must be provided" )

  g.idx <- 1:nrow(x)
  e.idx <- 1:ncol(x)

  # sample subsetting
  #
  if ( !is.null(exptnames) )
  {
    e.idx <- match( exptnames, colnames(x@signal) )
    if ( !ignore && any(is.na(e.idx)) )
      stop( "subsetting on non-existing columns" )
    else
      e.idx <- e.idx[!is.na(e.idx)]
    if ( length(e.idx)==0 )
      stop( "empty subset to select" )
  }
  # gene subsetting
  #
  if ( !is.null(genenames) )
  {
    g.idx <- match( genenames, rownames(x@signal) )
    if ( !ignore && any(is.na(g.idx)) )
      stop( "subsetting on non-existing rows" )
    else
      g.idx <- g.idx[!is.na(g.idx)]
    if ( length(g.idx)==0 )
      stop( "empty subset to select" )
  }
  return( new("gctdata",
              signal=x@signal[g.idx,e.idx,drop=F],
              description=x@description[g.idx]) )
}

subset.data <- function( x, exptnames=NULL, genenames=NULL, ignore=F )
{
  if (class(x)=="gctdata") {
    return( subset.gctdata(x, exptnames=exptnames, genenames=genenames, ignore=ignore) )
  }
  else if (class(x)=="resdata") {
    return( subset.resdata(x, exptnames=exptnames, genenames=genenames, ignore=ignore) )
  }
  else stop( "unrecognized data format" )
}

read.data.gp <- function( filename, verbose=F )
{
  file.test( filename )
  ext <- file.ext( filename )

  VERBOSE( verbose, "  Reading data ..\n" );

  VERBOSE( verbose, "\tFile extension: '.", ext, "'.\n", sep="" )

  result <- switch( ext,
                 res=read.res.wrapper( filename, verbose = verbose),
                 gct=read.gct.wrapper( filename, verbose = verbose ),
                 stop("unrecognized file extension: ", ext) )
}

write.data.gp <- function( data, filename, verbose=F )
{
  #file.test( filename, mode=2 )
  ext <- file.ext(filename)

  VERBOSE(verbose, "  Writing data to file '", filename, "' ..", sep="");
  if ( class(data)=="resdata" ) {
    if ( ext!="res" ) warning( "improper extension for res file: ", ext )
    write.res.wrapper( data, filename, verbose=verbose )
  }
  else if ( class(data)=="gctdata" ) {
    if ( ext!="gct" ) warning( "improper extension for gct file: ", ext )
    write.gct.wrapper( data, filename, verbose=verbose )
  }
  else {
    stop( "unsupported data format: ", class(data) )
  }
  VERBOSE(verbose, "done.\n" )
}

read.cls.wrapper <- function(filename, verbose = F)
{
    result <- read.cls(filename)

    cls <- result$labels

    VERBOSE( verbose, "class names: ", paste(levels(cls), collapse=", "), "\n" )

    return(cls)
}

write.cls.wrapper <- function( cls, filename )
{
    names <- levels(cls)

    result <- list(labels = cls, names = names)
    write.cls( result, filename)
}

subset.cls <- function( cls, sub )
{
   levs <- if (is.null(levels(cls))) sort(unique(cls)) else levels(cls)
   cls1 <- cls[sub]  

   cls1.lev <- levs[match(sort(unique(cls1)), sort(unique(cls)))]
   #cls1 <- match(cls1,unique(cls1))-1
  
   #levels(cls1) <- cls1.lev
   cls1 <- factor(cls1, levels = cls1.lev)

   cls1
}

subset.all <- function( dat, cls, subfile=NULL, subset=NULL, verbose=F )
{
  if ( is.null(subset) && is.null(subfile) )
    stop( "subset or subfile must be specified" )

  VERBOSE( verbose, "Extracting sample subset " )
  if ( !is.null(subfile) ) {
    VERBOSE( verbose, "from '", subfile, "' .. ", sep="" )
    subset <- read.table( subfile, sep="\t", header=F )[,1]
  }
  s.idx <- match( subset, exptnames(dat) )
  if ( any(is.na(s.idx)) ) stop( "subset contains unmatched samples" )
  dat <- subset.data( dat, exptnames=subset )
  cls <- subset.cls( cls, s.idx )
  VERBOSE( verbose, "done, [", paste(dim(dat),collapse=" x "), "] data entries.\n", sep="" )
  list( data=dat, cls=cls )
}

VERBOSE <- function( v, ... )
{
  if ( v ) cat( ... )
}

my.write.matrix <- function ( x, file = "", sep = "\t",
                              col.names=T,
                              append=F,
                              row.names=F,
                              justify = c( "none", "left", "right"),
                              pval=NULL,
                              newline="\n",
                              names=NULL )
{
  justify = match.arg( justify )
  x <- as.matrix(x)
  p <- ncol(x)
  cnames <- colnames(x)
  rnames <- rownames(x)

  if ( !is.null(pval) ) {
    x[,pval] <- format.pval( as.numeric(x[,pval]) )
  }
  if ( col.names && !is.null(cnames) )
  {
    x <- format(rbind( cnames, x ), justify=justify)
  }
  if ( row.names )
  {
    p <- p+1
    if ( col.names && !is.null(cnames) ) {
      rnames <- if (is.null(names)) c("",rnames) else c(names, rnames)
    }
    x <- cbind( format(rnames,justify=justify), x )
  }
  cat( t(x), file=file, sep=c(rep(sep,p - 1), newline), append=append )
}
cv <- function(x,mad=F)
{
  if ( is.matrix(x) )
    apply( x, 2, cv, mad=mad )
  else if ( is.vector(x) ) {
    m <- abs( if ( mad ) median(x) else drop(fast.mean(x)))
    if ( m==0 ) stop( "mean(x) is 0" )
    s <- if ( mad ) mad(x) else drop(fast.sd(x))
    s/m
  }
  else if (is.data.frame(x))
    sapply(x, cv, mad=mad )
  else cv(as.vector(x),mad=mad)
}

file.ext <- function( filen )
{
  rev(unlist(strsplit( filen, "\\.")))[1]
}

file.test <- function( filen, mode=4, string=NULL, nostop )
{
  action <- c("exist","execute","write","","read")[mode+1]
  if ( file.access(filen,mode)[1]!=0 )
    stop( if (is.null(string)) paste("cannot ",action," file '",filen,"'",sep="") else string )
  else
    return( T )
}

########################################################################
#                              MAIN                                    #
########################################################################

my.sample <- function(x, size, strata=NULL, replace=F, prob=NULL)
{
  if ( is.null(strata) )
    return( sample(x, size, replace, prob) )

  # ELSE ..
  #
  if (length(x)==1) x <- 1:x
  if (missing(size)) size <- length(x)
  if ( length(strata)!=length(x) )
    stop( "strata must be same length as x" )

  idx <- lapply( unique(strata), function(z) which(strata==z) )
  nidx <- sapply( idx, length )
  if (sum(nidx)!=length(strata))
    stop("sum(nidx)!=length(strata)")

  if (size<length(x)) {
    idx2 <- nidx<=2

    nidx <- nidx * (size)/sum(nidx)
   
    nidx[idx2][nidx[idx2]<1] <- 1

    if ( length(idxUP <- which(nidx!=floor(nidx)))>0 ) # handling of fractional samples
    {
      sum.nidx <- round(sum(nidx-floor(nidx)))
      nidxUP <- sample(idxUP, sum.nidx)

      nidx[nidxUP] <-  ceiling(nidx[nidxUP])
      nidx[-nidxUP] <- floor(nidx[-nidxUP])
    }
    if (any(nidx==0))
      stop( "some strata have 0 sample size" )
  }

  S <- NULL
  for ( i in 1:length(idx) )
  {
    S <- c(S,sample(idx[[i]],size=nidx[i],replace=replace))
  }

  return(S)
}

train.test.split <- function(ssize, cls=NULL, nfolds=1, method=c("random","CV"),
                             split=0.5, seed=NULL)
{
  method <- match.arg(method)
  if (method=="CV" && nfolds>ssize)
    stop( "with cross-validation (CV), the number of splits cannot be greater than number of samples: ",nfolds)
  if (method=="CV" && nfolds<2)
    stop( "with cross-validation (CV), the number of splits cannot be less than 2: ", nfolds)

  splits <- matrix( 0, nfolds, ssize )
  if ( method=="CV" ) {
    folds <- xval.select( sample.size=ssize, nfolds=nfolds, cls=cls )
    for ( i in 1:nfolds )
      splits[i,folds==i] <- 1
  }
  else if ( method=="random" )
  {
    tsize <- floor(ssize * split)

    for ( i in 1:nfolds ) {
      idx <- my.sample(x=ssize, size=tsize, strata=cls)
      splits[i,-idx] <- 1
    }
  }
  else {
    stop( "unrecognized split method: ", method )
  }
  return( splits )
}

parseCmdLine <- function(input.filename,
                                 cls.filename,
                                 out.stub,
                                 method=c("random","CV"),
                                 stratified=T,
                                 nfolds=1,
                                 seed=NULL,
                                 libdir, split=NULL) {
                                 
     split.dataset.train.test(input.filename=input.filename,
                                 cls.filename=cls.filename,
                                 out.stub=out.stub,
                                 method=method,
                                 stratified=stratified,
                                 nfolds=nfolds,
                                 seed=seed,
                                 libdir=libdir, 
                                 split=split)                           
}

split.dataset.train.test <- function(input.filename,
                                 cls.filename,
                                 out.stub,
                                 method=c("random","CV"),
                                 stratified=T,
                                 split=0.5,
                                 nfolds=1,
                                 seed=NULL,
                                 libdir)
{
    setup(libdir)
    verbose <- F

    if(is.null(split))
        stop("Missing value for percentage split proportion")

    split <- as.numeric(split)
    if( method == "random" && (split >= 1 || split <= 0))
    {
        stop("split parameter must be less than 1 and greater than 0")
    }

    nfolds <- as.numeric(nfolds)
    if(nfolds <= 0)
    {
        stop("nfold parameter must be greater than 0")
    }

    stratified <- as.logical(stratified)
    if(!is.null(seed)) seed <- as.numeric(seed)
    set.seed(seed)
    method <- match.arg(method)

    DAT <- read.data.gp( input.filename )
    CLS <- read.cls.wrapper( cls.filename )
    strata <- if (stratified) CLS <- as.factor(CLS)

    classCount <- sapply( unique(CLS), function(x) which(CLS==x) )
    classCount <- sapply( classCount, length )

    num.classes <- length(unique(CLS))

    if(ncol(DAT) != length(CLS))
        stop("Number of samples in cls file does not match the number of samples in dataset")

    splits <- train.test.split(ncol(DAT),cls=strata,method=method,split=split, nfolds=nfolds, seed=seed)

    ext <- file.ext(input.filename)

    VERBOSE( verbose, "Writing train/test sets to files\n" )
    for ( i in 1:nfolds )
    {
        trn.idx <- which( splits[i,]==0 )
        trn.dat <- subset.data( DAT, exptnames=exptnames(DAT)[trn.idx] )
        trn.cls <- subset.cls( CLS, trn.idx )
        trn.stub <-  paste( out.stub, "train", i-1, sep="." )
        dat.name <- paste( trn.stub, ext, sep=".")
        cls.name <- paste( trn.stub, "cls", sep=".")

        VERBOSE( verbose, i, ") writing ", trn.stub, ".", ext, ",cls .. ", sep="" )
        write.data.gp(trn.dat,file=dat.name, verbose=F)
        write.cls.wrapper(trn.cls,file=cls.name)
        VERBOSE( verbose, "done.\n" )

        tst.dat <- subset.data( DAT, exptnames=exptnames(DAT)[-trn.idx] )
        tst.cls <- subset.cls( CLS, -trn.idx )

        tst.stub <-  paste( out.stub, "test", i-1, sep="." )
        dat.name <- paste( tst.stub, ext, sep=".")
        cls.name <- paste( tst.stub, "cls", sep=".")

        VERBOSE( verbose, i, ") writing ", tst.stub, ".", ext, ",cls .. ", sep="" )
        write.data.gp(tst.dat,file=dat.name, verbose=F)
        write.cls.wrapper(tst.cls,file=cls.name)
        VERBOSE( verbose, "done.\n" )
   }
}