# Splits a dataset into train and test subsets

use POSIX;
use Getopt::Std;
getopt('FrtTncO');

# Defaults:

$res_file = "NULL"; # Res file with train expression data
$res_file = $opt_F if defined($opt_F);

if (defined($opt_c)) {
    $cls_file = $opt_c;
    $cls_flag = 1;
    print "cls file = $cls_file \n";
} else {
    $cls_flag = 0;
}

$file_format = 1; 
$file_format = $opt_r if defined($opt_r); # Test files is in res format (default). The other format supported is gct.

$fraction_train =  0.666; # 
$fraction_train = $opt_t if defined($opt_t);

$fraction_test =  1.0-fraction_train; # 
$fraction_test = $opt_T if defined($opt_T);

$num_splits =  1; # number of splits (default 1)
$num_splits = $opt_n if defined($opt_n);

$output_name_prefix =  "DEFAULT"; # Use input name
$output_name_prefix = $opt_O if defined($opt_O);

print "Input file= $res_file \n";
print "File format = $file_format \n";
print "Fraction/number in train set = $fraction_train \n";
print "Fraction/number in test set = $fraction_test \n";
print "Number of splits = $num_splits \n";

srand(77654);
%distance = ();

if ($res_file =~ /(.*).res/) {
    $res_name = $1;
}
if ($res_file =~ /(.*).gct/) {
    $res_name = $1;
}

if ($output_name_prefix ne "DEFAULT") {
    $res_name = $output_name_prefix;
}

print "var= $output_name_prefix \n";
print "Output file prefix= $res_name \n";

# $cls_file = "$res_name" . ".cls";

if ($cls_flag == 1) {
    if ($output_name_prefix == 0) {
	if ($cls_file =~ /(.*).cls/) {
	    $cls_name = $1;
	}
    } else {
	$cls_name = $output_name_prefix;
    }

   open(F2, "$cls_file") || die "Cannot open cls file $cls_file \n";

   # Read target classes from cls file

    $line = <F2>;
    ($num_samples, $num_classes, $num_mems) = split(" ", $line);

    print "num classes in cls file = $num_classes \n";
    chomp($line);
    @target_classes = ();
    $line = <F2>;
    $target_labels = $line;
    $line = <F2>;
    chomp($line);
    @target_classes = split(" ", $line);
    close F2;
}

# Read input dataset

@sample_names = ();
@scan_names = ();

open(F1, "$res_file") || die "Cannot open file $res_file \n";

if ($file_format == 1) { # it is in res format
    $line = <F1>;
    chomp($line);
    @data = split("\t", $line);
    $desc = shift(@data);
    $gene = shift(@data);
    $j = 0;
    while (defined($datum = shift(@data))) {
	$empty = shift(@data);
	@words = split(" ", $datum);
	$datum = join("_", @words);
	$sample_names[$j] = $datum;
	$j++;
    }
    $line = <F1>;
    chomp($line);
    @data = split("\t", $line);
    $empty = shift(@data);
    $j = 0;
    while (defined($datum = shift(@data))) {
	$empty = shift(@data);
	@words = split(" ", $datum);
	$datum = join("_", @words);
	$scan_names[$j] = $datum;
	$j++;
    }
    $line = <F1>;
    chomp($line);
    @data = split("\t", $line);
    $num_rows = shift(@data);

} else { # it is in gct format
    $line = <F1>; # release line
    @data = split("\t", $line);
    $release = shift(@data);
    $line = <F1>; # count line
    @data = split("\t", $line);
    $num_rows = shift(@data);
    $num_cols = shift(@data);
    $line = <F1>; 
    chomp($line);
    @data = split("\t", $line);
    $gene = shift(@data);
    $desc = shift(@data);
    $j = 0;
    while (defined($datum = shift(@data))) {
	@words = split(" ", $datum);
	$datum = join("_", @words);
	$sample_names[$j] = $datum;
	$j++;
    }
}

@gene_matrix = ();
@call_matrix = ();
@gene_list = ();
@desc_list = ();
$gene_count = 0;

while (<F1>) {
    chomp $_;
    @data = split("\t", $_);
    if ($file_format == 1) { # it is in res format
	$desc = shift(@data);
	$gene = shift(@data);
    } else {   # gct format
	$gene = shift(@data);
	$desc = shift(@data);
    }
    $gene_array = ();
    $call_array = ();
    $j = 0;
    while (defined($datum = shift(@data))) {
	if ($file_format == 1) { # it is in res format
	    $call_matrix[$gene_count][$j] = shift(@data);
	}
	$gene_matrix[$gene_count][$j] = $datum;
	$j++;
    }
    $sample_count = $j;
    $gene_list[$gene_count] = $gene;
    $desc_list[$gene_count] = $desc;
    $gene_count++;
}
close F1;

print "sample_count=$sample_count \n";

if ($fraction_train > 1) {
    $train_size = $fraction_train;
} else {
    $train_size = floor($fraction_train*$sample_count);
}
if ($fraction_test > 1) {
    $test_size = $fraction_test;
} else {
    $test_size = $sample_count - $train_size;
}

print "train size = $train_size \n";
print "test size = $test_size \n";

# loop over splits

for $k (0..$num_splits - 1) {

    print "creating set $k...\n";

# permute samples and split

    @sort_order = ();
    for $i (0..$sample_count - 1) {
	$sort_order[$i] = $i;
	$distance{$i} = rand();
    }
    @sort_order = sort bydistance @sort_order;
    
# output train set 

    if ($file_format == 1) {
	$train_set_name = "$res_name" . ".train." . "$k.res";
	$test_set_name = "$res_name" . ".test." . "$k.res";
    } else {
	$train_set_name = "$res_name" . ".train." . "$k.gct";
	$test_set_name = "$res_name" . ".test." . "$k.gct";
    }

    if (-e "$train_set_name") { 
	print "Output train file $train_set_name exits. Deleting it ...\n";
	system("del $train_set_name");
    }
    if (-e "$test_set_name") { 
	print "Output test file $test_set_name exits. Deleting it ...\n";
	system("del $test_set_name");
    }

    $filename = ">" . "$train_set_name";
    open(TRAIN, $filename) || die "cannot open file: $filename \n";
    $filename = ">" . "$test_set_name";
    open(TEST, $filename) || die "cannot open file: $filename \n";

    if ($file_format == 0) {
	# GCT
	print TRAIN "$release";
	print TEST "$release";
	print TRAIN "$num_rows\t$train_size\n";
	print TEST "$num_rows\t$test_size\n";
    } 
    print TRAIN "Description\tAccession\t";  
    print TEST  "Description\tAccession\t";  

    for $k (0..$sample_count - 1) {   # Loop over samples
	if ($k < $train_size) {
	    print TRAIN "$sample_names[$sort_order[$k]]";
	    if ($k < ($train_size - 1)) {
		if ($file_format == 0) {
	    		print TRAIN "\t";
		} else {
	    		print TRAIN "\t\t";
		}
	    }
	} elsif ($k < $train_size + $test_size) {
	    print TEST "$sample_names[$sort_order[$k]]";
	    if ($k < ($train_size + $test_size - 1)) {
		if ($file_format == 0) {
	    		print TEST "\t";
		} else {
	    		print TEST "\t\t";
		}
	    }
	}
    }
    print TRAIN "\n";
    print TEST "\n";

    if ($file_format == 1) {
	for $k (0..$sample_count - 1) {   # Loop over samples
	    if ($k < $train_size) {
		print TRAIN "$scan_names[$sort_order[$k]]";
		if ($k < ($train_size - 1)) {
		    	print TRAIN "\t\t";
		}
	    } elsif ($k < $train_size + $test_size) {
		print TEST "$scan_names[$sort_order[$k]]";
		if ($k < ($train_size + $test_size - 1)) {
	    		print TEST "\t\t";
		}
	    }
	}
	print TRAIN "\n$num_rows\n";
	print TEST "\n$num_rows\n";
    }
    for $i (0..$gene_count - 1) {
	if ($file_format == 1) {
	    print TRAIN "$desc_list[$i]\t$gene_list[$i]\t";
	    print TEST  "$desc_list[$i]\t$gene_list[$i]\t";
	} else {
	    print TRAIN "$gene_list[$i]\t$desc_list[$i]\t";
	    print TEST  "$gene_list[$i]\t$desc_list[$i]\t";
	}

	for $k (0..$sample_count - 1) {   # Loop over samples
	    if ($k < $train_size) {
		if ($file_format == 1) {
		    print TRAIN "$gene_matrix[$i][$sort_order[$k]]\t$call_matrix[$i][$sort_order[$k]]";
		} else {
		    print TRAIN "$gene_matrix[$i][$sort_order[$k]]";
		}
		if ($k < ($train_size - 1)) {
			print TRAIN "\t";
		}
	    } elsif ($k < $train_size + $test_size) {
		if ($file_format == 1) {
		    print TEST "$gene_matrix[$i][$sort_order[$k]]\t$call_matrix[$i][$sort_order[$k]]";
		} else {
		    print TEST "$gene_matrix[$i][$sort_order[$k]]";
		}
		if ($k < ($train_size + $test_size - 1)) {
			print TEST "\t";
		}
	    }
	}
	print TRAIN "\n";
	print TEST "\n";
    }
    close TRAIN;
    close TEST;

    if ($cls_flag == 1) {

# save CLS files

	$train_cls_name = "$cls_name" . ".train." . "$k.cls";
	$filename = ">" . "$train_cls_name";
	open(TRAIN, $filename) || die "cannot open file: $filename \n";
	$test_cls_name = "$cls_name" . ".test." . "$k.cls";
	$filename = ">" . "$test_cls_name";
	open(TEST, $filename) || die "cannot open file: $filename \n";

	print TRAIN "$train_size $num_classes $num_mems\n";
	print TEST "$test_size $num_classes $num_mems\n";

	print TRAIN "$target_labels";
	print TEST "$target_labels";

	for $k (0..$sample_count - 1) {   # Loop over samples
	    if ($k < $train_size) {
		print TRAIN "$target_classes[$sort_order[$k]] ";
	    } elsif ($k < $train_size + $test_size) {
		print TEST "$target_classes[$sort_order[$k]] ";
	    }
	}
	close TRAIN;
	close TEST;
    }

}

sub bydistance {
    $distance{$b} <=> $distance{$a};
}
