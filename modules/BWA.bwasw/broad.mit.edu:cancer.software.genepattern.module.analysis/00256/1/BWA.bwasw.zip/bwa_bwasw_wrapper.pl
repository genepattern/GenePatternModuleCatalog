#!/usr/bin/perl

use Config;
use File::Basename;
use File::Path;
use IPC::Open3;
use IO::Select;
use IO::Handle;
use Getopt::Long;

$result = GetOptions ("libdir:s" => \$libdir,
                      "y:s"  => \$bwa_index_cache,
                      "w1:s" => \$prebuilt_index,
                      "w2:s" => \$custom_index,
                      "p:s"  => \$read_file,
                      "a:s"  => \$mScore,
                      "b:s"  => \$mismatchPen,
                      "q:s"  => \$gapOpenPen,
                      "r:s"  => \$gapExtPen,
                      "t1:s" => \$numThreads,
                      "w:s"  => \$bandWidth,
					  "t2:s" => \$mThresh,
					  "c:s"  => \$cThresh,
                      "z:s"  => \$zHeur,
                      "s:s"  => \$mInitSeed,
                      "n:s"  => \$minSeed,
					  "o:s" =>  \$outputPrefix
					  );

require ${libdir}."utility.pl";
require ${libdir}."download_bwa_index.pl";

$zip_command = "zip";
$unzip_command = "unzip";
$custom_bwa_index_path = "bwa_index/";

$bwa_linux64_zip=${libdir}."bwa-0.5.9.Linux_x86_64.zip";
$bwa_linux64_dir=${libdir}."bwa-0.5.9.Linux_x86_64/";
$bwa_mac64_zip=${libdir}."bwa-0.5.9.OSX_x86_64.zip";
$bwa_mac64_dir=${libdir}."bwa-0.5.9.OSX_x86_64/";
$bwa_mac32_zip=${libdir}."bwa-0.5.9.OSX_i386.zip";
$bwa_mac32_dir=${libdir}."bwa-0.5.9.OSX_i386/";

setupExecutables('mac64');

$bwa_exec=$bwa_dir."bwa";
if(checkCompatibility($bwa_exec) eq "false")
{
    rmtree($bwa_mac64_dir);

    setupExecutables('mac32');

    #check compatibility with 32-bit version
    if(checkCompatibility($bwa_exec) eq "false")
    {
        print STDERR "\nBWA.bwasw is not currently supported on this platform.";
        print STDERR "\nosname: $Config{osname}";
        print STDERR "\narchname: $Config{archname}\n";
        exit(1);
    }
}

if($bwa_index_cache ne "")
{
    if($ENV{'bwa.index.dir'} ne "")
    {
        $bwa_index_cache = $ENV{'bwa.index.dir'};
    }
}

if($prebuilt_index ne "none")
{
    $bwa_index = $bwa_index_cache.$prebuilt_index."/";
    download_bwa_index($prebuilt_index, $bwa_index);
    $bwa_index .= $prebuilt_index;
}
elsif($custom_index ne "")
{
    if(rindex($custom_index, ".zip") != -1)
    {
        unzip_func($custom_index, $custom_bwa_index_path);
    }

    opendir(DIR, $custom_bwa_index_path) or die $!;

    while (my $file = readdir(DIR))
    {
        $file_prefix = substr basename($file), 0, index(basename($file), '.');
        
        if($file !~ m/^\./)
        {
            $bwa_index_name = $file_prefix;
        }
    }

    closedir(DIR);
    #check if index name was found
    if($bwa_index_name eq "")
    {
        print STDERR "Unable to detect the name of the BWA index.";
        exit(1);
    }

    $bwa_index = $custom_bwa_index_path."${bwa_index_name}";
}
else
{
    print STDERR "\nEither a prebuilt BWA index or custom BWA index must be specified";
    exit(1);
}

if($read_file eq "")
{
    print STDERR "\nA read file must be specified";
    exit(1);

}
if($outputPrefix eq "")
{
    print STDERR "\nAn output prefix must be specified";
    exit(1);

}

$bwasw_cmd = "$bwa_exec bwasw";

if($mScore ne "")
{
    #mismatch penalty
    $bwasw_cmd .= " -a $mScore";
}
if($mismatchPen ne "")
{
    #mismatch penalty
    $bwasw_cmd .= " -b $mismatchPen";
}
if($gapOpenPen ne "")
{
    #gap open penalty
    $bwasw_cmd .= " -q $gapOpenPen";
}
if($gapExtenPen ne "")
{
    #gap extension penalty
    $bwasw_cmd .= " -r $gapExtenPen";
}
if($numThreads ne "")
{
    #num threads
    $bwasw_cmd .= " -t $numThreads";
}
if($bandWidth ne "")
{
    #gap extension penalty
    $bwasw_cmd .= " -w $bandWidth";
}
if($mThresh ne "")
{
    #minimum score threshold
    $bwasw_cmd .= " -T $mThresh";
}
if($cThresh ne "")
{
    #Coefficient for threshold adjustment
    $bwasw_cmd .= " -c $cThresh";
}
if($zHeur ne "")
{
    #Z-best heuristics
    $bwasw_cmd .= " -z $zHeur";
}
if($mInitSeed ne "")
{
    #Maximum SA interval size for initiating a seed
    $bwasw_cmd .= " -s $mInitSeed";
}
if($minSeed ne "")
{
    #Minimum number of seeds supporting the resultant alignment
    $bwasw_cmd .= " -N $minSeed";
}

$outputFile = $outputPrefix.".sam";
$bwasw_cmd .= " -f $outputFile";
$bwasw_cmd .= " " . $bwa_index. " ".$read_file;

print "\nCommand: $bwasw_cmd\n";
runCmd($bwasw_cmd);

sub runCmd()
{
    $cmd = shift;
    $Pin  = new IO::Handle;       $Pin->fdopen(10, "w");
    $Pout = new IO::Handle;       $Pout->fdopen(11, "r");
    $Perr = new IO::Handle;       $Perr->fdopen(12, "r");
    $Proc = open3($Pin, $Pout, $Perr, $cmd);

    my $sel = IO::Select->new();
    $sel->add($Perr, $Pout);

    while (my @ready = $sel->can_read)
    {
        foreach my $handle (@ready)
        {
            if (fileno($handle) == fileno($Perr))
            {
                # process has printed something on standard error
                my ($count, $data);
                $count = sysread($handle, $data, 1024);
                if ($count == 0)
                {
                    $sel->remove($handle);
                    next;
                }

                if ($data =~ m/read 0 sequences/i)
                #check for possible invalid input
    	        {
    	            $invalid_file = "True";
    		        print STDERR $data;
    		        print STDERR "Please check that the input file is a valid FASTA and FASTQ file";
    		    }

                if ($data =~ m/Abort/i || $data =~ m/Not enough memory allocated!/i)
                #if stderr output looks like an error message, write to stderr
    	        {
    		        print STDERR $data;
                }
                else
                {
            		print STDOUT $data;
                }
            }
            else
            {
                # process has printed something on standard out
                my ($count, $data);
                $count = sysread($handle, $data, 1024);
                if ($count == 0)
                {
                    $sel->remove($handle);
                    next;
                }
                print STDOUT $data;
            }
        }
    }
}

sub cleanup()
{
    #delete directory containing custom BWA index files from current directory
    rmtree($custom_bwa_index_path);

    #check if invalid input file
    if($invalid_file == "True")
    {
        unlink($outputFile);
    }
}

END
{
    cleanup();
}

